// Quantrain on Qollab: the Python bridge sends real shots to the backend picked in Select QPU.
import * as quantrainBridge from 'quantrain.qollab';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

// ═════════════ engine (prototype/src/engine.mjs, inlined by tools/build_prototype.py) ═════════════
// Quantrain engine — plain JavaScript, no rendering.
// Mirrors the Python package quantrain/: the level format, the Qiskit translation and the track physics.
// Used by the browser game (inlined by tools/build_prototype.py) and by tests/test_js_parity.py (via Node).

const FORMAT = 'quantrain-level/1';
const TWIST_STEPS = 8;                        // twists turn in steps of π/4; 8 steps = 2π = 0
const SPAN = { twist: 1, points: 2, cross: 2, interlock: 2 };
const PI = Math.PI;

class LevelError extends Error {}

// ───────────────────────── level format ─────────────────────────

function element(d, fixed, lid) {
  if (!(d.type in SPAN)) throw new LevelError(`${lid}: unknown element type '${d.type}'`);
  const steps = d.steps ?? 0, stay = d.stay ?? 50;
  if (d.type === 'twist' && !(Number.isInteger(steps) && steps >= 0 && steps < TWIST_STEPS)) throw new LevelError(`${lid}: twist steps must be 0..7`);
  if (d.type === 'points' && !(stay >= 0 && stay <= 100)) throw new LevelError(`${lid}: points 'stay' must be 0..100`);
  return { type: d.type, col: +d.col, rails: [...d.rails], steps, stay, fixed };
}
const phiOf = el => (el.steps % TWIST_STEPS) * PI / 4;
const thetaOf = el => 2 * Math.acos(Math.sqrt(el.stay / 100));

function parseLevel(data) {
  if (data.format !== FORMAT) throw new LevelError(`expected format '${FORMAT}'`);
  const lid = data.id ?? '?';
  const L = {
    id: lid, name: data.name ?? lid, blurb: data.blurb ?? '',
    rails: [...data.rails], columns: +data.columns, dispatch: data.dispatch ?? 'sequential',
    trains: data.trains.map(t => ({ id: t.id, colour: t.colour ?? '#f2683a', depot: t.depot, rails: [...(t.rails ?? [])] })),
    slots: (data.slots ?? []).map(s => ({ col: +s.col, rails: [...s.rails] })),
    fixed: (data.fixed ?? []).map(e => element(e, true, lid)),
    stations: (data.stations ?? []).map(s => ({ id: s.id, name: s.name ?? s.id, rail: s.rail, col: +s.col, passengers: [...(s.passengers ?? [])], partner: s.partner ?? null })),
    supply: { ...(data.supply ?? {}) },
    solutions: { ...(data.solutions ?? {}) },
    cars: data.cars ?? null,
    source: data,                                  // the level file as given (sent to Python on Qollab)
  };
  L.railIndex = r => L.rails.indexOf(r);
  L.owner = r => L.trains.find(t => t.rails.includes(r)) ?? null;
  L.groups = () => (L.dispatch === 'together' ? [[...L.trains]] : L.trains.map(t => [t]));
  validate(L);
  return L;
}

function validate(L) {
  const lid = L.id, cells = new Map();
  if (L.rails.length < 1 || L.rails.length > 12) throw new LevelError(`${lid}: needs 1..12 rails`);
  if (!['sequential', 'together'].includes(L.dispatch)) throw new LevelError(`${lid}: dispatch '${L.dispatch}' not supported`);
  if (L.trains.length < 1 || L.trains.length > 4) throw new LevelError(`${lid}: needs 1..4 trains`);
  if (L.cars !== null && !(Number.isInteger(L.cars) && L.cars >= 1 && L.cars <= 64)) throw new LevelError(`${lid}: 'cars' must be a whole number 1..64`);
  for (const s of L.stations) {
    const p = s.partner && L.stations.find(o => o.id === s.partner);
    if (s.partner && (!p || p.partner !== s.id)) throw new LevelError(`${lid}: station '${s.id}' and its partner must name each other`);
  }
  if (L.dispatch === 'together') {
    const owned = L.trains.flatMap(t => t.rails);
    if (L.trains.some(t => !t.rails.length || !t.rails.includes(t.depot))) throw new LevelError(`${lid}: every train lists its rails, including its depot`);
    if (new Set(owned).size !== owned.length) throw new LevelError(`${lid}: two trains own the same rail`);
  } else if ('interlock' in L.supply || L.fixed.some(e => e.type === 'interlock')) {
    throw new LevelError(`${lid}: interlocks need trains that leave together`);
  }
  const claim = (col, rails, what, isElement = false) => {
    if (col < 1 || col > L.columns) throw new LevelError(`${lid}: ${what} outside columns 1..${L.columns}`);
    for (const r of rails) if (L.railIndex(r) < 0) throw new LevelError(`${lid}: ${what} uses unknown rail '${r}'`);
    if (!rails.length || new Set(rails).size !== rails.length) throw new LevelError(`${lid}: ${what} must list distinct rails`);
    if (isElement && rails.length === 2 && Math.abs(L.railIndex(rails[0]) - L.railIndex(rails[1])) !== 1) throw new LevelError(`${lid}: ${what} joins rails that are not neighbours`);
    for (const r of rails) {
      const k = `${col}/${r}`;
      if (cells.has(k)) throw new LevelError(`${lid}: ${what} overlaps ${cells.get(k)}`);
      cells.set(k, what);
    }
  };
  L.slots.forEach(s => claim(s.col, s.rails, `build cells ${s.col}/${s.rails.join('-')}`));
  L.fixed.forEach(e => {
    if (e.rails.length !== SPAN[e.type]) throw new LevelError(`${lid}: fixed ${e.type} needs ${SPAN[e.type]} rail(s)`);
    claim(e.col, e.rails, `fixed ${e.type}`, true); pairRule(L, e);
  });
  L.stations.forEach(s => claim(s.col, [s.rail], `station '${s.id}'`));
}

// Trains that leave together never share a rail: points/crossovers stay inside one train's rails,
// an interlock is the only element joining rails of two different trains.
function pairOk(L, type, rails) {
  if (L.dispatch !== 'together' || rails.length !== 2) return true;
  const [a, b] = rails.map(L.owner);
  return type === 'interlock' ? !!(a && b && a !== b) : !!(a && a === b);
}
function pairRule(L, el) {
  if (!pairOk(L, el.type, el.rails)) {
    throw new LevelError(`${L.id}: ${el.type} at ${el.col}/${el.rails.join('-')} breaks the rule that trains never share a rail`);
  }
}

// ───────────────────────── build cells and placements ─────────────────────────
// The level's "slots" list build cells: one per (column, rail). A twist takes one cell; points, a crossover or
// an interlock take two neighbouring cells of one column. Each cell holds one element. Rails are stored top
// to bottom.

const isCell = (L, col, rail) => L.slots.some(s => s.col === col && s.rails.includes(rail));
const ordered = (L, rails) => [...rails].sort((a, b) => L.railIndex(a) - L.railIndex(b));

/** Every place an element of this type could go on an empty board: [{ col, rails }], rails top to bottom. */
function spots(L, type) {
  const out = [];
  for (let col = 1; col <= L.columns; col++) {
    for (let k = 0; k < L.rails.length; k++) {
      const rails = SPAN[type] === 1 ? [L.rails[k]] : k + 1 < L.rails.length ? [L.rails[k], L.rails[k + 1]] : null;
      if (!rails || !rails.every(r => isCell(L, col, r))) continue;
      if (pairOk(L, type, rails)) out.push({ col, rails });
    }
  }
  return out;
}
/** Can an element of this type stand on these rails of this column (build cells, neighbours, rail sharing rule)? */
function fits(L, type, spot) {
  const rails = ordered(L, spot.rails);
  if (rails.length !== SPAN[type] || !rails.every(r => isCell(L, spot.col, r))) return false;
  if (rails.length === 2 && Math.abs(L.railIndex(rails[0]) - L.railIndex(rails[1])) !== 1) return false;
  return pairOk(L, type, rails);
}

/** Fixed elements + validated player placements, in column order (same order as the Python translator). */
function layout(L, placements) {
  const used = {}, taken = new Set(), placed = [];
  for (const raw of placements) {
    const el = element(raw, false, L.id);
    const rails = ordered(L, el.rails);
    const where = `${el.type} at ${el.col}/${rails.join('-')}`;
    if (rails.some(r => L.railIndex(r) < 0)) throw new LevelError(`${L.id}: ${where} uses an unknown rail`);
    if (rails.length !== SPAN[el.type] || new Set(rails).size !== rails.length) throw new LevelError(`${L.id}: ${where} must cover ${SPAN[el.type]} rail(s)`);
    if (rails.length === 2 && Math.abs(L.railIndex(rails[0]) - L.railIndex(rails[1])) !== 1) throw new LevelError(`${L.id}: ${where} joins rails that are not neighbours`);
    for (const r of rails) {
      if (!isCell(L, el.col, r)) throw new LevelError(`${L.id}: ${where} is not on build cells`);
      if (taken.has(`${el.col}/${r}`)) throw new LevelError(`${L.id}: ${where} lands on a cell that is already used`);
    }
    if (!(el.type in L.supply)) throw new LevelError(`${L.id}: ${el.type} is not available here`);
    used[el.type] = (used[el.type] ?? 0) + 1;
    const cap = L.supply[el.type];
    if (cap !== null && used[el.type] > cap) throw new LevelError(`${L.id}: only ${cap} × ${el.type} available`);
    for (const r of rails) taken.add(`${el.col}/${r}`);
    const done = { ...el, rails };
    pairRule(L, done);
    placed.push(done);
  }
  return [...L.fixed, ...placed].map((e, i) => [e, i]).sort((a, b) => a[0].col - b[0].col || a[1] - b[1]).map(p => p[0]);
}

// ───────────────────────── Qiskit translation ─────────────────────────

const regName = (kind, id) => `${kind}_` + String(id).replace(/[^A-Za-z0-9_]/g, '_');

/** The circuit as a list of ops, gate for gate what quantrain/circuit.py builds. */
function buildCircuit(L, els, trains, { measure = true } = {}) {
  trains = Array.isArray(trains) ? trains : [trains];
  const nR = L.rails.length, nS = L.stations.length;
  const q = r => L.railIndex(r);
  const qubits = [...L.rails.map(r => regName('rail', r)), ...L.stations.map(s => regName('S', s.id))];
  const ops = trains.map(t => ({ gate: 'x', qubits: [q(t.depot)], params: [], src: { kind: 'depot', train: t.id } }));
  ops.push({ gate: 'barrier', label: 'depot' });
  for (let col = 1; col <= L.columns; col++) {
    for (const el of els) {
      if (el.col !== col) continue;
      if (el.type === 'twist') {
        if (el.steps % TWIST_STEPS) ops.push({ gate: 'p', qubits: [q(el.rails[0])], params: [phiOf(el)], src: { kind: 'twist', el } });
      } else if (el.type === 'points') {
        ops.push({ gate: 'xx_plus_yy', qubits: [q(el.rails[0]), q(el.rails[1])], params: [thetaOf(el), PI / 2], src: { kind: 'points', el } });
      } else if (el.type === 'cross') {
        ops.push({ gate: 'swap', qubits: [q(el.rails[0]), q(el.rails[1])], params: [], src: { kind: 'cross', el } });
      } else if (el.type === 'interlock') {
        ops.push({ gate: 'cz', qubits: [q(el.rails[0]), q(el.rails[1])], params: [], src: { kind: 'interlock', el } });
      }
    }
    L.stations.forEach((st, i) => {
      if (st.col === col) ops.push({ gate: 'cx', qubits: [q(st.rail), nR + i], params: [], src: { kind: 'station', st } });
    });
    ops.push({ gate: 'barrier', label: `c${col}` });
  }
  if (measure) ops.push({ gate: 'measure', qubits: qubits.map((_, i) => i), params: [] });
  return { name: `${L.id}:${trains.length === 1 ? trains[0].id : 'together'}`, qubits, nRails: nR, nStations: nS, nTrains: trains.length, ops };
}

/** Python source that rebuilds exactly this circuit in Qiskit. */
function toQiskitPython(L, circ) {
  const n = circ.qubits.length;
  const ang = x => {
    for (const [num, den] of [[0, 1], [1, 4], [1, 2], [3, 4], [1, 1], [5, 4], [3, 2], [7, 4], [2, 1]]) {
      if (Math.abs(x - PI * num / den) < 1e-12) {
        if (num === 0) return '0';
        const top = num === 1 ? 'pi' : `${num}*pi`;
        return den === 1 ? top : `${top}/${den}`;
      }
    }
    return x.toPrecision(17);
  };
  const lines = [
    'from math import pi',
    'from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister',
    'from qiskit.circuit.library import XXPlusYYGate',
    '',
    `# Quantrain · ${circ.name} — one qubit per rail, one per station`,
    `regs = [${circ.qubits.map(name => `QuantumRegister(1, "${name}")`).join(', ')}]`,
    `qc = QuantumCircuit(*regs, ClassicalRegister(${n}, "c"), name="${circ.name}")`,
  ];
  for (const op of circ.ops) {
    const [a, b] = op.qubits ?? [];
    if (op.gate === 'x') lines.push(`qc.x(${a})`);
    else if (op.gate === 'p') lines.push(`qc.p(${ang(op.params[0])}, ${a})`);
    else if (op.gate === 'xx_plus_yy') lines.push(`qc.append(XXPlusYYGate(${ang(op.params[0])}, ${ang(op.params[1])}), [${a}, ${b}])`);
    else if (op.gate === 'swap') lines.push(`qc.swap(${a}, ${b})`);
    else if (op.gate === 'cz') lines.push(`qc.cz(${a}, ${b})`);
    else if (op.gate === 'cx') lines.push(`qc.cx(${a}, ${b})`);
    else if (op.gate === 'barrier') lines.push(`qc.barrier(label="${op.label}")`);
    else if (op.gate === 'measure') lines.push(`qc.measure(range(${n}), range(${n}))`);
  }
  return lines.join('\n') + '\n';
}

// ───────────────────────── statevector simulation of the circuit ─────────────────────────

function simulate(circ) {
  const n = circ.qubits.length, size = 1 << n;
  const re = new Float64Array(size), im = new Float64Array(size);
  re[0] = 1;
  const swapAmp = (i, j) => { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; };
  for (const op of circ.ops) {
    const [a, b] = op.qubits ?? [];
    const ma = 1 << a, mb = 1 << b;
    if (op.gate === 'x') { for (let i = 0; i < size; i++) if (!(i & ma)) swapAmp(i, i | ma); }
    else if (op.gate === 'p') {
      const c = Math.cos(op.params[0]), s = Math.sin(op.params[0]);
      for (let i = 0; i < size; i++) if (i & ma) { const r = re[i], m = im[i]; re[i] = r * c - m * s; im[i] = r * s + m * c; }
    } else if (op.gate === 'swap') { for (let i = 0; i < size; i++) if ((i & ma) && !(i & mb)) swapAmp(i, (i ^ ma) | mb); }
    else if (op.gate === 'cx') { for (let i = 0; i < size; i++) if ((i & ma) && !(i & mb)) swapAmp(i, i | mb); }
    else if (op.gate === 'cz') { for (let i = 0; i < size; i++) if ((i & ma) && (i & mb)) { re[i] = -re[i]; im[i] = -im[i]; } }
    else if (op.gate === 'xx_plus_yy') {
      // Qiskit XXPlusYYGate(θ, β) on [a, b]: |a=1,b=0⟩ ↔ |a=0,b=1⟩ block
      // [[c, -i s e^{-iβ}], [-i s e^{iβ}, c]]
      const [theta, beta] = op.params, c = Math.cos(theta / 2), s = Math.sin(theta / 2);
      const u = [-s * Math.sin(beta), -s * Math.cos(beta)];   // -i s e^{-iβ}
      const w = [s * Math.sin(beta), -s * Math.cos(beta)];    // -i s e^{iβ}
      for (let i = 0; i < size; i++) {
        if (!((i & ma) && !(i & mb))) continue;
        const j = (i ^ ma) | mb;
        const [ir, ii, jr, ji] = [re[i], im[i], re[j], im[j]];
        re[i] = c * ir + (u[0] * jr - u[1] * ji); im[i] = c * ii + (u[0] * ji + u[1] * jr);
        re[j] = (w[0] * ir - w[1] * ii) + c * jr; im[j] = (w[0] * ii + w[1] * ir) + c * ji;
      }
    }
  }
  const probs = {};
  for (let i = 0; i < size; i++) {
    const p = re[i] * re[i] + im[i] * im[i];
    if (p > 1e-12) probs[i.toString(2).padStart(n, '0')] = p;
  }
  return probs;
}

/** One measured bitstring (Qiskit order, qubit 0 rightmost) in game terms. */
function decode(L, key, nTrains = 1) {
  const bits = key.replace(/ /g, '').split('').reverse();
  const nR = L.rails.length;
  const on = L.rails.filter((_, i) => bits[i] === '1');
  const stops = L.stations.filter((_, i) => bits[nR + i] === '1').sort((x, y) => x.col - y.col).map(s => s.id);
  const ok = on.length === nTrains;
  return { exit: ok ? on.join('+') : null, valid: ok, stops };
}
const outcomeKey = d => `${d.stops.join(',')}|${d.exit ?? 'derail'}`;

function circuitOutcomes(L, els, trains) {
  trains = Array.isArray(trains) ? trains : [trains];
  const out = {};
  for (const [key, p] of Object.entries(simulate(buildCircuit(L, els, trains, { measure: false })))) {
    const k = outcomeKey(decode(L, key, trains.length));
    out[k] = (out[k] ?? 0) + p;
  }
  return out;
}

// ───────────────────────── track physics (what the game animates) ─────────────────────────
// The state is a Map: configuration → complex amplitude [re, im]. A configuration lists the rail index of
// each train in the group ("0,3"); with one train it is just one amplitude per rail. applyJoint applies the
// part of an element between progress p0 and p1 (0..1), so the animation can show it happening gradually.

const abs2 = c => c[0] * c[0] + c[1] * c[1];
const cfgOf = key => key.split(',').map(Number);
const rot = (c, ang) => { const co = Math.cos(ang), si = Math.sin(ang); return [c[0] * co - c[1] * si, c[0] * si + c[1] * co]; };

function initialState(L, trains) {
  return new Map([[trains.map(t => L.railIndex(t.depot)).join(','), [1, 0]]]);
}

function applyJoint(S, L, el, p0, p1) {
  const q = r => L.railIndex(r);
  const out = new Map();
  const add = (cfg, c) => { const k = cfg.join(','), o = out.get(k); out.set(k, o ? [o[0] + c[0], o[1] + c[1]] : c); };
  if (el.type === 'twist') {
    const k = q(el.rails[0]), ang = phiOf(el) * (p1 - p0);
    for (const [key, c] of S) out.set(key, cfgOf(key).includes(k) ? rot(c, ang) : c);
    return out;
  }
  const i = q(el.rails[0]), j = q(el.rails[1]);
  if (el.type === 'interlock') {                         // CZ, phased in gradually: e^{iπp} when trains sit on both rails
    const ang = PI * (p1 - p0);
    for (const [key, c] of S) { const cfg = cfgOf(key); out.set(key, cfg.includes(i) && cfg.includes(j) ? rot(c, ang) : c); }
    return out;
  }
  if (el.type === 'cross') {                             // a swap happens all at once, halfway along
    if ((p0 < 0.5) === (p1 < 0.5)) return new Map(S);
    for (const [key, c] of S) add(cfgOf(key).map(r => (r === i ? j : r === j ? i : r)), c);
    return out;
  }
  // points: RY(θ) on the train sitting on rail i or j — [stay, switch] = [[cs, -sn], [sn, cs]]
  const half = thetaOf(el) * (p1 - p0) / 2, cs = Math.cos(half), sn = Math.sin(half);
  for (const [key, c] of S) {
    const cfg = cfgOf(key), ti = cfg.indexOf(i), tj = cfg.indexOf(j);
    if (ti >= 0) {
      add(cfg, [cs * c[0], cs * c[1]]);
      const m = [...cfg]; m[ti] = j; add(m, [sn * c[0], sn * c[1]]);
    } else if (tj >= 0) {
      const m = [...cfg]; m[tj] = i; add(m, [-sn * c[0], -sn * c[1]]);
      add(cfg, [cs * c[0], cs * c[1]]);
    } else add(cfg, c);
  }
  return out;
}

/** Which stations of this column see a train in configuration cfg (ids in station order). */
const seenBy = (L, stops, cfg) => stops.filter(s => cfg.includes(L.railIndex(s.rail))).map(s => s.id);

/** Probabilities of (stations that saw a train, exit rails) — same algorithm as quantrain/reference.py. */
function trackOutcomes(L, els, trains) {
  trains = Array.isArray(trains) ? trains : [trains];
  let branches = [[[], initialState(L, trains)]];
  for (let col = 1; col <= L.columns; col++) {
    for (const el of els) if (el.col === col) branches = branches.map(([seen, S]) => [seen, applyJoint(S, L, el, 0, 1)]);
    const stops = L.stations.filter(s => s.col === col);
    if (!stops.length) continue;
    const next = [];
    for (const [seen, S] of branches) {
      const groups = new Map();
      for (const [key, c] of S) {
        const hit = seenBy(L, stops, cfgOf(key)).join(',');
        if (!groups.has(hit)) groups.set(hit, new Map());
        groups.get(hit).set(key, c);
      }
      for (const [hit, sub] of groups) {
        let p = 0; for (const c of sub.values()) p += abs2(c);
        if (p > 1e-30) next.push([[...seen, ...(hit ? hit.split(',') : [])], sub]);
      }
    }
    branches = next;
  }
  const out = {};
  for (const [seen, S] of branches) for (const [key, c] of S) {
    const p = abs2(c);
    if (p <= 1e-12) continue;
    const k = `${seen.join(',')}|${cfgOf(key).sort((a, b) => a - b).map(r => L.rails[r]).join('+')}`;
    out[k] = (out[k] ?? 0) + p;
  }
  return out;
}

// ───────────────────────── the ideal run (scoring) ─────────────────────────
// A run sends `cars` cars per circuit; every car is one shot. In the ideal run the cars are spread over the
// outcomes exactly in proportion to their probabilities (largest remainder), so the score depends only on the
// build. Each car picks up one passenger at every station that sees it; couples board only if the partner
// station sees the same car. Same algorithm as quantrain/score.py (checked by tests/test_js_parity.py).

/** Cars per circuit: the level's 'cars', or enough to carry every passenger once. */
function carsFor(L) {
  if (L.cars) return L.cars;
  const total = L.stations.reduce((n, s) => n + s.passengers.length, 0);
  return Math.max(1, Math.ceil(total / L.groups().length));
}
/** Spread `cars` shots over the outcomes in proportion (largest remainder), interleaved evenly. */
function idealShots(probs, cars) {
  const keys = Object.keys(probs).filter(k => probs[k] > 1e-12).sort();
  const quota = keys.map(k => probs[k] * cars);
  const n = quota.map(q => Math.floor(q + 1e-9));
  let left = cars - n.reduce((a, b) => a + b, 0);
  const rem = i => Math.round((quota[i] - n[i]) * 1e9) / 1e9;
  const order = keys.map((_, i) => i).sort((a, b) => rem(b) - rem(a) || a - b);
  for (const i of order) { if (left <= 0) break; n[i] += 1; left -= 1; }
  const cur = keys.map(() => 0), out = [];
  for (let s = 0; s < cars; s++) {                 // smooth weighted round robin: A B A B rather than A A B B
    keys.forEach((_, i) => { cur[i] += n[i]; });
    let best = 0;
    for (let i = 1; i < keys.length; i++) if (cur[i] > cur[best]) best = i;
    out.push(keys[best]);
    cur[best] -= cars;
  }
  return out;
}
function starsFor(picked, total) {
  if (!total) return 0;
  if (picked === total) return 3;
  return picked * 3 >= total * 2 ? 2 : picked * 3 >= total ? 1 : 0;
}
/** Play the ideal run: the outcome of every car, and how many passengers they pick up. */
function idealRun(L, els) {
  const waiting = new Map(L.stations.map(s => [s.id, s.passengers.length]));
  const cars = carsFor(L);
  const groups = L.groups().map(group => {
    const probs = trackOutcomes(L, els, group);
    const shots = idealShots(probs, cars);
    for (const key of shots) {
      const seen = new Set(key.split('|')[0].split(',').filter(Boolean));
      for (const id of seen) {
        const st = L.stations.find(s => s.id === id);
        if (st.partner && !seen.has(st.partner)) continue;
        if (waiting.get(id) > 0) waiting.set(id, waiting.get(id) - 1);
      }
    }
    return { group, probs, shots };
  });
  const total = L.stations.reduce((n, s) => n + s.passengers.length, 0);
  const picked = total - [...waiting.values()].reduce((a, b) => a + b, 0);
  return { cars, groups, picked, total, cleared: total > 0 && picked === total, stars: starsFor(picked, total) };
}

// ───────────────────────── what each ghost shows ─────────────────────────
// For every train t and rail r: the probability of finding t there, and a phase for its roll and label.
// One train: the amplitude's own phase. Several trains: individual phases aren't defined for an entangled
// state, so we use a stable convention: a ghost shows the phase of the strongest joint configuration it is
// part of (for unentangled trains that is simply the train's own relative phase), measured against a
// reference configuration that is kept from frame to frame (prevRefKey) while it still carries weight.
// Ties are broken by configuration order, never by rounding noise, so nothing flips back and forth.
function ghostView(S, nTrains, nRails, prevRefKey = null) {
  const arg = c => Math.atan2(c[1], c[0]);
  const items = [];
  for (const [k, c] of S) { const p = abs2(c); if (p > 1e-12) items.push({ k, cfg: cfgOf(k), c, p }); }
  const order = (a, b) => (Math.abs(b.p - a.p) > 1e-6 ? b.p - a.p : a.k < b.k ? -1 : a.k > b.k ? 1 : 0);
  items.sort(order);
  const marg = Array.from({ length: nTrains }, () => new Array(nRails).fill(0));
  const phase = Array.from({ length: nTrains }, () => new Array(nRails).fill(0));
  for (const it of items) it.cfg.forEach((r, t) => { marg[t][r] += it.p; });
  if (!items.length) return { marg, phase, refKey: null };
  if (nTrains === 1) {
    for (const it of items) phase[0][it.cfg[0]] = arg(it.c);
    return { marg, phase, refKey: items[0].k };
  }
  const top = items[0].p;
  const prev = prevRefKey && S.get(prevRefKey);
  const ref = prev && abs2(prev) > 0.02 * top ? { k: prevRefKey, cfg: cfgOf(prevRefKey), c: prev } : items[0];
  const refPh = arg(ref.c);
  for (let t = 0; t < nTrains; t++) {
    for (let r = 0; r < nRails; r++) {
      if (marg[t][r] <= 1e-12) continue;
      phase[t][r] = arg(items.find(it => it.cfg[t] === r).c) - refPh;   // strongest branch this ghost is part of
    }
  }
  return { marg, phase, refKey: ref.k };
}

// ───────────────────────── shared puzzles (a whole puzzle inside a link) ─────────────────────────
// A puzzle made in the Playground travels as a compact array, compressed (deflate-raw) and written in URL-safe
// base64 after "#p=q1." in a link, or pasted as a code. It turns into an ordinary level file (puzzleToLevelData),
// so everything a level is checked for applies to it, plus the playground limits below.
//
//   [1, name, description, rails, columns, together(0/1),
//    trains   [[colour slot 0..3, depot rail index]],
//    stations [[col, rail index, passengers 0..4, partner station index or -1]],
//    fixed    [[type code, col, top rail index, steps (twist) | stay (points)]],     type codes: TYPE_CODES
//    cells    [bitmask of the rails the player may build on, one per column],
//    supply   [twist, points, cross, interlock]  (-1 = unlimited, 0 = not offered, n = n),
//    cars     (0 = automatic)]
const LIMITS = { maxRails: 8, maxColumns: 10, maxQubits: 20, maxTrains: 4, maxPassengers: 4, name: 40, description: 280 };
const TRAIN_KINDS = [['orange', '#f2683a'], ['teal', '#12a39b'], ['violet', '#8a5cf6'], ['blue', '#2f7de1']];
const SHAPE_NAMES = ['bubble', 'cube', 'octahedron'];
const TYPE_CODES = ['twist', 'points', 'cross', 'interlock'];
const PUZZLE_VERSION = 1;
const letter = k => String.fromCharCode(65 + k);

/** The puzzle array → a level file (throws LevelError when anything is off). */
function puzzleToLevelData(P) {
  const bad = why => { throw new LevelError(`puzzle: ${why}`); };
  if (!Array.isArray(P) || P.length !== 12 || P[0] !== PUZZLE_VERSION) bad('unknown puzzle format');
  const [, name, desc, nR, nC, together, trains, stations, fixed, cells, supply, cars] = P;
  const isInt = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  if (typeof name !== 'string' || name.length > LIMITS.name) bad('name');
  if (typeof desc !== 'string' || desc.length > LIMITS.description) bad('description');
  if (!isInt(nR, 1, LIMITS.maxRails) || !isInt(nC, 1, LIMITS.maxColumns) || !isInt(together, 0, 1)) bad('size');
  if (!Array.isArray(trains) || !trains.length || trains.length > LIMITS.maxTrains) bad('trains');
  if (!Array.isArray(stations) || nR + stations.length > LIMITS.maxQubits) bad('stations');
  if (!Array.isArray(fixed) || fixed.length > nR * nC || !Array.isArray(cells) || cells.length !== nC) bad('map');
  if (!Array.isArray(supply) || supply.length !== 4 || !supply.every(v => isInt(v, -1, 99))) bad('supply');
  if (!isInt(cars, 0, 64)) bad('cars');
  const rails = Array.from({ length: nR }, (_, k) => letter(k));
  for (const t of trains) if (!Array.isArray(t) || !isInt(t[0], 0, 3) || !isInt(t[1], 0, nR - 1)) bad('train');
  if (new Set(trains.map(t => t[0])).size !== trains.length || new Set(trains.map(t => t[1])).size !== trains.length) bad('two trains alike');
  const sorted = [...trains].sort((a, b) => a[1] - b[1]);
  const levelTrains = sorted.map(([slot, r], k) => {
    const d = { id: TRAIN_KINDS[slot][0], colour: TRAIN_KINDS[slot][1], depot: rails[r] };
    if (together) d.rails = rails.slice(k === 0 ? 0 : r, k + 1 < sorted.length ? sorted[k + 1][1] : nR);
    return d;
  });
  const sid = st => `s${st[0]}${rails[st[1]]}`;
  for (const st of stations) if (!Array.isArray(st) || !isInt(st[0], 1, nC) || !isInt(st[1], 0, nR - 1) || !isInt(st[2], 0, LIMITS.maxPassengers) || !isInt(st[3], -1, stations.length - 1)) bad('station');
  const levelStations = stations.map((st, i) => ({
    id: sid(st), name: `Stop ${rails[st[1]]}${st[0]}`, rail: rails[st[1]], col: st[0],
    passengers: Array.from({ length: st[2] }, (_, k) => SHAPE_NAMES[(i + k) % 3]),
    ...(st[3] >= 0 ? { partner: sid(stations[st[3]]) } : {}),
  }));
  const levelFixed = fixed.map(f => {
    if (!Array.isArray(f) || !isInt(f[0], 0, 3) || !isInt(f[1], 1, nC) || !isInt(f[2], 0, nR - 1)) bad('block');
    const type = TYPE_CODES[f[0]], span = SPAN[type];
    if (f[2] + span > nR) bad('block off the map');
    const el = { type, col: f[1], rails: rails.slice(f[2], f[2] + span) };
    if (type === 'twist') { if (!isInt(f[3], 0, 7)) bad('twist'); el.steps = f[3]; }
    if (type === 'points') { if (!isInt(f[3], 0, 100)) bad('points'); el.stay = f[3]; }
    return el;
  });
  const slots = [];
  cells.forEach((mask, c) => {
    if (!isInt(mask, 0, (1 << nR) - 1)) bad('cells');
    const free = rails.filter((_, k) => mask & (1 << k));
    if (free.length) slots.push({ col: c + 1, rails: free });
  });
  const levelSupply = {};
  TYPE_CODES.forEach((t, i) => { if (supply[i] !== 0) levelSupply[t] = supply[i] < 0 ? null : supply[i]; });
  if (!together || trains.length < 2) delete levelSupply.interlock;
  const data = {
    format: FORMAT, id: 'puzzle', name: name || 'Untitled puzzle', blurb: desc, rails, columns: nC,
    dispatch: together ? 'together' : 'sequential', trains: levelTrains, slots, fixed: levelFixed,
    stations: levelStations, supply: levelSupply, solutions: {}, ...(cars ? { cars } : {}),
  };
  parseLevel(data);                                // throws on overlaps, broken couples, shared rails, …
  return data;
}

const b64url = bytes => {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};
const unb64url = text => {
  const s = atob(text.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((text.length + 3) % 4));
  return Uint8Array.from(s, ch => ch.charCodeAt(0));
};
async function pipe(bytes, stream) {
  return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(stream)).arrayBuffer());
}
/** Puzzle array → "q1.…" (compressed) or "q1j.…" (plain, for browsers without CompressionStream). */
export async function encodePuzzle(P) {
  puzzleToLevelData(P);                            // never share a broken puzzle
  const bytes = new TextEncoder().encode(JSON.stringify(P));
  if (typeof CompressionStream === 'function') return 'q1.' + b64url(await pipe(bytes, new CompressionStream('deflate-raw')));
  return 'q1j.' + b64url(bytes);
}
/** A code, or any text containing "#p=<code>" (a whole link) → { puzzle, level data }. Throws LevelError if damaged. */
export async function decodePuzzle(text) {
  const m = String(text).trim().match(/(?:#p=)?(q1j?)\.([A-Za-z0-9_-]{4,8000})\s*$/);
  if (!m) throw new LevelError('puzzle: this is not a puzzle code');
  let bytes;
  try {
    bytes = unb64url(m[2]);
    if (m[1] === 'q1') bytes = await pipe(bytes, new DecompressionStream('deflate-raw'));
  } catch { throw new LevelError('puzzle: the code is damaged'); }
  if (bytes.length > 20000) throw new LevelError('puzzle: too big');
  let P;
  try { P = JSON.parse(new TextDecoder().decode(bytes)); } catch { throw new LevelError('puzzle: the code is damaged'); }
  return { puzzle: P, data: puzzleToLevelData(P) };
}

// ═════════════ levels (levels/*.json, inlined by the build) ═════════════
const LEVEL_FILES = [
 {
  "format": "quantrain-level/1",
  "id": "01-first-departure",
  "name": "First departure",
  "blurb": "Your train is a single photon and the station is a detector. Press Run: one press sends one train of cars, and every car is one shot of the quantum circuit.",
  "rails": [
   "A"
  ],
  "columns": 2,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [],
  "fixed": [],
  "stations": [
   {
    "id": "stop",
    "name": "Stop",
    "rail": "A",
    "col": 2,
    "passengers": [
     "bubble",
     "cube",
     "octahedron"
    ]
   }
  ],
  "supply": {},
  "solutions": {
   "untouched": []
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "02-twist-tunnel",
  "name": "Twist tunnel",
  "blurb": "A twist rolls the train: the roll is its phase. Drop twists on the pads and tap them to turn them by π/4. Twists add up and wrap round. The station takes everyone whatever you do: a train on one track shows its roll to nobody.",
  "rails": [
   "A"
  ],
  "columns": 4,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 1,
    "rails": [
     "A"
    ]
   },
   {
    "col": 2,
    "rails": [
     "A"
    ]
   },
   {
    "col": 3,
    "rails": [
     "A"
    ]
   }
  ],
  "fixed": [],
  "stations": [
   {
    "id": "stop",
    "name": "Stop",
    "rail": "A",
    "col": 4,
    "passengers": [
     "octahedron",
     "bubble",
     "cube"
    ]
   }
  ],
  "supply": {
   "twist": null
  },
  "solutions": {
   "untouched": [],
   "half-turn": [
    {
     "type": "twist",
     "col": 1,
     "rails": [
      "A"
     ],
     "steps": 2
    },
    {
     "type": "twist",
     "col": 2,
     "rails": [
      "A"
     ],
     "steps": 2
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "03-quantum-points",
  "name": "Quantum points",
  "blurb": "Quantum points split the train into two ghosts. The stations measure it: each car shows up on one line only, at random. Serve both stops.",
  "rails": [
   "A",
   "B"
  ],
  "columns": 3,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "col": 2,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "fixed": [],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 3,
    "passengers": [
     "bubble",
     "cube"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 3,
    "passengers": [
     "octahedron",
     "bubble"
    ]
   }
  ],
  "supply": {
   "points": 1,
   "twist": null
  },
  "solutions": {
   "untouched": [],
   "split": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "A",
      "B"
     ]
    }
   ],
   "split-and-twist": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "A",
      "B"
     ]
    },
    {
     "type": "twist",
     "col": 2,
     "rails": [
      "B"
     ],
     "steps": 2
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "04-dark-port",
  "name": "Dark port",
  "blurb": "Two quantum points in a row. Untouched, every train ends up on line B, where nobody waits: the ghosts meet and cancel on A. One twist changes how they meet.",
  "rails": [
   "A",
   "B"
  ],
  "columns": 4,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 2,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 4,
    "passengers": [
     "bubble",
     "cube",
     "octahedron",
     "bubble"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 4,
    "passengers": []
   }
  ],
  "supply": {
   "twist": 1
  },
  "solutions": {
   "untouched": [],
   "half-turn": [
    {
     "type": "twist",
     "col": 2,
     "rails": [
      "B"
     ],
     "steps": 4
    }
   ],
   "quarter-turn": [
    {
     "type": "twist",
     "col": 2,
     "rails": [
      "B"
     ],
     "steps": 2
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "05-quarter-turn",
  "name": "Quarter turn",
  "blurb": "An old tunnel on B already turns the train a quarter. Only the difference between the ghosts' rolls matters, and a twist can't be undone, only turned further. Send every car to B.",
  "rails": [
   "A",
   "B"
  ],
  "columns": 5,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "twist",
    "col": 2,
    "rails": [
     "B"
    ],
    "steps": 2
   },
   {
    "type": "points",
    "col": 4,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 5,
    "passengers": []
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 5,
    "passengers": [
     "cube",
     "bubble",
     "octahedron",
     "cube"
    ]
   }
  ],
  "supply": {
   "twist": 1
  },
  "solutions": {
   "untouched": [],
   "even-out": [
    {
     "type": "twist",
     "col": 3,
     "rails": [
      "A"
     ],
     "steps": 2
    }
   ],
   "full-turn": [
    {
     "type": "twist",
     "col": 3,
     "rails": [
      "B"
     ],
     "steps": 6
    }
   ],
   "half-turn": [
    {
     "type": "twist",
     "col": 3,
     "rails": [
      "B"
     ],
     "steps": 2
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "06-switchyard",
  "name": "Switchyard",
  "blurb": "Blocks only join neighbouring tracks. A crossover swaps two tracks, so ghosts can travel across the map. Serve A and D.",
  "rails": [
   "A",
   "B",
   "C",
   "D"
  ],
  "columns": 5,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   },
   {
    "col": 3,
    "rails": [
     "C",
     "D"
    ]
   },
   {
    "col": 4,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "fixed": [],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 5,
    "passengers": [
     "bubble",
     "cube"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 5,
    "passengers": []
   },
   {
    "id": "stop-c",
    "name": "Stop C",
    "rail": "C",
    "col": 5,
    "passengers": []
   },
   {
    "id": "stop-d",
    "name": "Stop D",
    "rail": "D",
    "col": 5,
    "passengers": [
     "octahedron",
     "bubble"
    ]
   }
  ],
  "supply": {
   "points": 1,
   "cross": 2
  },
  "solutions": {
   "untouched": [],
   "route": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "A",
      "B"
     ]
    },
    {
     "type": "cross",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    },
    {
     "type": "cross",
     "col": 3,
     "rails": [
      "C",
      "D"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "07-crossed-wires",
  "name": "Crossed wires",
  "blurb": "The dark port again, with one crossover to place. Swapping two ghosts that look the same changes nothing; changing what goes in or what comes out does.",
  "rails": [
   "A",
   "B"
  ],
  "columns": 6,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "col": 5,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 2,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 4,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 6,
    "passengers": [
     "bubble",
     "octahedron",
     "cube",
     "bubble"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 6,
    "passengers": []
   }
  ],
  "supply": {
   "cross": 1
  },
  "solutions": {
   "untouched": [],
   "middle": [
    {
     "type": "cross",
     "col": 3,
     "rails": [
      "A",
      "B"
     ]
    }
   ],
   "swap-in": [
    {
     "type": "cross",
     "col": 1,
     "rails": [
      "A",
      "B"
     ]
    }
   ],
   "swap-out": [
    {
     "type": "cross",
     "col": 5,
     "rails": [
      "A",
      "B"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "08-fair-shares",
  "name": "Fair shares",
  "blurb": "Two quantum points split the train three ways. Match the split to the passengers: one at A, two at B, one at C.",
  "rails": [
   "A",
   "B",
   "C"
  ],
  "columns": 4,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   },
   {
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "fixed": [],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 4,
    "passengers": [
     "bubble"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 4,
    "passengers": [
     "cube",
     "octahedron"
    ]
   },
   {
    "id": "stop-c",
    "name": "Stop C",
    "rail": "C",
    "col": 4,
    "passengers": [
     "bubble"
    ]
   }
  ],
  "supply": {
   "points": 2,
   "cross": 1
  },
  "solutions": {
   "untouched": [],
   "tempting": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "A",
      "B"
     ]
    },
    {
     "type": "points",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    }
   ],
   "fair": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "A",
      "B"
     ]
    },
    {
     "type": "points",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    },
    {
     "type": "cross",
     "col": 3,
     "rails": [
      "A",
      "B"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "09-grand-junction",
  "name": "Grand junction",
  "blurb": "The train spreads over four tracks and reunites. Untouched, every ghost meets on D. One twist spreads the train everywhere: you need a pattern of rolls to send it all to A.",
  "rails": [
   "A",
   "B",
   "C",
   "D"
  ],
  "columns": 8,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 4,
    "rails": [
     "A",
     "B",
     "C",
     "D"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "cross",
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "C",
     "D"
    ]
   },
   {
    "type": "points",
    "col": 5,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 5,
    "rails": [
     "C",
     "D"
    ]
   },
   {
    "type": "cross",
    "col": 6,
    "rails": [
     "B",
     "C"
    ]
   },
   {
    "type": "points",
    "col": 7,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 7,
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 8,
    "passengers": [
     "bubble",
     "cube",
     "octahedron",
     "bubble"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 8,
    "passengers": []
   },
   {
    "id": "stop-c",
    "name": "Stop C",
    "rail": "C",
    "col": 8,
    "passengers": []
   },
   {
    "id": "stop-d",
    "name": "Stop D",
    "rail": "D",
    "col": 8,
    "passengers": []
   }
  ],
  "supply": {
   "twist": 2
  },
  "solutions": {
   "untouched": [],
   "one": [
    {
     "type": "twist",
     "col": 4,
     "rails": [
      "B"
     ],
     "steps": 4
    }
   ],
   "pattern": [
    {
     "type": "twist",
     "col": 4,
     "rails": [
      "B"
     ],
     "steps": 4
    },
    {
     "type": "twist",
     "col": 4,
     "rails": [
      "C"
     ],
     "steps": 4
    }
   ],
   "pattern-outer": [
    {
     "type": "twist",
     "col": 4,
     "rails": [
      "A"
     ],
     "steps": 4
    },
    {
     "type": "twist",
     "col": 4,
     "rails": [
      "D"
     ],
     "steps": 4
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "10-nosy-inspector",
  "name": "Nosy inspector",
  "blurb": "The inspector on B has nobody to pick up, but it sees every train that passes. Knowing which way the train went destroys the interference. Get every car to B.",
  "rails": [
   "A",
   "B",
   "C"
  ],
  "columns": 6,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   },
   {
    "col": 3,
    "rails": [
     "A"
    ]
   },
   {
    "col": 4,
    "rails": [
     "B",
     "C"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 5,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "inspector",
    "name": "Inspector",
    "rail": "B",
    "col": 3,
    "passengers": []
   },
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 6,
    "passengers": []
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 6,
    "passengers": [
     "octahedron",
     "cube",
     "bubble",
     "octahedron"
    ]
   }
  ],
  "supply": {
   "cross": 2,
   "twist": 1
  },
  "solutions": {
   "untouched": [],
   "twist": [
    {
     "type": "twist",
     "col": 3,
     "rails": [
      "A"
     ],
     "steps": 4
    }
   ],
   "detour": [
    {
     "type": "cross",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    },
    {
     "type": "cross",
     "col": 4,
     "rails": [
      "B",
      "C"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "11-switch-both-ways",
  "name": "Switch both ways",
  "blurb": "When two ghosts meet at quantum points, the phase between them picks the exit: no difference sends the train one way, a half turn (π) the other. The second loop already has a π twist. Stop at A first, then at B.",
  "rails": [
   "A",
   "B"
  ],
  "columns": 8,
  "cars": 3,
  "dispatch": "sequential",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A"
   }
  ],
  "slots": [
   {
    "col": 2,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "col": 6,
    "rails": [
     "B"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 5,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "twist",
    "col": 6,
    "rails": [
     "A"
    ],
    "steps": 4
   },
   {
    "type": "points",
    "col": 7,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "first",
    "name": "Stop 1",
    "rail": "A",
    "col": 4,
    "passengers": [
     "bubble",
     "cube",
     "octahedron"
    ]
   },
   {
    "id": "second",
    "name": "Stop 2",
    "rail": "B",
    "col": 8,
    "passengers": [
     "cube",
     "bubble",
     "octahedron"
    ]
   }
  ],
  "supply": {
   "twist": null
  },
  "solutions": {
   "empty": [],
   "both-ways": [
    {
     "type": "twist",
     "col": 2,
     "rails": [
      "A"
     ],
     "steps": 4
    },
    {
     "type": "twist",
     "col": 6,
     "rails": [
      "B"
     ],
     "steps": 4
    }
   ],
   "first-only": [
    {
     "type": "twist",
     "col": 2,
     "rails": [
      "B"
     ],
     "steps": 4
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "12-remote-twist",
  "name": "Remote twist",
  "blurb": "Two trains leave together. Orange runs the dark port and ends on empty B. Teal never splits, it just rides on C. An interlock is a twist that only happens when a train is on each of its rails: use teal to turn orange's ghost on B.",
  "rails": [
   "A",
   "B",
   "C"
  ],
  "columns": 4,
  "cars": 3,
  "dispatch": "together",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A",
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "id": "teal",
    "colour": "#12a39b",
    "depot": "C",
    "rails": [
     "C"
    ]
   }
  ],
  "slots": [
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "stop-a",
    "name": "Stop A",
    "rail": "A",
    "col": 4,
    "passengers": [
     "bubble",
     "cube",
     "octahedron"
    ]
   },
   {
    "id": "stop-b",
    "name": "Stop B",
    "rail": "B",
    "col": 4,
    "passengers": []
   },
   {
    "id": "stop-c",
    "name": "Stop C",
    "rail": "C",
    "col": 4,
    "passengers": [
     "octahedron",
     "bubble",
     "cube"
    ]
   }
  ],
  "supply": {
   "interlock": 1
  },
  "solutions": {
   "untouched": [],
   "interlock": [
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "13-remote-switch",
  "name": "Remote switch",
  "blurb": "Same trick, but now split teal too. Wherever teal goes, orange follows its own way: the two trains end up entangled. Couples: A with C, B with D.",
  "rails": [
   "A",
   "B",
   "C",
   "D"
  ],
  "columns": 4,
  "cars": 4,
  "dispatch": "together",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A",
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "id": "teal",
    "colour": "#12a39b",
    "depot": "C",
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "slots": [
   {
    "col": 1,
    "rails": [
     "C",
     "D"
    ]
   },
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "A",
     "B"
    ]
   }
  ],
  "stations": [
   {
    "id": "a",
    "name": "Stop A",
    "rail": "A",
    "col": 4,
    "passengers": [
     "bubble",
     "bubble"
    ],
    "partner": "c"
   },
   {
    "id": "b",
    "name": "Stop B",
    "rail": "B",
    "col": 4,
    "passengers": [
     "cube",
     "cube"
    ],
    "partner": "d"
   },
   {
    "id": "c",
    "name": "Stop C",
    "rail": "C",
    "col": 4,
    "passengers": [
     "bubble",
     "bubble"
    ],
    "partner": "a"
   },
   {
    "id": "d",
    "name": "Stop D",
    "rail": "D",
    "col": 4,
    "passengers": [
     "cube",
     "cube"
    ],
    "partner": "b"
   }
  ],
  "supply": {
   "points": 1,
   "interlock": 1
  },
  "solutions": {
   "untouched": [],
   "interlock-only": [
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    }
   ],
   "split-only": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "C",
      "D"
     ]
    }
   ],
   "entangle": [
    {
     "type": "points",
     "col": 1,
     "rails": [
      "C",
      "D"
     ]
    },
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "14-entangled-couples",
  "name": "Entangled couples",
  "blurb": "Two trains leave together. Couples only travel together: bubbles wait at A and D, cubes at B and C. An interlock is a twist that only happens when a train is on each of its rails: it adds π to that branch alone, so teal's last points sends it one way or the other depending on where orange is.",
  "rails": [
   "A",
   "B",
   "C",
   "D"
  ],
  "columns": 4,
  "cars": 4,
  "dispatch": "together",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A",
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "id": "teal",
    "colour": "#12a39b",
    "depot": "C",
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "slots": [
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 1,
    "rails": [
     "C",
     "D"
    ]
   },
   {
    "type": "points",
    "col": 3,
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "stations": [
   {
    "id": "a",
    "name": "Stop A",
    "rail": "A",
    "col": 4,
    "passengers": [
     "bubble",
     "bubble"
    ],
    "partner": "d"
   },
   {
    "id": "b",
    "name": "Stop B",
    "rail": "B",
    "col": 4,
    "passengers": [
     "cube",
     "cube"
    ],
    "partner": "c"
   },
   {
    "id": "c",
    "name": "Stop C",
    "rail": "C",
    "col": 4,
    "passengers": [
     "cube",
     "cube"
    ],
    "partner": "b"
   },
   {
    "id": "d",
    "name": "Stop D",
    "rail": "D",
    "col": 4,
    "passengers": [
     "bubble",
     "bubble"
    ],
    "partner": "a"
   }
  ],
  "supply": {
   "interlock": 1
  },
  "solutions": {
   "independent": [],
   "entangled": [
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    }
   ]
  }
 },
 {
  "format": "quantrain-level/1",
  "id": "15-swap-partners",
  "name": "Swap partners",
  "blurb": "Entangled couples again, but this time the bubbles wait at A and C, the cubes at B and D. The interlock pairs A with D. One more twist on teal changes who meets whom.",
  "rails": [
   "A",
   "B",
   "C",
   "D"
  ],
  "columns": 5,
  "cars": 4,
  "dispatch": "together",
  "trains": [
   {
    "id": "orange",
    "colour": "#f2683a",
    "depot": "A",
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "id": "teal",
    "colour": "#12a39b",
    "depot": "C",
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "slots": [
   {
    "col": 2,
    "rails": [
     "B",
     "C"
    ]
   },
   {
    "col": 3,
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "fixed": [
   {
    "type": "points",
    "col": 1,
    "rails": [
     "A",
     "B"
    ]
   },
   {
    "type": "points",
    "col": 1,
    "rails": [
     "C",
     "D"
    ]
   },
   {
    "type": "points",
    "col": 4,
    "rails": [
     "C",
     "D"
    ]
   }
  ],
  "stations": [
   {
    "id": "a",
    "name": "Stop A",
    "rail": "A",
    "col": 5,
    "passengers": [
     "bubble",
     "bubble"
    ],
    "partner": "c"
   },
   {
    "id": "b",
    "name": "Stop B",
    "rail": "B",
    "col": 5,
    "passengers": [
     "cube",
     "cube"
    ],
    "partner": "d"
   },
   {
    "id": "c",
    "name": "Stop C",
    "rail": "C",
    "col": 5,
    "passengers": [
     "bubble",
     "bubble"
    ],
    "partner": "a"
   },
   {
    "id": "d",
    "name": "Stop D",
    "rail": "D",
    "col": 5,
    "passengers": [
     "cube",
     "cube"
    ],
    "partner": "b"
   }
  ],
  "supply": {
   "interlock": 1,
   "twist": 1
  },
  "solutions": {
   "untouched": [],
   "interlock-only": [
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    }
   ],
   "swap": [
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    },
    {
     "type": "twist",
     "col": 3,
     "rails": [
      "D"
     ],
     "steps": 4
    }
   ],
   "swap-c": [
    {
     "type": "interlock",
     "col": 2,
     "rails": [
      "B",
      "C"
     ]
    },
    {
     "type": "twist",
     "col": 3,
     "rails": [
      "C"
     ],
     "steps": 4
    }
   ]
  }
 }
];
const LEVELS = LEVEL_FILES.map(parseLevel);

const H           = 1.6;    // rail height (the train rolls around and under it)
const COL         = 3.2;    // world units per column (one column = one circuit time step)
const RAIL_GAP    = 3.6;    // distance between neighbouring rails
const TWIST_LEN   = 1.6;    // distance over which a twist rolls the train
const PAIR_LEN    = COL * 0.92;   // length of points / crossovers
const DIAL_R      = 1.1;
const TRAIN_SCALE = 1.45;
const PLATFORM    = { len: 2.8, width: 1.5, top: H - 0.18, gap: 1.05 };   // gap = rail to platform edge (clears the rolling train)
const CAMERA      = { elevationDeg: 34, azimuthDeg: 24, portraitAzimuthDeg: 64, maxZoom: 5 };

// ───────────────────────── helpers ─────────────────────────
const FRACS = ['0', 'π/4', 'π/2', '3π/4', 'π', '5π/4', '3π/2', '7π/4'];
function fmtPhase(phi) {
  const t = ((phi / PI) % 2 + 2) % 2, q = t * 4, k = Math.round(q);
  return Math.abs(q - k) < 0.03 ? FRACS[k % 8] : t.toFixed(2) + 'π';
}
function fmtAngle(x) {                            // circuit labels: π fractions when exact
  const q = x / (PI / 4), k = Math.round(q);
  if (Math.abs(q - k) < 1e-9 && k >= 0 && k <= 8) return k === 8 ? '2π' : FRACS[k];
  return x.toFixed(3);
}
// Timers go through window.*: Qollab injects its own promise-returning setTimeout into project code.
const clamp01 = v => Math.min(1, Math.max(0, v));
const smooth = v => v * v * (3 - 2 * v);
const easeInOut = v => 0.5 - 0.5 * Math.cos(PI * v);
const lerp = (a, b, u) => a + (b - a) * u;
const css = name => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// ───────────────────────── renderer, scene, materials ─────────────────────────
const stage = document.getElementById('stage');
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
stage.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 200);

const themed = [];
function tmat(token, opts = {}) {
  const m = opts.line ? new THREE.LineBasicMaterial(opts.params) : new THREE.MeshBasicMaterial(opts.params);
  themed.push({ mat: m, token });
  return m;
}
const glass = opacity => ({ params: { transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide } });
const mat = {
  ground: tmat('--ground'), rail: tmat('--rail'), shadow: tmat('--rail-shadow'),
  tunnel: tmat('--tunnel'), stationFill: tmat('--station-fill'), window: tmat('--window'),
  dialFill: tmat('--tunnel', glass(0.06)), dialSector: tmat('--tunnel', glass(0.22)), dialRing: tmat('--tunnel', glass(0.45)),
  interlock: tmat('--interlock'),
  splitGlass: tmat('--tunnel', glass(0.14)), splitPlate: tmat('--tunnel', glass(0.35)), splitEdge: tmat('--tunnel', { line: true }),
  // build slots: a pad under the rail(s); idle = empty spot, ok = the dragged block fits, hot = it will snap here, off = it doesn't fit
  slot: {
    idle: [tmat('--muted', glass(0.10)), tmat('--muted', glass(0.55))],
    ok:   [tmat('--tunnel', glass(0.14)), tmat('--tunnel', glass(0.8))],
    hot:  [tmat('--tunnel', glass(0.34)), tmat('--tunnel', glass(1))],
    off:  [tmat('--muted', glass(0.03)), tmat('--muted', glass(0.14))],
  },
  preview: tmat('--tunnel', glass(0.4)), previewLine: tmat('--tunnel', { line: true, params: { transparent: true, opacity: 0.7 } }),
};
const matPainted = new THREE.MeshBasicMaterial({ vertexColors: true });

const painted = [];
const shade = { top: 0.32 };
const WHITE = new THREE.Color('#ffffff'), BLACK = new THREE.Color('#000000');
function paintable(geometry, token, rule = null, level = true) {
  const geo = geometry.index ? geometry.toNonIndexed() : geometry;
  geo.computeVertexNormals();
  geo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(geo.attributes.position.count * 3), 3));
  const entry = { geo, token, rule, level };
  painted.push(entry);
  repaint(entry);
  return geo;
}
const shaded = (geometry, token, rule, level) => new THREE.Mesh(paintable(geometry, token, rule, level), matPainted);
function repaint({ geo, token, rule }) {
  const base = new THREE.Color(token.startsWith('#') ? token : css(token));
  const n = geo.attributes.normal, p = geo.attributes.position, c = geo.attributes.color, col = new THREE.Color();
  for (let i = 0; i < n.count; i += 3) {
    const nx = (n.getX(i) + n.getX(i + 1) + n.getX(i + 2)) / 3;
    const ny = (n.getY(i) + n.getY(i + 1) + n.getY(i + 2)) / 3;
    const cy = (p.getY(i) + p.getY(i + 1) + p.getY(i + 2)) / 3;
    const custom = rule && rule(nx, ny, cy);
    if (custom) col.copy(custom);
    else {
      col.copy(base);
      if (ny > 0) col.lerp(WHITE, shade.top * ny); else col.lerp(BLACK, 0.28 * -ny);
      col.lerp(BLACK, 0.06 * Math.abs(nx));
    }
    for (let k = 0; k < 3; k++) c.setXYZ(i + k, col.r, col.g, col.b);
  }
  c.needsUpdate = true;
}

const ground = new THREE.Mesh(new THREE.PlaneGeometry(160, 80), mat.ground);
ground.rotation.x = -PI / 2;
scene.add(ground);
const grid = new THREE.GridHelper(160, 160);
grid.position.y = 0.001;
scene.add(grid);

// ───────────────────────── the quantrains (one ghost per train per rail) ─────────────────────────
// Local frame: +x = forward along the rail, +y = "up" away from the rail (rolls with phase), z = sideways.
// Every car is the same box with flat, slightly rounded ends (like a DSB set): no front or back.
const bodyShape = new THREE.Shape();
bodyShape.moveTo(-0.9, 0);
bodyShape.lineTo(0.9, 0);
bodyShape.quadraticCurveTo(1.0, 0, 1.0, 0.1);
bodyShape.lineTo(1.0, 0.34);
bodyShape.quadraticCurveTo(1.0, 0.44, 0.9, 0.44);
bodyShape.lineTo(-0.9, 0.44);
bodyShape.quadraticCurveTo(-1.0, 0.44, -1.0, 0.34);
bodyShape.lineTo(-1.0, 0.1);
bodyShape.quadraticCurveTo(-1.0, 0, -0.9, 0);
const bodyExtrude = new THREE.ExtrudeGeometry(bodyShape, {
  depth: 0.38, curveSegments: 6, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.06, bevelSegments: 3,
});
bodyExtrude.translate(0, 0, -0.19);
const bandGeo = new THREE.ExtrudeGeometry(roundRect(2.13, 0.51, 0.09), { depth: 0.11, bevelEnabled: false, curveSegments: 5 });
bandGeo.rotateX(-PI / 2).translate(0, -0.055, 0);  // a window band that follows the rounded corners round both ends
const hangerGeo = new THREE.BoxGeometry(0.3, 0.14, 0.18);

const bodyGeos = new Map(), palettes = [];      // one painted body per train colour
function bodyGeoFor(hex) {
  if (bodyGeos.has(hex)) return bodyGeos.get(hex);
  const entry = { pal: null };
  palettes.push(entry);
  const pal = () => entry.pal ?? (entry.pal = {
    side: new THREE.Color(hex), roof: new THREE.Color(hex).lerp(WHITE, 0.62), nose: new THREE.Color(hex).lerp(WHITE, 0.2),
    back: new THREE.Color(hex).lerp(BLACK, 0.18), belly: new THREE.Color(css('--belly')), window: new THREE.Color(css('--window')),
  });
  const out = new THREE.Color(), ramp = (a, b, v) => Math.min(1, Math.max(0, (v - a) / (b - a)));
  const geo = paintable(bodyExtrude.clone(), '--train', (nx, ny) => {   // blend by the facet's normal: rounded edges shade smoothly
    const P = pal();
    out.copy(P.side).lerp(P.nose, ramp(0.2, 0.9, Math.abs(nx)));
    if (ny > 0) out.lerp(P.roof, ramp(0.25, 0.85, ny)); else out.lerp(P.belly, ramp(0.25, 0.85, -ny));
    return out;
  }, false);
  bodyGeos.set(hex, geo);
  return geo;
}

function makeGhost(train) {
  const mats = {
    body: new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true }),
    window: tmat('--window', { params: { transparent: true } }),
    belly: tmat('--belly', { params: { transparent: true } }),
  };
  mats.window.color.set(css('--window')); mats.belly.color.set(css('--belly'));
  const root = new THREE.Group(), yaw = new THREE.Group(), roll = new THREE.Group();
  root.add(yaw); yaw.add(roll);
  roll.scale.setScalar(TRAIN_SCALE);
  const body = new THREE.Mesh(bodyGeoFor(train.colour), mats.body);
  body.position.y = 0.16;
  const band = new THREE.Mesh(bandGeo, mats.window);
  band.position.set(0, 0.16 + 0.27, 0);
  roll.add(body, band);
  for (const x of [-0.55, 0.45]) {             // two hangers that clamp the train to the rail
    const hanger = new THREE.Mesh(hangerGeo, mats.belly);
    hanger.position.set(x, 0.08, 0);
    roll.add(hanger);
  }
  const halo = new THREE.Group();               // entangled: a ring of branch colours around the ghost (does not roll)
  halo.rotation.x = -PI / 2;
  halo.position.y = -0.02;
  halo.scale.set(1.55, 1, 1);
  root.add(halo);
  root.visible = false;
  scene.add(root);
  const label = { el: document.createElement('div'), world: new THREE.Vector3(), anchorY: -1 };
  label.el.className = 'lbl phase';
  label.el.style.boxShadow = `0 0 0 2px ${train.colour}`;
  label.el.hidden = true;
  document.getElementById('labels').appendChild(label.el);
  const g = { root, yaw, roll, mats, label, halo, haloKey: '' };
  g.setOpacity = o => { for (const m of Object.values(mats)) m.opacity = o; };
  return g;
}
const ghosts = new Map();                      // `${train.id}:${rail index}:${car}` → ghost (created when first needed)
function ghostFor(train, r, car = 0) {
  const key = `${train.id}:${r}:${car}`;
  if (!ghosts.has(key)) ghosts.set(key, makeGhost(train));
  return ghosts.get(key);
}
function hideGhosts(except = new Set()) {
  for (const g of ghosts.values()) if (!except.has(g)) { g.root.visible = false; g.label.el.hidden = true; }
}

// ───────────────────────── level building ─────────────────────────
const SHAPES = {
  bubble:     () => new THREE.IcosahedronGeometry(0.19, 2),
  cube:       () => new THREE.BoxGeometry(0.3, 0.3, 0.3),
  octahedron: () => new THREE.OctahedronGeometry(0.24, 0),
};
const dialBasis = new THREE.Matrix4().makeBasis(new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 1), new THREE.Vector3(1, 0, 0));

const pickGroup = new THREE.Group();            // invisible hit boxes, one per rail component
scene.add(pickGroup);
const hitMat = new THREE.MeshBasicMaterial({ visible: false });
function registerPick(center, size, labels, place = null) {
  const box = new THREE.Mesh(new THREE.BoxGeometry(size.x, size.y, size.z), hitMat);
  box.position.copy(center);
  box.userData.pick = { labels, place };      // place = the player's placement (can be dragged / tapped)
  for (const l of labels) l.el.hidden = true;
  pickGroup.add(box);
}
let L = null, levelIndex = 0, build = [], levelGroup = null, levelLabels = [], rulerLabels = [];
let placements = [];                            // the player's build: [{ type, col, rails, steps? }], edited by drag and drop
let cellObjs = [];                              // one pad per build cell
let anim = [];                                  // animation ops: one per element, with an x range
let stationObjs = [];
const colX = c => (c - (L.columns + 1) / 2) * COL;
const railZ = k => (k - (L.rails.length - 1) / 2) * RAIL_GAP;
const zOf = r => railZ(L.railIndex(r));
const depotX = () => colX(0);
const exitX = () => colX(L.columns + 1);

function addLabel(className, html, world, anchorY = -0.5, list = levelLabels) {
  const el = document.createElement('div');
  el.className = 'lbl ' + className;
  el.innerHTML = html;
  document.getElementById('labels').appendChild(el);
  const l = { el, world, anchorY };
  list.push(l);
  return l;
}

// ── the player's build: saved per level in this browser; ?level=N&solution=name loads an example build (tests, demo video)
const params = new URLSearchParams(location.search);
const seeded = new Set();
const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked: the build lives for this visit only */ } },
};
const storeKey = () => `quantrain:build:${L.id}`;
function legal(list) { try { layout(L, list); return true; } catch { return false; } }
function loadPlacements() {
  const sol = params.get('solution');
  if (sol && L.solutions[sol] && !seeded.has(L.id)) { seeded.add(L.id); return L.solutions[sol].map(p => ({ ...p })); }
  const saved = store.get(storeKey());
  return Array.isArray(saved) && legal(saved) ? saved : [];
}
const cellKey = (col, rail) => `${col}/${rail}`;
const sameSpot = (a, b) => a.col === b.col && ordered(L, a.rails).join() === ordered(L, b.rails).join();

let mode = 'level';                             // 'level' | 'playground' | 'puzzle' (a community puzzle)
function buildLevel(index) {
  mode = 'level';
  puzzleCtx = null;
  setMaker(false);
  document.body.classList.remove('playground', 'puzzle', 'puzzle-test');
  levelIndex = index;
  L = LEVELS[index];
  placements = loadPlacements();
  document.getElementById('title').textContent = `${index + 1}. ${L.name}`;
  document.getElementById('blurb').textContent = L.blurb;
  document.getElementById('back').textContent = '‹ Levels';
  document.getElementById('prev-level').disabled = index === 0;
  document.getElementById('next-level').disabled = index === LEVELS.length - 1;
  setupPalette();
  rebuild();
  applyTheme();
  fit();
}

// Rebuild the scene from level + placements (after every edit). The camera stays where it is.
function rebuild() {
  if (levelGroup) {
    scene.remove(levelGroup);
    levelGroup.traverse(o => o.geometry && o.geometry.dispose());
  }
  for (const l of [...levelLabels, ...rulerLabels, ...hintLabels]) l.el.remove();
  for (const b of [...pickGroup.children]) { pickGroup.remove(b); b.geometry.dispose(); }
  hovered = null;
  levelLabels = []; rulerLabels = []; hintLabels = [];
  for (let i = painted.length - 1; i >= 0; i--) if (painted[i].level) painted.splice(i, 1);

  build = layout(L, placements);
  shotStats = new Map();                           // a new build: old shots no longer apply

  const G = levelGroup = new THREE.Group();
  scene.add(G);
  const x0 = depotX() - 1.6, x1 = exitX() + 1.0;
  const zs = L.rails.map((_, k) => railZ(k));
  const zMin = Math.min(...zs);

  // rails, ground shadows, terminus bars
  for (const z of zs) {
    const len = x1 - x0, mid = (x0 + x1) / 2;
    const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, len, 16), mat.rail);
    rail.rotation.z = PI / 2;
    rail.position.set(mid, H, z);
    const sh = new THREE.Mesh(new THREE.PlaneGeometry(len, 0.16), mat.shadow);
    sh.rotation.x = -PI / 2;
    sh.position.set(mid, 0.003, z);
    G.add(rail, sh);
    for (const x of [x0, x1]) {
      const bar = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.9), mat.rail);
      bar.position.set(x, H, z);
      G.add(bar);
    }
  }

  // depots (Mini-Metro squares), one per train depot rail
  for (const r of new Set(L.trains.map(t => t.depot))) {
    for (const [size, m, y] of [[1.2, mat.rail, H - 0.11], [0.86, mat.stationFill, H - 0.1]]) {   // a square sitting on the rail
      const sq = new THREE.Mesh(new THREE.BoxGeometry(size, 0.05, size), m);
      sq.position.set(depotX(), y, zOf(r));
      G.add(sq);
    }
    const trainsHere = L.trains.filter(t => t.depot === r).map(t => t.id).join(', ');
    const pgTrain = mode === 'playground' && L.trains.length > 1 ? pg.trains.find(t => t.rail === r) : null;   // the last train stays
    registerPick(new THREE.Vector3(depotX(), H, zOf(r)), new THREE.Vector3(1.8, 1.4, 1.8),
      [addLabel('tag', `depot<b>${esc(trainsHere)}</b>` + (pgTrain ? '<em>drag to move · off the line to remove</em>' : ''), new THREE.Vector3(depotX(), H + 0.9, zOf(r)), -1)],
      pgTrain ? { type: 'train', slot: pgTrain.slot, rail: r } : null);
  }
  for (const z of zs) registerPick(new THREE.Vector3(x1 - 0.4, H, z), new THREE.Vector3(1.4, 1.2, 1.4),
    [addLabel('tag', 'exit', new THREE.Vector3(x1, H + 0.7, z), -1)]);

  // build slots: a pad under the rail(s)
  cellObjs = L.slots.flatMap(s => s.rails.map(r => buildCellPad(G, s.col, r)));
  if (mode === 'playground') cellObjs.push(...L.rails.map(r => buildCellPad(G, 0, r)));   // depots, for placing trains

  // elements → scene objects + animation ops
  anim = [];
  for (const el of build) {
    const place = el.fixed ? null : placements.find(p => sameSpot(p, el));
    anim.push(buildElement(G, el, place));
  }
  anim.sort((a, b) => a.start - b.start);

  // stations
  stationObjs = L.stations.map(st => buildStation(G, st));

  // column ruler (shown with the circuit panel): same names as the circuit's barriers
  for (let c = 1; c <= L.columns; c++) {
    const l = addLabel('ruler', `c${c}`, new THREE.Vector3(colX(c), H + DIAL_R + 0.9, zMin), -0.5, rulerLabels);
    l.el.hidden = hood.hidden;
  }

  showSlots();
  updatePalette();
  hideGhosts();
  resetRun();
  if (!hood.hidden) renderHood();
}

const LOCK_ICON = '<svg class="lock" width="11" height="11" viewBox="0 0 24 24" aria-label="fixed"><rect x="4" y="10" width="16" height="12" rx="2.5" fill="currentColor"/><path d="M8 10V7a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="3"/></svg>';
// One element → scene objects (+ its hover label and hit box unless it is a preview). Returns its animation op.
function buildElement(G, el, place = null, preview = false) {
  const x = colX(el.col);
  const tag = (html, world) => {
    if (preview) return [];
    const hint = el.fixed ? '' : el.type === 'twist' ? '<em>tap to turn · drag to move</em>' : '<em>drag to move · off the line to remove</em>';
    return [addLabel('tag', (el.fixed ? LOCK_ICON + 'fixed ' : '') + html + hint, world, -1)];
  };
  const pick = (center, size, labels) => { if (!preview) registerPick(center, size, labels, place); };
  if (el.type === 'twist') {
    const op = { el, x, start: x - TWIST_LEN / 2, len: TWIST_LEN, dphi: phiOf(el) };
    const z = zOf(el.rails[0]);
    buildDial(G, op, z);
    pick(new THREE.Vector3(x, H, z), new THREE.Vector3(0.9, 2.8, 2.8),
      tag(`twist<b>+${fmtPhase(op.dphi)}</b>`, new THREE.Vector3(x, H + DIAL_R + 0.5, z)));
    return op;
  }
  const z1 = zOf(el.rails[0]), z2 = zOf(el.rails[1]);
  if (el.type === 'interlock') {
    const op = { el, x, start: x - TWIST_LEN / 2, len: TWIST_LEN };
    buildInterlock(G, op, z1, z2);
    pick(new THREE.Vector3(x, H, (z1 + z2) / 2), new THREE.Vector3(1.0, 1.2, Math.abs(z2 - z1) + 1.0),
      tag('interlock<b>CZ: phase π if a train is on each rail</b>', new THREE.Vector3(x, H + 0.6, (z1 + z2) / 2)));
    return op;
  }
  const op = { el, x, start: x - PAIR_LEN / 2, len: PAIR_LEN };
  buildCrossover(G, op, z1, z2, el.type === 'points');
  if (el.type === 'points' && !preview) {
    op.hint = addLabel('hint', '', new THREE.Vector3(x, H - 0.55, (z1 + z2) / 2), 0, hintLabels);
    op.hint.el.hidden = true;
  }
  pick(new THREE.Vector3(x, H, (z1 + z2) / 2), new THREE.Vector3(PAIR_LEN, 1.4, Math.abs(z2 - z1) + 1.2),
    tag(el.type === 'points' ? `quantum points<b>${el.stay} : ${100 - el.stay}</b>` : 'cross', new THREE.Vector3(x, H + 1.0, (z1 + z2) / 2)));
  return op;
}

function roundRect(w, d, r) {
  const s = new THREE.Shape(), x = -w / 2, y = -d / 2;
  s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
  s.lineTo(x + w, y + d - r); s.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
  s.lineTo(x + r, y + d); s.quadraticCurveTo(x, y + d, x, y + d - r);
  s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y);
  return s;
}
function buildCellPad(G, col, rail) {          // a build cell: a pad under the rail
  const zc = zOf(rail), w = 1.8, d = 1.8, r = 0.42, rim = 0.11;
  const ring = roundRect(w, d, r);
  ring.holes.push(roundRect(w - 2 * rim, d - 2 * rim, r - rim));
  const fill = new THREE.Mesh(new THREE.ShapeGeometry(roundRect(w, d, r), 6), mat.slot.idle[0]);
  const edge = new THREE.Mesh(new THREE.ShapeGeometry(ring, 6), mat.slot.idle[1]);
  const pad = new THREE.Group();
  pad.add(fill, edge);
  pad.rotation.x = -PI / 2;
  pad.position.set(colX(col), H - 0.16, zc);
  G.add(pad);
  return { col, rail, key: cellKey(col, rail), pad, fill, edge };
}

// A twist dial: a faint disc with a thin ring; the coloured arc and sector show the twist still to come.
// The crosshair "lens" (needle + a dot for every π/4) is one piece that turns with the train.
// Arc and sector are fixed-size buffers updated in place: no allocations while the train rolls.
const ARC_SEGS = 48;
function arcBuffers() {
  const sector = new THREE.BufferGeometry(), band = new THREE.BufferGeometry();
  sector.setAttribute('position', new THREE.BufferAttribute(new Float32Array((ARC_SEGS + 2) * 3), 3));
  band.setAttribute('position', new THREE.BufferAttribute(new Float32Array((ARC_SEGS + 1) * 6), 3));
  const si = [], bi = [];
  for (let k = 0; k < ARC_SEGS; k++) {
    si.push(0, k + 1, k + 2);
    const a = 2 * k, b = 2 * k + 1, c = 2 * k + 2, d = 2 * k + 3;
    bi.push(a, c, b, b, c, d);
  }
  sector.setIndex(si); band.setIndex(bi);
  return { sector, band };
}
function shapeArc(op, start, len) {
  const sp = op.sector.geometry.attributes.position, bp = op.arc.geometry.attributes.position;
  sp.setXYZ(0, 0, 0, 0);
  for (let k = 0; k <= ARC_SEGS; k++) {
    const a = start + len * k / ARC_SEGS, c = Math.cos(a), s = Math.sin(a);
    sp.setXYZ(k + 1, c * DIAL_R, s * DIAL_R, 0);
    bp.setXYZ(2 * k, c * (DIAL_R - 0.055), s * (DIAL_R - 0.055), 0);
    bp.setXYZ(2 * k + 1, c * (DIAL_R + 0.055), s * (DIAL_R + 0.055), 0);
  }
  sp.needsUpdate = true; bp.needsUpdate = true;
}
function buildDial(G, op, z) {
  const dial = new THREE.Group();
  dial.position.set(op.x, H, z);
  dial.quaternion.setFromRotationMatrix(dialBasis);
  dial.add(new THREE.Mesh(new THREE.CircleGeometry(DIAL_R, 64), mat.dialFill));
  dial.add(new THREE.Mesh(new THREE.TorusGeometry(DIAL_R, 0.018, 6, 96), mat.dialRing));
  const end = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 8), mat.tunnel);   // where the twist ends
  end.position.set(Math.cos(op.dphi) * DIAL_R, Math.sin(op.dphi) * DIAL_R, 0);
  dial.add(end);
  const { sector: sg, band: bg } = arcBuffers();
  const sector = new THREE.Mesh(sg, mat.dialSector), arc = new THREE.Mesh(bg, mat.tunnel);
  sector.frustumCulled = arc.frustumCulled = false;
  const lens = new THREE.Group();               // turns as one piece
  const needle = new THREE.Mesh(new THREE.BoxGeometry(DIAL_R + 0.32, 0.06, 0.06), mat.rail);
  needle.position.x = (DIAL_R + 0.32) / 2;
  lens.add(needle);
  for (let k = 0; k < 8; k++) {
    const a = k * PI / 4;
    const dot = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.075, 0.075), mat.rail);
    dot.position.set(Math.cos(a) * (DIAL_R + 0.13), Math.sin(a) * (DIAL_R + 0.13), 0);
    dot.rotation.z = a;
    lens.add(dot);
  }
  dial.add(sector, arc, lens);
  G.add(dial);
  Object.assign(op, { sector, arc, lens, shown: null });
  setDial(op, 0);
}
function setDial(op, cur) {
  if (op.shown !== null && Math.abs(op.shown - cur) < 1e-4) return;
  op.shown = cur;
  op.lens.rotation.z = cur;
  const len = Math.abs(op.dphi - cur);
  op.arc.visible = op.sector.visible = len > 1e-3;
  if (len > 1e-3) shapeArc(op, Math.min(cur, op.dphi), len);
}

const linkGeo = new THREE.TorusGeometry(0.1, 0.03, 6, 14).scale(1.6, 1, 1);
function buildInterlock(G, op, z1, z2) {         // a chain between the two rails, anchored with a big dot on each
  for (const z of [z1, z2]) {
    const dot = new THREE.Mesh(new THREE.SphereGeometry(0.27, 20, 14), mat.interlock);
    dot.position.set(op.x, H, z);
    G.add(dot);
  }
  const zA = Math.min(z1, z2) + 0.24, zB = Math.max(z1, z2) - 0.24;
  const pitch = 0.27, n = Math.max(2, Math.round((zB - zA) / pitch));
  const along = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -PI / 2);   // link's long axis → z
  for (let i = 0; i < n; i++) {
    const link = new THREE.Mesh(linkGeo, mat.interlock);
    link.position.set(op.x, H, zA + (i + 0.5) * (zB - zA) / n);
    const twist = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), (i % 2) * PI / 2);
    link.quaternion.multiplyQuaternions(twist, along);   // every other link turned 90° around the chain
    G.add(link);
  }
}

const crossZ = (zFrom, zTo, u) => zFrom + (zTo - zFrom) * smooth(clamp01(u));
function buildCrossover(G, op, z1, z2, withSplitter) {
  for (const [a, b] of [[z1, z2], [z2, z1]]) {
    const pts = Array.from({ length: 33 }, (_, i) => new THREE.Vector3(op.start + op.len * i / 32, H, crossZ(a, b, i / 32)));
    G.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 64, 0.07, 10), mat.rail));
  }
  if (!withSplitter) return;
  const cube = new THREE.Group();
  cube.position.set(op.x, H, (z1 + z2) / 2);
  const box = new THREE.BoxGeometry(0.95, 0.95, 0.95);
  cube.add(new THREE.Mesh(box, mat.splitGlass));
  cube.add(new THREE.LineSegments(new THREE.EdgesGeometry(box), mat.splitEdge));
  const plate = new THREE.Mesh(new THREE.PlaneGeometry(0.95 * Math.SQRT2, 0.95), mat.splitPlate);
  plate.rotation.y = PI / 4;
  cube.add(plate);
  G.add(cube);
}

// Couples (stations that name each other) wait in a shared colour: pink first, then others.
const COUPLE_COLOURS = ['#ff4f9a', '#ffaa1f', '#2aa8ff', '#5fcf5a'];
function coupleColour(st) {
  if (!st.partner) return null;
  const pairs = [];
  for (const s of L.stations) if (s.partner) { const k = [s.id, s.partner].sort().join('|'); if (!pairs.includes(k)) pairs.push(k); }
  return COUPLE_COLOURS[pairs.indexOf([st.id, st.partner].sort().join('|')) % COUPLE_COLOURS.length];
}
function buildStation(G, st) {
  const k = L.railIndex(st.rail), n = L.rails.length, z = railZ(k), sx = colX(st.col);
  const sides = n === 1 ? ['front', 'back'] : [k === 0 ? 'back' : 'front'];
  const waitOn = sides[0];
  const decorOn = sides.includes('back') && n === 1 ? 'back' : waitOn;
  const sign = s => (s === 'front' ? 1 : -1);
  const zAt = (side, depth) => z + sign(side) * (PLATFORM.gap + depth);   // depth 0 = edge next to the rail
  const top = PLATFORM.top;
  for (const side of sides) {                    // a slab at rail level on slim pillars
    const slab = shaded(new THREE.BoxGeometry(PLATFORM.len, 0.22, PLATFORM.width), '--platform');
    slab.position.set(sx, top - 0.11, zAt(side, PLATFORM.width / 2));
    G.add(slab);
    for (const px of [-PLATFORM.len / 2 + 0.3, PLATFORM.len / 2 - 0.3]) {
      const pillar = shaded(new THREE.BoxGeometry(0.16, top - 0.22, 0.16), '--platform');
      pillar.position.set(sx + px, (top - 0.22) / 2, zAt(side, PLATFORM.width / 2));
      G.add(pillar);
      const zp = zAt(side, PLATFORM.width / 2), link = new THREE.Mesh(new THREE.PlaneGeometry(0.16, Math.abs(zp - z)), mat.shadow);
      link.rotation.x = -PI / 2;                   // a strip on the ground from the rail's line to the pillar
      link.position.set(sx + px, 0.003, (z + zp) / 2);
      G.add(link);
    }
  }
  // small triangles along the platform edge, pointing at the platform's rail
  const tri = new THREE.Shape();
  tri.moveTo(-0.12, 0); tri.lineTo(0.12, 0); tri.lineTo(0, 0.2); tri.closePath();
  for (const side of sides) for (const dx of [-0.9, 0, 0.9]) {
    const t = new THREE.Mesh(new THREE.ShapeGeometry(tri), mat.rail);
    t.rotation.set(-PI / 2, 0, side === 'front' ? 0 : PI);     // local +y → toward the rail
    t.position.set(sx + dx, top + 0.006, zAt(side, 0.08));
    G.add(t);
  }
  // a little house and a tree standing on the platform (away from the edge, at the ends)
  const alone = decorOn !== waitOn;
  const house = new THREE.Group();
  const walls = shaded(new THREE.BoxGeometry(0.9, 0.58, 0.56), '--building');
  walls.position.y = 0.29;
  const roof = shaded(new THREE.CylinderGeometry(0.4, 0.4, 1.0, 3, 1), '--roof');
  roof.rotation.set(-PI / 2, 0, PI / 2);
  roof.position.y = 0.58 + 0.19;
  roof.scale.set(1, 1, 0.8);
  const door = new THREE.Mesh(new THREE.PlaneGeometry(0.18, 0.3), mat.window);
  door.position.set(0.18, 0.15, 0.281);           // faces the camera
  house.add(walls, roof, door);
  house.position.set(alone ? sx + 0.5 : sx + PLATFORM.len / 2 - 0.55, top, zAt(decorOn, alone ? 0.75 : 1.05));
  const tree = new THREE.Group();
  const trunk = shaded(new THREE.BoxGeometry(0.1, 0.36, 0.1), '--trunk');
  trunk.position.y = 0.18;
  const crownA = shaded(new THREE.IcosahedronGeometry(0.33, 0), '--leaf');
  crownA.position.y = 0.58;
  const crownB = shaded(new THREE.IcosahedronGeometry(0.24, 0), '--leaf');
  crownB.position.set(0.1, 0.84, 0.04);
  tree.add(trunk, crownA, crownB);
  tree.position.set(alone ? sx - 0.75 : sx - PLATFORM.len / 2 + 0.35, top, zAt(decorOn, alone ? 0.75 : 1.05));
  G.add(house, tree);

  const waitZ = zAt(waitOn, 0.32);                 // passengers wait at the platform edge
  const passengers = st.passengers.map((kind, i, all) => {
    const mesh = shaded(SHAPES[kind](), coupleColour(st) ?? '--passenger');
    const home = new THREE.Vector3(sx - 0.15 + (i - (all.length - 1) / 2) * 0.45, top + 0.24, waitZ);
    mesh.position.copy(home);
    G.add(mesh);
    return { mesh, home, state: 'waiting', t0: 0 };
  });
  const label = addLabel('tag stop', '', new THREE.Vector3(sx, top + 1.5, zAt(waitOn, PLATFORM.width / 2)), -1);
  for (const side of sides) {
    registerPick(new THREE.Vector3(sx, top / 2 + 0.3, zAt(side, PLATFORM.width / 2)), new THREE.Vector3(PLATFORM.len, top + 1.2, PLATFORM.width), [label],
      mode === 'playground' ? { type: 'station', col: st.col, rail: st.rail } : null);
  }
  return { st, k, passengers, label };
}

// ───────────────────────── labels ─────────────────────────
const v = new THREE.Vector3();
let hintLabels = [];                             // one per quantum points: phase difference → exit rail
function placeLabel(l, w, h) {
  v.copy(l.world).project(camera);
  l.sx = (v.x + 1) / 2 * w; l.sy = (1 - v.y) / 2 * h;
  l.el.style.transform = `translate(${l.sx}px, ${l.sy}px) translate(-50%, ${l.anchorY * 100}%)`;
}
function placeLabels() {
  const w = renderer.domElement.clientWidth, h = renderer.domElement.clientHeight;
  for (const l of levelLabels) placeLabel(l, w, h);
  for (const l of rulerLabels) if (!l.el.hidden) placeLabel(l, w, h);
  for (const g of ghosts.values()) if (!g.label.el.hidden) placeLabel(g.label, w, h);
  for (const l of hintLabels) if (!l.el.hidden) placeLabel(l, w, h);
}

// Hover (mouse) or press and hold (touch) on a rail component to see its label.
const raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
let hovered = null, holdTimer = null, hideTimer = null;
function pickAt(cx, cy) {
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  pickGroup.updateMatrixWorld();                 // hit boxes may be newer than the last rendered frame
  const hit = raycaster.intersectObjects(pickGroup.children, false)[0];
  return hit ? hit.object.userData.pick : null;
}
function showPick(p) {
  if (hovered === p) return;
  if (hovered) for (const l of hovered.labels) l.el.hidden = true;
  hovered = p;
  if (p) for (const l of p.labels) l.el.hidden = false;
  renderer.domElement.style.cursor = !p ? '' : p.place && !busy() ? 'grab' : 'help';
}
renderer.domElement.addEventListener('pointermove', e => { if (e.pointerType === 'mouse' && !drag.active) showPick(pickAt(e.clientX, e.clientY)); });
renderer.domElement.addEventListener('pointerleave', () => showPick(null));
renderer.domElement.addEventListener('pointerdown', e => {
  if (e.pointerType === 'mouse') return;
  window.clearTimeout(holdTimer); window.clearTimeout(hideTimer);
  const { clientX: x, clientY: y } = e;
  holdTimer = window.setTimeout(() => showPick(pickAt(x, y)), 280);
});
for (const type of ['pointerup', 'pointercancel']) {
  renderer.domElement.addEventListener(type, e => {
    if (e.pointerType === 'mouse') return;
    window.clearTimeout(holdTimer);
    hideTimer = window.setTimeout(() => showPick(null), 1200);
  });
}

// ───────────────────────── camera fit + zoom / pan ─────────────────────────
const controls = new OrbitControls(camera, renderer.domElement);
controls.enableRotate = false;
controls.zoomToCursor = true;
controls.screenSpacePanning = true;
controls.minZoom = 1;
controls.maxZoom = CAMERA.maxZoom;
controls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
controls.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_PAN };

const hood = document.getElementById('hood');
const maker = document.getElementById('maker');
const makerOpen = () => !maker.hidden;
const dock = document.querySelector('.dock');
const viewDir = new THREE.Vector3();
function fit() {
  if (!levelGroup) return;
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setSize(w, h);
  levelGroup.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(levelGroup);
  const home = box.getCenter(new THREE.Vector3());
  const el = THREE.MathUtils.degToRad(CAMERA.elevationDeg);
  const az = THREE.MathUtils.degToRad(h > w * 1.1 ? CAMERA.portraitAzimuthDeg : CAMERA.azimuthDeg);
  viewDir.set(-Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el));
  controls.target.copy(home);
  camera.position.copy(home).addScaledVector(viewDir, 60);
  camera.zoom = 1;
  camera.lookAt(home);
  camera.updateMatrixWorld();
  const pts = [], b = new THREE.Box3();
  levelGroup.traverse(o => {
    if (!(o.isMesh || o.isLine) || !o.geometry.attributes.position) return;
    b.setFromObject(o);
    if (b.isEmpty()) return;
    for (let i = 0; i < 8; i++) pts.push(new THREE.Vector3(i & 1 ? b.max.x : b.min.x, i & 2 ? b.max.y : b.min.y, i & 4 ? b.max.z : b.min.z));
  });
  for (const l of levelLabels) pts.push(l.world.clone());
  if (mode === 'playground') {                     // room for the + buttons
    const xm = depotX() - 1.6;
    pts.push(new THREE.Vector3(exitX() + 3.2, H, railZ(0)),
      new THREE.Vector3(xm, H, railZ(0) - RAIL_GAP * 0.62 - 0.7), new THREE.Vector3(xm, H, railZ(L.rails.length - 1) + RAIL_GAP * 0.62 + 0.7));
  }
  for (const z of L.rails.map((_, k) => railZ(k))) pts.push(new THREE.Vector3(depotX(), H + 1.7, z), new THREE.Vector3(exitX(), H + 1.7, z));
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const pt of pts) {
    pt.applyMatrix4(camera.matrixWorldInverse);
    minX = Math.min(minX, pt.x); maxX = Math.max(maxX, pt.x); minY = Math.min(minY, pt.y); maxY = Math.max(maxY, pt.y);
  }
  minY -= 0.35; maxX += 0.6; minX -= 0.6;
  const topPx = document.querySelector('header').getBoundingClientRect().bottom + 12;
  const sheet = !hood.hidden ? hood : makerOpen() ? maker : null;
  const bottomPx = (sheet ? sheet.getBoundingClientRect().height : h - dock.getBoundingClientRect().top) + 12;
  const availW = w - 32, availH = Math.max(80, h - topPx - bottomPx);
  const s = Math.max((maxX - minX) / availW, (maxY - minY) / availH);
  const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
  const top = cy + (topPx + availH / 2) * s;
  camera.left = cx - (w / 2) * s; camera.right = cx + (w / 2) * s;
  camera.top = top; camera.bottom = top - h * s;
  camera.updateProjectionMatrix();
  controls.update();
}
document.getElementById('fit').addEventListener('click', fit);
function zoomBy(f) {
  camera.zoom = Math.min(controls.maxZoom, Math.max(controls.minZoom, camera.zoom * f));
  camera.updateProjectionMatrix();
}
document.getElementById('zoom-in').addEventListener('click', () => zoomBy(1.25));
document.getElementById('zoom-out').addEventListener('click', () => zoomBy(0.8));

// ───────────────────────── theme ─────────────────────────
function applyTheme() {
  scene.background = new THREE.Color(css('--ground'));
  for (const { mat: m, token } of themed) m.color.set(css(token));
  grid.material.color = new THREE.Color(css('--grid'));
  grid.material.vertexColors = false;
  grid.material.needsUpdate = true;
  const g = new THREE.Color(css('--ground'));
  shade.top = (g.r + g.g + g.b) / 3 < 0.2 ? 0.12 : 0.32;
  for (const e of palettes) e.pal = null;
  painted.forEach(repaint);
}
const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');
darkQuery.addEventListener('change', applyTheme);
new MutationObserver(applyTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
document.getElementById('theme').addEventListener('click', () => {
  const root = document.documentElement;
  const dark = root.dataset.theme ? root.dataset.theme === 'dark' : darkQuery.matches;
  root.dataset.theme = dark ? 'light' : 'dark';
});

// ───────────────────────── the trains on the track ─────────────────────────
// A run sends a train of `cars` cars per circuit (engine.carsFor). Every car is one shot of the circuit: it
// carries its own quantum state (configuration → amplitude, advanced with engine.applyJoint, the same physics
// as the circuit) and its own outcome from the ideal run (engine.idealRun), which decides what each station
// measures as that car passes. Cars follow each other at a fixed gap and never stop, so the train visibly
// splits as its cars are measured one by one.
const RUN_SPEED = 4.2, CAR_GAP = 3.3;
const FADE_MS = 140;                               // ghosts a measurement rules out vanish quickly: you see who boarded where
let cars = [];
const branchColour = new Map();                    // joint configuration → colour, shared by all cars of a run
const prog = (op, x) => smooth(clamp01((x - op.start) / op.len));

function railProbs(S) {
  const p = new Array(L.rails.length).fill(0);
  for (const [k, c] of S) for (const r of cfgOf(k)) p[r] += abs2(c);
  return p;
}
// The measurements a car's outcome stands for: at every station column, which stations see it; then the exit.
function eventsFor(key) {
  const [stopsStr, exit] = key.split('|');
  const seen = new Set(stopsStr.split(',').filter(Boolean));
  const events = [];
  for (let col = 1; col <= L.columns; col++) {
    const stops = L.stations.filter(st => st.col === col);
    if (!stops.length) continue;
    const hit = stops.filter(st => seen.has(st.id)).map(st => st.id).join(',');
    events.push({ x: colX(col), keep: cfg => seenBy(L, stops, cfg).join(',') === hit, seen: hit ? hit.split(',') : [], sig: hit });
  }
  events.push({ x: exitX(), keep: cfg => [...cfg].sort((a, b) => a - b).map(r => L.rails[r]).join('+') === exit, seen: [], sig: exit, exit: true });
  return events;
}
function makeCar(group, j, outcome = null) {
  return {
    j, group, outcome, S: initialState(L, group), x: depotX(), fade: null, refKey: null, phaseOffset: 0,
    pre: new Map(), sig: '', gone: false, events: outcome ? eventsFor(outcome) : [],
    seenAll: new Set(outcome ? outcome.split('|')[0].split(',').filter(Boolean) : []),
  };
}
function evolve(car, x1) {
  for (const op of anim) {
    const p0 = prog(op, car.x), p1 = prog(op, x1);
    if (p0 === p1) continue;
    if (p0 === 0 && !car.pre.has(op)) car.pre.set(op, { preS: car.S, pre: railProbs(car.S), post: railProbs(applyJoint(car.S, L, op.el, 0, 1)) });
    car.S = applyJoint(car.S, L, op.el, p0, p1);
  }
  car.x = x1;
}
function collapse(car, ev, now) {                  // measurement: keep the matching configurations, renormalise
  const n0 = car.group.length;
  const view = ghostView(car.S, n0, L.rails.length, car.refKey);
  const S = new Map();
  let n = 0;
  for (const [k, c] of car.S) if (ev.keep(cfgOf(k), k)) { S.set(k, c); n += abs2(c); }
  n = Math.sqrt(n) || 1;
  for (const [k, c] of S) S.set(k, [c[0] / n, c[1] / n]);
  car.S = S;
  car.sig += '|' + ev.sig;
  // an overall phase means nothing after a measurement: keep the survivors' displayed phases where they were
  const after = ghostView(S, n0, L.rails.length, null);
  const strongest = [...S.keys()].sort((a, b) => abs2(S.get(b)) - abs2(S.get(a)))[0];
  const prevOffset = car.phaseOffset;
  if (strongest && n0 > 1) { const r0 = cfgOf(strongest)[0]; car.phaseOffset += view.phase[0][r0] - after.phase[0][r0]; }
  car.refKey = after.refKey;
  car.fade = { t0: now, before: view.marg, phases: view.phase.map(row => row.map(p => p + prevOffset)) };   // losers fade with the phase they showed
}
function advanceTo(car, x, now) {
  for (const ev of car.events) {
    if (ev.done || ev.x > x) continue;
    evolve(car, ev.x);
    ev.done = true;
    collapse(car, ev, now);
    if (ev.seen.length) boardAt(car, ev.seen, now);
  }
  evolve(car, x);
}

function ghostPose(car, r, x) {
  let z = railZ(r), yaw = 0;
  for (const op of anim) {
    if (op.el.type === 'twist' || op.el.type === 'interlock') continue;
    const [i, j] = op.el.rails.map(L.railIndex);
    if ((r !== i && r !== j) || x <= op.start || x >= op.start + op.len) continue;
    const o = r === i ? j : i, zr = railZ(r), zo = railZ(o), st = car.pre.get(op);
    const u = (x - op.start) / op.len;
    let zFrom = null, zTo = null;
    if (op.el.type === 'cross') { [zFrom, zTo] = u < 0.5 ? [zr, zo] : [zo, zr]; }
    else if (st && st.pre[r] < 1e-6 && st.pre[o] > 1e-6) { [zFrom, zTo] = [zo, zr]; }                        // split: peels off the other rail
    else if (st && st.post[r] < 1e-6 && st.pre[r] > 1e-6 && st.post[o] > 1e-6) { [zFrom, zTo] = [zr, zo]; }   // merge: joins the survivor
    if (zFrom === null) continue;
    z = crossZ(zFrom, zTo, u);
    yaw = -Math.atan((zTo - zFrom) * 6 * u * (1 - u) / op.len);
  }
  return { z, yaw };
}

// Continuous phase changes (twists) are shown as they happen. A sudden change of the displayed phase
// (an entangled ghost joining another branch) becomes a quick roll instead of a snap.
function smoothPhase(g, target, now, fresh) {
  if (fresh || g.shownPhi === undefined || g.lastT === undefined || now < g.lastT) { g.shownPhi = target; g.lastT = now; return target; }
  let d = target - g.shownPhi;
  d = ((d % (2 * PI)) + 3 * PI) % (2 * PI) - PI;          // shortest way round, in (−π, π]
  if (Math.abs(d) <= PI / 4) g.shownPhi = target;
  else g.shownPhi += d * Math.min(1, (now - g.lastT) / 120);
  g.lastT = now;
  return g.shownPhi;
}
// Purity of one train's own state, Tr(ρ²): 1 when it is independent of the others, < 1 when entangled.
function purity(S, t) {
  const rows = new Map();                          // rest-of-the-trains configuration → (rail of train t → amplitude)
  for (const [k, c] of S) {
    const cfg = cfgOf(k), rest = cfg.filter((_, i) => i !== t).join(',');
    if (!rows.has(rest)) rows.set(rest, []);
    rows.get(rest).push([cfg[t], c]);
  }
  const rho = new Map();
  for (const row of rows.values()) for (const [r1, a] of row) for (const [r2, b] of row) {
    const k = r1 + ',' + r2, o = rho.get(k) ?? [0, 0];
    rho.set(k, [o[0] + a[0] * b[0] + a[1] * b[1], o[1] + a[1] * b[0] - a[0] * b[1]]);   // a · conj(b)
  }
  let pur = 0;
  for (const c of rho.values()) pur += abs2(c);
  return pur;
}

// Branches of an entangled state: each joint configuration gets a colour, kept while it exists. Every ghost
// wears the colours of the branches it is part of (a ring around it and dots in its label), so partners match.
const BRANCH_COLOURS = ['#8f5cff', '#12b5d6', '#e8a317', '#e2557b', '#3fbf6a', '#6b7cff'];
const branchMats = BRANCH_COLOURS.map(c => new THREE.MeshBasicMaterial({ color: c, transparent: true, opacity: 0.9, depthWrite: false, side: THREE.DoubleSide }));
const arcGeos = new Map();
function arcGeo(n, i) {
  const k = `${n}/${i}`, gap = n > 1 ? 0.14 : 0;
  if (!arcGeos.has(k)) arcGeos.set(k, new THREE.RingGeometry(1.15, 1.42, 40, 1, (i * 2 * PI) / n + gap / 2, (2 * PI) / n - gap));
  return arcGeos.get(k);
}
function setHalo(g, colours) {
  const key = colours.join(',');
  if (g.haloKey === key) return;
  g.haloKey = key;
  for (const m of [...g.halo.children]) g.halo.remove(m);
  colours.forEach((ci, i) => g.halo.add(new THREE.Mesh(arcGeo(colours.length, i), branchMats[ci])));
}
// Entangled partners hang together: a chain arches from each ghost to the ghost of the other train it exists with
// (same branch colour as their rings). Drawn for the first car of every branch. One instanced mesh of chain links.
const MAX_LINKS = 900;
const cordGeo = new THREE.TorusGeometry(0.1, 0.028, 6, 12).scale(1.7, 1, 1);    // long axis along x
const cordMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95 });
const cordLinks = new THREE.InstancedMesh(cordGeo, cordMat, MAX_LINKS);
cordLinks.frustumCulled = false;
cordLinks.count = 0;
scene.add(cordLinks);
const cordM = new THREE.Matrix4(), cordQ = new THREE.Quaternion(), cordQ2 = new THREE.Quaternion(), cordP = new THREE.Vector3();
const cordT = new THREE.Vector3(), cordS = new THREE.Vector3(1, 1, 1), cordX = new THREE.Vector3(1, 0, 0), cordC = new THREE.Color();
const CORD_Y = H + 0.95, LINK_PITCH = 0.3;
function drawCords(cords) {
  let n = 0;
  for (const { x, z1, z2, colour } of cords) {
    const zc = (z1 + z2) / 2, R = Math.abs(z2 - z1) / 2, dir = Math.sign(z1 - zc) || 1;
    const links = Math.max(6, Math.round(PI * R / LINK_PITCH));
    cordC.set(BRANCH_COLOURS[colour]);
    for (let i = 0; i <= links && n < MAX_LINKS; i++) {
      const th = PI * i / links;                   // a tall half circle from one ghost to the other
      cordP.set(x, CORD_Y + R * Math.sin(th), zc + dir * R * Math.cos(th));
      cordT.set(0, Math.cos(th), -dir * Math.sin(th)).normalize();
      cordQ.setFromUnitVectors(cordX, cordT);
      if (i % 2) cordQ.premultiply(cordQ2.setFromAxisAngle(cordT, PI / 2));   // every other link turned, like a chain
      cordM.compose(cordP, cordQ, cordS);
      cordLinks.setMatrixAt(n, cordM);
      cordLinks.setColorAt(n, cordC);
      n++;
    }
  }
  cordLinks.count = n;
  cordLinks.instanceMatrix.needsUpdate = true;
  if (cordLinks.instanceColor) cordLinks.instanceColor.needsUpdate = true;
}

function branchesOf(items) {                       // stable colour per joint configuration, for the whole run
  for (const it of [...items].sort((a, b) => (a.k < b.k ? -1 : 1))) {
    if (!branchColour.has(it.k)) branchColour.set(it.k, branchColour.size % BRANCH_COLOURS.length);
  }
}

// At quantum points: for every branch of the other trains, the phase difference of the two arriving ghosts
// and where they merge (0 → one rail, π → the other, in between → still split).
const arg = c => Math.atan2(c[1], c[0]);
function pointsHint(op, S, group) {
  const i = L.railIndex(op.el.rails[0]), j = L.railIndex(op.el.rails[1]);
  const conds = new Map();
  for (const [k, c] of S) {
    const cfg = cfgOf(k), t = cfg.findIndex(r => r === i || r === j);
    if (t < 0) continue;
    const rest = cfg.map((r, u) => (u === t ? '*' : r)).join(',');
    const e = conds.get(rest) ?? { t, cfg, a: [0, 0], b: [0, 0] };
    if (cfg[t] === i) e.a = c; else e.b = c;
    conds.set(rest, e);
  }
  const half = thetaOf(op.el) / 2, cs = Math.cos(half), sn = Math.sin(half);
  const lines = [];
  for (const e of conds.values()) {
    if (abs2(e.a) < 1e-4 || abs2(e.b) < 1e-4) continue;          // only one ghost arrives: nothing to interfere
    let d = arg(e.b) - arg(e.a);
    d = ((d % (2 * PI)) + 2 * PI) % (2 * PI);
    const oi = [cs * e.a[0] - sn * e.b[0], cs * e.a[1] - sn * e.b[1]], oj = [sn * e.a[0] + cs * e.b[0], sn * e.a[1] + cs * e.b[1]];
    const pi = abs2(oi), pj = abs2(oj), n = pi + pj || 1;
    const dest = pi / n > 0.995 ? `<b>${esc(L.rails[i])}</b>` : pj / n > 0.995 ? `<b>${esc(L.rails[j])}</b>`
      : `${esc(L.rails[i])} ${Math.round(100 * pi / n)}% · ${esc(L.rails[j])} ${Math.round(100 * pj / n)}%`;
    const others = group.map((tr, u) => (u === e.t ? null : `${esc(tr.id)} on ${esc(L.rails[e.cfg[u]])}`)).filter(Boolean);
    const cond = conds.size > 1 && others.length ? `<span class="if">if ${others.join(', ')}:</span> ` : '';
    lines.push(`${cond}Δφ ${fmtPhase(d)} → ${dest}`);
  }
  return [...new Set(lines)];
}

function drawCars(now) {
  const lift = anim.some(o => o.el.type === 'twist') ? DIAL_R + 0.35 : anim.some(o => o.el.type === 'interlock') ? 1.95 : 1.2;
  const moving = busy();
  const shown = new Set(), labelled = new Set(), cords = [];
  for (const car of cars) {
    if (car.gone || (car.j > 0 && car.x < depotX() - 1e-6)) continue;        // still waiting in the depot
    const x = car.x, group = car.group;
    const view = ghostView(car.S, group.length, L.rails.length, car.refKey);
    car.refKey = view.refKey;
    const marg = view.marg;
    const u = car.fade ? clamp01((now - car.fade.t0) / FADE_MS) : 1;
    const away = clamp01((x - exitX()) / 1.6);                                 // past the exit: drive off and fade
    const withLabels = !labelled.has(car.sig) && away === 0;                   // the first car of every branch
    labelled.add(car.sig);
    // which trains are entangled: a train's own (reduced) state is no longer pure
    const tangled = group.map((_, t) => group.length > 1 && purity(car.S, t) < 0.995);
    let items = [];
    if (tangled.some(Boolean)) {
      items = [...car.S].map(([k, c]) => ({ k, cfg: cfgOf(k), c, p: abs2(c) })).filter(o => o.p > 0.01);
      branchesOf(items);
    }
    const ref = car.refKey && car.S.get(car.refKey);
    const refPh = ref ? arg(ref) : 0;
    group.forEach((train, ti) => {
      for (let r = 0; r < L.rails.length; r++) {
        const before = car.fade ? car.fade.before[ti][r] : marg[ti][r];
        const p = car.fade ? lerp(before, marg[ti][r], u) : marg[ti][r];
        if (p <= 0.002) continue;
        const g = ghostFor(train, r, car.j);
        shown.add(g);
        const fresh = !g.root.visible;
        const { z, yaw } = ghostPose(car, r, x);
        g.root.visible = true;
        g.root.position.set(x, H, z);
        g.yaw.rotation.y = yaw;
        const target = marg[ti][r] > 1e-12 ? view.phase[ti][r] + car.phaseOffset : (car.fade ? car.fade.phases[ti][r] : 0);
        let phi;
        if (tangled[ti] && !fresh && g.shownPhi !== undefined) { phi = g.shownPhi; g.lastT = now; }   // no phase of its own: hold still
        else phi = smoothPhase(g, target, now, fresh);
        g.roll.rotation.x = phi;
        const losing = car.fade && marg[ti][r] < 1e-9 && before > 0;
        g.root.scale.setScalar(losing ? 1 + 0.35 * u : 1);
        g.setOpacity((0.15 + 0.85 * p) * (1 - away));
        g.label.el.hidden = !withLabels;
        setHalo(g, []);                            // (rings under the trains removed: the cords show who belongs together)
        if (!withLabels) continue;
        if (tangled[ti]) (car.at ??= {})[`${ti}:${r}`] = z;     // where this ghost is, for the cords
        g.label.world.set(x + 0.1, H + lift, z);
        const pct = Math.round(p * 100);
        let tail = pct < 100 ? ` <small>· ${pct}%</small>` : '';
        if (!moving && car.j === 0) tail += ` <small>· ${carsFor(L)} car${carsFor(L) === 1 ? '' : 's'}</small>`;
        if (tangled[ti]) {
          const mine = items.filter(it => it.cfg[ti] === r).sort((a, b) => branchColour.get(a.k) - branchColour.get(b.k));
          g.label.el.innerHTML = mine.map(it => {
            let rel = arg(it.c) - refPh;
            rel = ((rel % (2 * PI)) + 2 * PI) % (2 * PI);
            return `<i class="bdot" style="background:${BRANCH_COLOURS[branchColour.get(it.k)]}"></i>${fmtPhase(rel)}`;
          }).join('<span class="bsep"></span>') + tail;
        } else g.label.el.innerHTML = `φ = ${fmtPhase(phi)}` + tail;
      }
    });
    if (withLabels && car.at) {                    // chain each entangled branch's ghosts together
      for (const it of items) for (let t = 0; t + 1 < it.cfg.length; t++) {
        if (!tangled[t] && !tangled[t + 1]) continue;
        const z1 = car.at[`${t}:${it.cfg[t]}`], z2 = car.at[`${t + 1}:${it.cfg[t + 1]}`];
        if (z1 !== undefined && z2 !== undefined && Math.abs(z1 - z2) > 0.1) cords.push({ x, z1, z2, colour: branchColour.get(it.k) });
      }
    }
    car.at = null;
  }
  if (!moving) {                                     // between runs, every train waits at its depot
    for (const train of L.trains) {
      if (cars.some(c => c.group.some(t => t.id === train.id))) continue;
      const g = ghostFor(train, L.railIndex(train.depot), 0);
      shown.add(g);
      g.root.visible = true; g.root.position.set(depotX(), H, zOf(train.depot)); g.root.scale.setScalar(1);
      g.yaw.rotation.y = 0; g.roll.rotation.x = 0; g.shownPhi = 0; g.setOpacity(1); setHalo(g, []);
      g.label.el.hidden = true;
    }
  }
  hideGhosts(shown);
  drawCords(cords);

  for (const op of anim) {
    if (op.el.type === 'twist') {                  // the dial follows the car that is inside it
      const inside = cars.find(c => !c.gone && c.x >= op.start && c.x <= op.start + op.len);
      setDial(op, inside ? op.dphi * prog(op, inside.x) : 0);
    }
    if (!op.hint) continue;
    const car = moving ? cars.find(c => !c.gone && c.x > op.start - 1.4 && c.x < op.start + op.len * 0.85) : null;
    const lines = car ? pointsHint(op, car.pre.get(op)?.preS ?? car.S, car.group) : [];
    op.hint.el.hidden = !lines.length;
    if (lines.length) {
      const html = lines.join('<br>');
      if (op.hint.el.innerHTML !== html) op.hint.el.innerHTML = html;
    }
  }
}

// ───────────────────────── building: palette, drag and drop ─────────────────────────
// Drag a block from the palette onto a dashed pad on the line; drag a placed block to another pad, or off the line
// to remove it; drop onto a placed block to replace it (the old one goes back to the supply). Tap a twist to turn it
// by π/4. Locked while trains run. Every edit rebuilds the scene and the circuit from level + placements.
const TYPES = ['twist', 'points', 'cross', 'interlock'];
const NAMES = { twist: 'twist', points: 'points', cross: 'cross', interlock: 'interlock', station: 'station', train: 'train' };
const ICONS = {
  twist: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5" fill="currentColor" fill-opacity=".08" stroke="currentColor" stroke-width="1.4" stroke-opacity=".5"/><path d="M12 3.5a8.5 8.5 0 0 1 8.5 8.5" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/><path d="M12 12l5.5-5.5" stroke="var(--fg)" stroke-width="2" stroke-linecap="round"/></svg>',
  points: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 6.5h4c6.5 0 6.5 11 13 11h4M1.5 17.5h4c6.5 0 6.5-11 13-11h4" fill="none" stroke="var(--fg)" stroke-width="1.8"/><rect x="8" y="8" width="8" height="8" rx="1" fill="currentColor" fill-opacity=".3" stroke="currentColor" stroke-width="1.6"/></svg>',
  cross: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 6.5h4c6.5 0 6.5 11 13 11h4M1.5 17.5h4c6.5 0 6.5-11 13-11h4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  interlock: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 5h21M1.5 19h21" stroke="var(--fg)" stroke-width="1.6" opacity=".45"/><path d="M12 7.5v9" stroke="currentColor" stroke-width="2.6" stroke-dasharray="2.4 1.8"/><circle cx="12" cy="5" r="3.2" fill="currentColor"/><circle cx="12" cy="19" r="3.2" fill="currentColor"/></svg>',
};
ICONS.station = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 6h21" stroke="var(--fg)" stroke-width="1.8"/><rect x="5" y="10" width="14" height="5" rx="1" fill="currentColor" fill-opacity=".25" stroke="currentColor" stroke-width="1.5"/><path d="M8 10V7.6M16 10V7.6" stroke="currentColor" stroke-width="1.4"/><path d="M13 15v-3.5h3.5V15" fill="currentColor"/><circle cx="8.5" cy="12.4" r="1.4" fill="var(--fg)"/></svg>';
ICONS.train = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1.5 15.5h21" stroke="var(--fg)" stroke-width="1.8"/><path d="M3 14V9.5Q3 8 4.5 8H15q4.5 0 5.5 4.5V14z" fill="var(--train)"/><rect x="5" y="9.6" width="9" height="1.6" rx=".8" fill="var(--window)"/></svg>';
const CLEAR_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12a7 7 0 1 0 2.1-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M6.5 3v4.5H11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const paletteEl = document.getElementById('palette');

const used = type => placements.filter(p => p.type === type).length;
function left(type) {
  if (type === 'station') return PG.maxQubits - L.rails.length - L.stations.length;
  if (type === 'train') return PG.maxTrains - L.trains.length;
  return L.supply[type] === null ? Infinity : L.supply[type] - used(type);
}
// where a block can go: elements on build cells; in the playground also stations (one cell) and trains (a free depot)
function spotsFor(type) {
  if (type === 'station') return L.slots.flatMap(sl => sl.rails.map(r => ({ col: sl.col, rails: [r] })));
  if (type === 'train') {
    const taken = new Set(L.trains.map(t => t.depot));
    return L.rails.filter(r => !taken.has(r)).map(r => ({ col: 0, rails: [r] }));
  }
  return spots(L, type);
}
const cellsOf = spot => spot.rails.map(r => cellKey(spot.col, r));
const usedCells = () => new Set(placements.flatMap(cellsOf));
const spotCentre = spot => new THREE.Vector3(colX(spot.col), H, spot.rails.reduce((z, r) => z + zOf(r), 0) / spot.rails.length);

function setupPalette() {
  const types = [...TYPES.filter(t => t in L.supply), ...(mode === 'playground' ? ['station', 'train'] : [])];
  paletteEl.hidden = types.length === 0;           // a level with nothing to build (level 1): just Run
  paletteEl.innerHTML = types.map(t => `<button class="piece k-${t}" type="button" data-type="${t}">${ICONS[t]}<span>${NAMES[t]}</span><span class="count"></span></button>`).join('') +
    (mode === 'playground'
      ? `<button class="piece clear" id="clear" type="button" aria-label="Reset the playground to a small empty line">${CLEAR_ICON}<span>reset</span></button>`
      : `<button class="piece clear" id="clear" type="button" aria-label="Clear: remove every block you placed">${CLEAR_ICON}<span>clear</span></button>`);
}
function updatePalette() {
  if (!L) return;
  const locked = busy();
  paletteEl.classList.toggle('locked', locked);
  for (const b of paletteEl.querySelectorAll('.piece[data-type]')) {
    const t = b.dataset.type, n = left(t);
    b.querySelector('.count').textContent = n === Infinity ? '∞' : String(n);
    b.disabled = locked || n <= 0;
    b.setAttribute('aria-label', `${NAMES[t]}: ${n === Infinity ? 'unlimited' : n + ' left'}. Drag it onto a dashed spot on the line, or press to put it on the first free spot.`);
  }
  const clear = document.getElementById('clear');
  if (clear) clear.disabled = locked || (mode !== 'playground' && placements.length === 0);
  for (const b of document.querySelectorAll('#pg-dispatch .chip')) {
    b.setAttribute('aria-pressed', String((b.dataset.dispatch === 'together') === L.dispatch.includes('together')));
    b.disabled = locked;
  }
  updatePlus();
}
function edit(next) {                             // every change of the build goes through here
  placements = next;
  if (mode === 'playground') { pg.placements = next; store.set(PG_KEY, pg); }
  else if (mode === 'level') store.set(storeKey(), placements);
  else if (mode === 'puzzle') store.set(puzzleStoreKey(), placements);
  rebuild();
}

// cell pads: idle → only empty cells show; while dragging → cells the block can use light up, the target glows
function showSlots(type = null, target = null) {
  const used = usedCells();
  const ok = new Set(type ? spotsFor(type).flatMap(cellsOf) : []);
  const hot = new Set(target ? cellsOf(target) : []);
  for (const o of cellObjs) {
    let look;
    if (!type) look = used.has(o.key) || o.col === 0 ? null
      : mode === 'playground' && makerOpen() ? ((pg.blocked ?? []).includes(o.key) ? 'idle' : 'ok')   // maker: blue = player cell
      : 'idle';                                    // depot pads only show for trains
    else if (!ok.has(o.key)) look = used.has(o.key) || o.col === 0 ? null : 'off';
    else look = hot.has(o.key) ? 'hot' : 'ok';
    o.pad.visible = !!look;
    if (look) { o.fill.material = mat.slot[look][0]; o.edge.material = mat.slot[look][1]; }
  }
}

// the dragged block's preview, drawn at the pad it will snap to
const previewGroup = new THREE.Group();
scene.add(previewGroup);
function showPreview(item, slot) {
  for (const o of [...previewGroup.children]) { previewGroup.remove(o); o.traverse(m => m.geometry && m.geometry.dispose()); }
  if (!slot || item.type === 'station' || item.type === 'train') return;   // those show the glowing pad only
  const G = new THREE.Group();
  const el = { type: item.type, col: slot.col, rails: [...slot.rails], steps: item.steps ?? 0, stay: item.stay ?? 50, fixed: false };
  const op = buildElement(G, el, null, true);
  if (op.lens) setDial(op, 0);
  G.traverse(o => { if (o.isLineSegments) o.material = mat.previewLine; else if (o.isMesh) o.material = mat.preview; });
  previewGroup.add(G);
}

const drag = { pending: null, active: null, floating: null, suppressClick: false };
const DRAG_START_PX = 8, TOUCH_LIFT_PX = 64;
function canEdit() { return !busy() && !makerOpen(); }   // the open puzzle maker uses taps on the map to mark pads

// pointer down on a placed block (capture on the stage, so the camera does not pan) or on a palette block
stage.addEventListener('pointerdown', e => {
  if (!canEdit() || drag.active || drag.pending || !e.isPrimary) return;
  const p = pickAt(e.clientX, e.clientY);
  if (!p || !p.place) return;
  controls.enabled = false;
  drag.pending = { place: p.place, type: p.place.type, x0: e.clientX, y0: e.clientY, t0: performance.now(), id: e.pointerId, touch: e.pointerType !== 'mouse' };
}, { capture: true });
paletteEl.addEventListener('pointerdown', e => {
  const b = e.target.closest('.piece[data-type]');
  if (!b || b.disabled || !canEdit() || drag.active || !e.isPrimary) return;
  drag.pending = { type: b.dataset.type, fromPalette: true, x0: e.clientX, y0: e.clientY, t0: performance.now(), id: e.pointerId, touch: e.pointerType !== 'mouse' };
});
// a press on a palette block without dragging puts it on the first free pad it fits (also the keyboard route)
paletteEl.addEventListener('click', e => {
  if (drag.suppressClick) { drag.suppressClick = false; return; }
  if (!canEdit()) return;
  if (e.target.closest('#clear')) {
    if (mode === 'playground') pgCommit(PG_START(), { refit: true });
    else if (placements.length) edit([]);
    return;
  }
  const b = e.target.closest('.piece[data-type]');
  if (!b || b.disabled) return;
  const used = usedCells();
  const spot = spotsFor(b.dataset.type).find(sp => cellsOf(sp).every(k => !used.has(k)));
  if (spot) drop({ type: b.dataset.type }, spot);
});
function newPlacement(type, slot, from = {}) {
  const p = { type, col: slot.col, rails: [...slot.rails] };
  if (type === 'twist') p.steps = from.steps ?? 1;          // a new twist starts at π/4
  if (from.stay !== undefined && type === 'points') p.stay = from.stay;
  return p;
}

window.addEventListener('pointermove', e => {
  const d = drag.pending;
  if (d && e.pointerId === d.id && Math.hypot(e.clientX - d.x0, e.clientY - d.y0) > DRAG_START_PX) startDrag(e);
  if (drag.active && e.pointerId === drag.active.id) moveDrag(e);
});
function startDrag(e) {
  const d = drag.pending;
  drag.pending = null;
  window.clearTimeout(holdTimer);
  showPick(null);
  controls.enabled = false;
  const item = d.fromPalette ? { type: d.type } : { ...d.place };
  drag.active = { item, id: d.id, touch: d.touch, target: null, base: null };
  if (!d.fromPalette) {                          // lifted off the line
    if (item.type === 'station' || item.type === 'train') {
      drag.active.base = pg.placements;             // blocks to restore if lifting changed which ones are legal
      const g = clonePg(pg);
      if (item.type === 'station') g.stations = g.stations.filter(st => !(st.col === item.col && st.rail === item.rail));
      else g.trains = g.trains.filter(t => t.rail !== item.rail);
      pgCommit(g, { save: false });
    } else { placements = placements.filter(p => p !== d.place); rebuild(); }
  }
  drag.active.spots = spotsFor(item.type).map(sp => ({ ...sp, centre: spotCentre(sp) }));
  const f = drag.floating = document.createElement('div');
  f.className = `piece floating k-${item.type}`;
  f.innerHTML = `${ICONS[item.type]}<span>${NAMES[item.type]}</span>`;
  document.body.appendChild(f);
  document.body.classList.add('dragging');
  showSlots(item.type);
  moveDrag(e);
}
const scr = new THREE.Vector3();
function toScreen(world) {
  const r = renderer.domElement.getBoundingClientRect();
  scr.copy(world).project(camera);
  return { x: r.left + (scr.x + 1) / 2 * r.width, y: r.top + (1 - scr.y) / 2 * r.height };
}
function moveDrag(e) {
  const a = drag.active;
  const x = e.clientX, y = e.clientY - (a.touch ? TOUCH_LIFT_PX : 0);   // on a phone the block floats above the finger
  // snap: the nearest pad the block fits, within about half a column on screen
  const c0 = toScreen(new THREE.Vector3(0, H, 0)), c1 = toScreen(new THREE.Vector3(COL, H, 0));
  const radius = Math.max(36, 0.62 * Math.hypot(c1.x - c0.x, c1.y - c0.y));
  let target = null, best = radius;
  for (const sp of a.spots) {
    const p = toScreen(sp.centre), dist = Math.hypot(p.x - x, p.y - y);
    if (dist < best) { best = dist; target = sp; }
  }
  if (target !== a.target) { a.target = target; showSlots(a.item.type, target); showPreview(a.item, target); }
  drag.floating.style.transform = `translate(${x - 31}px, ${y - 29}px) scale(${target ? 0.8 : 1})`;
  drag.floating.style.opacity = target ? '0.45' : '1';
}
function endPointer(e, cancelled) {
  const d = drag.pending;
  if (d && e.pointerId === d.id) {               // no drag: a tap
    drag.pending = null;
    if (!d.fromPalette) {
      controls.enabled = true;
      const quick = !d.touch || performance.now() - d.t0 < 280;      // a long press only shows the label
      if (!cancelled && quick && d.place.type === 'twist' && canEdit()) {
        edit(placements.map(p => (p === d.place ? { ...p, steps: ((p.steps ?? 0) + 1) % TWIST_STEPS } : p)));
        if (e.pointerType === 'mouse') showPick(pickAt(e.clientX, e.clientY));
      }
    }
    return;
  }
  const a = drag.active;
  if (!a || e.pointerId !== a.id) return;
  drag.active = null;
  drag.floating.remove();
  drag.floating = null;
  document.body.classList.remove('dragging');
  showPreview(null, null);
  controls.enabled = true;
  drag.suppressClick = true;
  window.setTimeout(() => { drag.suppressClick = false; }, 0);
  const target = cancelled ? null : a.target;
  if (a.base) pg.placements = a.base;
  if (target) drop(a.item, target);
  else if (a.item.type === 'station' || a.item.type === 'train') pgCommit(clonePg(pg));   // removed from the line
  else edit(placements);                         // dropped off the line: a placed block is removed, a new one is not placed
}
// put a block (or, in the playground, a station or a train) on a spot; whatever was in the way goes back
function drop(item, target) {
  const hit = new Set(cellsOf(target));
  const pgItem = item.type === 'station' || item.type === 'train';
  const keep = (pgItem ? pg.placements : placements).filter(p => !cellsOf(p).some(k => hit.has(k)));
  if (pgItem) {
    const g = clonePg(pg);
    g.placements = keep;
    if (item.type === 'station') g.stations.push({ col: target.col, rail: target.rails[0] });
    else g.trains.push({ slot: item.slot ?? [0, 1, 2, 3].find(k => !g.trains.some(t => t.slot === k)), rail: target.rails[0] });
    if (!pgCommit(g)) pgCommit(clonePg(pg));
    return;
  }
  const next = [...keep, newPlacement(item.type, target, item)];
  edit(legal(next) ? next : placements);
}
// read-only hooks for the browser tests (where the pads are on screen, what is placed)
window.quantrainTest = {
  cells: () => cellObjs.map(o => ({ col: o.col, rail: o.rail, visible: o.pad.visible, ...toScreen(spotCentre({ col: o.col, rails: [o.rail] })) })),
  spots: type => spotsFor(type).map(sp => ({ col: sp.col, rails: sp.rails.join('-'), ...toScreen(spotCentre(sp)) })),
  placements: () => JSON.parse(JSON.stringify(placements)),
  state: () => state,
  playground: () => JSON.parse(JSON.stringify(pg)),
  pgLoad: g => mode === 'playground' && !busy() && pgCommit(clonePg(g), { refit: true }),   // tests: set a whole playground
  edit: list => !busy() && (edit(list.map(p => ({ ...p }))), true),                         // tests: set the build
  stars: () => idealRun(L, build).stars,
  puzzle: () => puzzleCtx && { name: L.name, test: puzzleCtx.test, key: puzzleCtx.key, mode },
  design: () => designToPuzzle(pg),
  level: () => ({ id: L.id, rails: L.rails, columns: L.columns, dispatch: L.dispatch, trains: L.trains.map(t => [t.id, t.depot, t.rails.join('')]), stations: L.stations.map(st => st.id) }),
  plus: () => [...document.querySelectorAll('#plus button')].map(b => ({ add: b.dataset.add ?? null, remove: b.dataset.remove ?? null, disabled: b.disabled, x: b.getBoundingClientRect().x + 19, y: b.getBoundingClientRect().y + 19 })),
  // the live check under the hood, for every circuit of the current build: circuit simulation == train physics
  check: () => L.groups().every(group => {
    const a = circuitOutcomes(L, build, group), b = trackOutcomes(L, build, group);
    return [...new Set([...Object.keys(a), ...Object.keys(b)])].every(k => Math.abs((a[k] ?? 0) - (b[k] ?? 0)) < 1e-9);
  }),
};
window.addEventListener('pointerup', e => endPointer(e, false));
window.addEventListener('pointercancel', e => endPointer(e, true));

// ───────────────────────── runs ─────────────────────────
// One press of Run plays the ideal run: every circuit sends its train of cars, each car one shot with the
// outcome engine.idealRun gave it. The level is cleared when that one run picks up every passenger.
// While trains run the board is locked; Pause / Resume freezes the clock, Stop resets the line.
const runBtn = document.getElementById('run');
const hoodBtn = document.getElementById('hood-open');
const statsEl = document.getElementById('stats');
let state = 'idle', runClock = 0, lastNow = null, queue = [], result = null, lastStars = null;
const busy = () => state === 'running' || state === 'paused';
const allPassengers = () => stationObjs.flatMap(st => st.passengers);
const waitingCount = () => allPassengers().filter(p => p.state === 'waiting').length;
const STAR_TEXT = n => '★'.repeat(n) + '☆'.repeat(3 - n);

function updateHud() {
  for (const so of stationObjs) {
    const n = so.passengers.filter(p => p.state === 'waiting').length;
    const partner = so.st.partner && L.stations.find(o => o.id === so.st.partner);
    so.label.el.innerHTML = `${esc(so.st.name)}<b>${so.passengers.length === 0 ? 'nobody waiting' : n > 0 ? n + ' waiting' : 'all aboard ✓'}</b>` +
      (partner ? `<i>couples with ${esc(partner.name)}</i>` : '') + (mode === 'playground' ? '<em>drag to move · off the line to remove</em>' : '');
  }
  const total = allPassengers().length, picked = total - waitingCount(), k = carsFor(L);
  const per = L.groups().length > 1 ? ` per train` : '';
  statsEl.textContent = `${k} car${k === 1 ? '' : 's'}${per} · picked up ${picked} / ${total}` + (state === 'done' && lastStars !== null ? ` · ${STAR_TEXT(lastStars)}` : '');
}
function updateButtons() {
  hoodBtn.textContent = busy() ? 'Stop' : 'Under the hood';
  runBtn.textContent = { idle: 'Run', running: 'Pause', paused: 'Resume', done: 'Run again' }[state];
  runBtn.classList.toggle('stop', busy());
  updatePalette();
}
function resetPassengers() {
  for (const p of allPassengers()) { p.state = 'waiting'; p.mesh.visible = true; p.mesh.scale.setScalar(1); p.mesh.position.copy(p.home); p.mesh.rotation.set(0, 0, 0); }
}
function resetRun() {                              // back to the start: the first train waits at its depot
  hideResult();
  resetPassengers();
  cars = [makeCar(L.groups()[0], 0)];
  branchColour.clear();
  state = 'idle';
  lastStars = null;
  runClock = 0;
  drawCars(0);
  updateHud();
  updateButtons();
}
function startGroup(g) {
  cars = g.shots.map((key, j) => makeCar(g.group, j, key));
  runClock = 0;
  branchColour.clear();
}
function run() {
  hideResult();
  resetPassengers();
  result = idealRun(L, build);
  queue = [...result.groups];
  startGroup(queue.shift());
  state = 'running';
  lastNow = null;
  showPick(null);
  updateHud();
  updateButtons();
}
function finishRun() {
  cars = [];
  state = 'done';
  const total = allPassengers().length, picked = total - waitingCount();
  lastStars = starsFor(picked, total);
  if (mode === 'level') {                          // remember the best result for the level grid
    const best = store.get(`quantrain:stars:${L.id}`) ?? 0;
    if (lastStars > best) store.set(`quantrain:stars:${L.id}`, lastStars);
  }
  if (mode === 'puzzle' && puzzleCtx?.test && lastStars === 3) {   // the maker cleared it: now it may be shared
    pg.verified = puzzleKey(puzzleCtx.P);
    store.set(PG_KEY, pg);
  }
  updateHud();
  updateButtons();
  if (mode === 'level' || mode === 'puzzle') showResult();
}

// ── the result card: stars, what every car did (the ideal run), and where to go next
const resultEl = document.getElementById('result');
function hideResult() { resultEl.hidden = true; }
function showResult() {
  const total = allPassengers().length, picked = total - waitingCount(), stars = lastStars ?? 0;
  const best = store.get(`quantrain:stars:${L.id}`) ?? stars;
  document.getElementById('result-title').textContent = stars === 3 ? (mode === 'puzzle' ? 'Puzzle cleared!' : 'Level cleared!') : stars > 0 ? 'Almost there' : 'Not yet';
  document.getElementById('result-stars').innerHTML = [0, 1, 2].map(k => `<span class="${k < stars ? 'on' : ''}">${STAR}</span>`).join('');
  document.getElementById('result-stars').setAttribute('aria-label', `${stars} of 3 stars`);
  const left = stationObjs.map(so => [so.st.name, so.passengers.filter(p => p.state === 'waiting').length]).filter(([, n]) => n > 0);
  document.getElementById('result-sub').textContent = `Picked up ${picked} of ${total} passengers with ${result.cars} car${result.cars === 1 ? '' : 's'}` +
    (L.groups().length > 1 ? ' per train' : '') + '. ' +
    (left.length ? `Still waiting: ${left.map(([name, n]) => `${n} at ${name}`).join(', ')}.` : 'Every car found someone waiting.') +
    (best > stars ? ` Your best here: ${best} ★.` : '');
  const nameOf = id => L.stations.find(o => o.id === id)?.name ?? id;
  const rows = result.groups.flatMap(g => {
    const cars = {};
    for (const k of g.shots) cars[k] = (cars[k] ?? 0) + 1;
    return Object.entries(g.probs).filter(([, p]) => p > 1e-9).sort((a, b) => b[1] - a[1]).map(([k, p]) => {
      const [stops, exit] = k.split('|');
      const who = result.groups.length > 1 ? `${esc(g.group[0].id)}: ` : '';
      return `<tr><td>${who}${stops ? stops.split(',').map(nameOf).map(esc).join(' → ') : '—'}</td><td>${esc(exit)}</td>` +
        `<td class="num">${(p * 100).toFixed(1)}%</td><td class="num">${cars[k] ?? 0}</td></tr>`;
    });
  }).join('');
  document.getElementById('result-table').innerHTML =
    `<table><thead><tr><th>Stations seen</th><th>Exit</th><th>Chance</th><th>Cars</th></tr></thead><tbody>${rows}</tbody></table>`;
  const next = document.getElementById('result-next'), share = document.getElementById('result-share');
  next.hidden = mode !== 'level' || levelIndex >= LEVELS.length - 1;
  next.textContent = stars === 3 ? 'Next level ▶' : 'Skip to next ▶';
  next.classList.toggle('alt', stars !== 3);
  const testing = mode === 'puzzle' && puzzleCtx?.test;
  share.hidden = mode !== 'puzzle' || (testing && stars !== 3);
  share.textContent = testing ? 'Cleared ✓ Share your puzzle' : 'Share this puzzle';
  document.getElementById('result-levels').textContent = mode === 'level' ? 'Levels' : testing ? 'Back to editing' : 'Menu';
  if (testing && stars === 3) document.getElementById('result-title').textContent = 'Puzzle verified!';
  resultEl.hidden = false;
  (!share.hidden ? share : stars === 3 && !next.hidden ? next : document.getElementById('result-retry')).focus();
}
document.getElementById('result-close').addEventListener('click', hideResult);
document.getElementById('result-retry').addEventListener('click', hideResult);
document.getElementById('result-hood').addEventListener('click', () => { hideResult(); setHood(true); });
document.getElementById('result-levels').addEventListener('click', () => { hideResult(); goBack(); });
document.getElementById('result-share').addEventListener('click', () => { hideResult(); sharePuzzle(); });
document.getElementById('result-next').addEventListener('click', () => { hideResult(); if (levelIndex < LEVELS.length - 1) buildLevel(levelIndex + 1); });
resultEl.addEventListener('click', e => { if (e.target === resultEl) hideResult(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !resultEl.hidden) hideResult(); });

const trainCentre = new THREE.Vector3();
function hop(p, now) {
  const u = clamp01((now - p.t0) / 650);
  p.ghost.roll.localToWorld(trainCentre.set(0.05, 0.38, 0));
  p.mesh.position.lerpVectors(p.home, trainCentre, easeInOut(u));
  p.mesh.position.y += 1.1 * 4 * u * (1 - u);
  p.mesh.rotation.y = u * PI;
  p.mesh.scale.setScalar(1 - 0.75 * u * u);
  if (u >= 1) { p.state = 'aboard'; p.mesh.visible = false; updateHud(); }
}
// A car passing a station that sees it takes one waiting passenger (couples: only if the partner station sees
// the same car). The passenger hops onto the moving car.
function boardAt(car, ids, now) {
  for (const id of ids) {
    const st = L.stations.find(o => o.id === id);
    if (st.partner && !car.seenAll.has(st.partner)) continue;
    const so = stationObjs.find(o => o.st.id === id);
    const next = so.passengers.find(p => p.state === 'waiting');
    if (!next) continue;
    const ti = cfgOf([...car.S.keys()][0]).indexOf(so.k);     // which train of this car is at the station
    if (ti < 0) continue;
    next.ghost = ghostFor(car.group[ti], so.k, car.j);
    next.state = 'hopping';
    next.t0 = now;
  }
}

function step(now) {
  if (state === 'running') runClock += lastNow === null ? 0 : Math.min(100, Math.max(0, now - lastNow));
  lastNow = now;
  for (const p of allPassengers()) if (p.state === 'hopping') hop(p, runClock);
  if (busy()) {
    const lead = depotX() + RUN_SPEED * runClock / 1000;
    for (const car of cars) {
      if (car.gone) continue;
      const x = lead - car.j * CAR_GAP;
      if (x < depotX()) continue;
      advanceTo(car, Math.min(x, exitX() + 1.7), runClock);
      if (x > exitX() + 1.6) car.gone = true;
    }
    if (state === 'running' && cars.every(c => c.gone) && !allPassengers().some(p => p.state === 'hopping')) {
      if (queue.length) startGroup(queue.shift());     // the next train's turn
      else finishRun();
    }
  }
  drawCars(runClock);
}
runBtn.addEventListener('click', () => {
  if (state === 'running') { state = 'paused'; updateButtons(); }
  else if (state === 'paused') { state = 'running'; lastNow = null; updateButtons(); }
  else run();
});
hoodBtn.addEventListener('click', () => { if (busy()) resetRun(); else setHood(true); });

// ───────────────────────── under the hood: the Qiskit circuit ─────────────────────────
let hoodGroup = 0;
function circuitSVG(circ) {
  const CH = 7.3, WIRE = 38, TOP = 30;
  const nameW = Math.max(...circ.qubits.map(q => q.length)) * CH + 14;
  const y = q => TOP + q * WIRE;
  const parts = [];
  let x = nameW + 8;
  const segs = [];                          // gates between barriers, packed into sub-columns
  let cur = [], lastBarrier = -Infinity;
  for (const op of circ.ops) {
    if (op.gate === 'barrier') { segs.push({ gates: cur, barrier: op.label }); cur = []; }
    else cur.push(op);
  }
  if (cur.length) segs.push({ gates: cur, barrier: null });

  const gateInfo = op => {
    const lo = Math.min(...op.qubits), hi = Math.max(...op.qubits);
    if (op.gate === 'x') return { w: 34, lo, hi, kind: 'depot', title: `depot: train ${op.src.train} starts here` };
    if (op.gate === 'p') return { w: Math.max(40, (`P(${fmtAngle(op.params[0])})`).length * CH + 16), lo, hi, kind: 'twist', title: `twist ${fmtPhase(op.params[0])} · column ${op.src.el.col} · rail ${op.src.el.rails[0]}` };
    if (op.gate === 'xx_plus_yy') return { w: Math.max(70, 12 * CH + 14), lo, hi, kind: 'points', title: `quantum points ${op.src.el.stay}:${100 - op.src.el.stay} · column ${op.src.el.col} · rails ${op.src.el.rails.join('–')}` };
    if (op.gate === 'swap') return { w: 30, lo, hi, kind: 'cross', title: `cross · column ${op.src.el.col} · rails ${op.src.el.rails.join('–')}` };
    if (op.gate === 'cz') return { w: 30, lo, hi, kind: 'interlock', title: `interlock · column ${op.src.el.col} · rails ${op.src.el.rails.join('–')}: phase π only if a train is on each rail` };
    if (op.gate === 'cx') return { w: 30, lo, hi, kind: 'station', title: `station ${op.src.st.name}: records the train on rail ${op.src.st.rail}` };
    return { w: 38, lo: 0, hi: circ.qubits.length - 1, kind: 'measure', title: 'measure: where the train exits and which stations saw it' };
  };
  const drawGate = (op, gi, cx) => {
    const t = `<title>${esc(gi.title)}</title>`;
    if (op.gate === 'x' || op.gate === 'p') {
      const label = op.gate === 'x' ? 'X' : `P(${fmtAngle(op.params[0])})`;
      return `<g>${t}<rect class="box k-${gi.kind}" x="${cx - gi.w / 2}" y="${y(gi.lo) - 15}" width="${gi.w}" height="30" rx="5"/><text class="glabel" x="${cx}" y="${y(gi.lo) + 4}" text-anchor="middle">${esc(label)}</text></g>`;
    }
    if (op.gate === 'xx_plus_yy') {
      const top = y(gi.lo) - 15, hgt = y(gi.hi) - y(gi.lo) + 30, mid = (y(gi.lo) + y(gi.hi)) / 2;
      return `<g>${t}<rect class="box k-points" x="${cx - gi.w / 2}" y="${top}" width="${gi.w}" height="${hgt}" rx="5"/>` +
        `<text class="glabel" x="${cx}" y="${mid - 2}" text-anchor="middle">XX+YY</text>` +
        `<text class="gsub" x="${cx}" y="${mid + 13}" text-anchor="middle">(${fmtAngle(op.params[0])}, ${fmtAngle(op.params[1])})</text></g>`;
    }
    if (op.gate === 'swap') {
      const xs = q => `<path class="link k-cross" d="M${cx - 6} ${y(q) - 6}l12 12M${cx + 6} ${y(q) - 6}l-12 12"/>`;
      return `<g>${t}<line class="link k-cross" x1="${cx}" x2="${cx}" y1="${y(gi.lo)}" y2="${y(gi.hi)}"/>${xs(op.qubits[0])}${xs(op.qubits[1])}</g>`;
    }
    if (op.gate === 'cz') {
      const [a, b] = op.qubits;
      return `<g>${t}<line class="link k-interlock" x1="${cx}" x2="${cx}" y1="${y(a)}" y2="${y(b)}"/><circle class="k-interlock" cx="${cx}" cy="${y(a)}" r="6"/><circle class="k-interlock" cx="${cx}" cy="${y(b)}" r="6"/></g>`;
    }
    if (op.gate === 'cx') {
      const [c, tq] = op.qubits;
      return `<g>${t}<line class="link" x1="${cx}" x2="${cx}" y1="${y(c)}" y2="${y(tq)}"/><circle class="dot" cx="${cx}" cy="${y(c)}" r="5"/>` +
        `<circle class="box k-station" cx="${cx}" cy="${y(tq)}" r="10"/><path class="link" d="M${cx - 10} ${y(tq)}h20M${cx} ${y(tq) - 10}v20"/></g>`;
    }
    // measure: a meter on every wire
    return `<g>${t}${circ.qubits.map((_, q) => `<rect class="box k-measure" x="${cx - 15}" y="${y(q) - 13}" width="30" height="26" rx="4"/>` +
      `<path class="link" d="M${cx - 9} ${y(q) + 6}a9 9 0 0 1 18 0M${cx} ${y(q) + 6}l6 -9" fill="none"/>`).join('')}</g>`;
  };

  for (const seg of segs) {
    const cols = [];                        // greedy packing: gates whose wire spans overlap go side by side
    for (const op of seg.gates) {
      const gi = gateInfo(op);
      let placed = cols.find(c => c.spans.every(([a, b]) => gi.hi < a || gi.lo > b));
      if (!placed) { placed = { spans: [], items: [], w: 0 }; cols.push(placed); }
      placed.spans.push([gi.lo, gi.hi]); placed.items.push([op, gi]); placed.w = Math.max(placed.w, gi.w);
    }
    for (const c of cols) {
      x += 8;
      for (const [op, gi] of c.items) parts.push(drawGate(op, gi, x + c.w / 2));
      x += c.w + 8;
    }
    if (seg.barrier !== null) {
      x = Math.max(x + 6, lastBarrier + 30);   // keep empty columns readable
      lastBarrier = x;
      parts.push(`<line class="bar-line" x1="${x}" x2="${x}" y1="${TOP - 20}" y2="${y(circ.qubits.length - 1) + 18}"/>` +
        `<text class="bar-label" x="${x}" y="${TOP - 22}" text-anchor="middle">${esc(seg.barrier)}</text>`);
      x += 6;
    }
  }
  x += 14;
  const height = y(circ.qubits.length - 1) + 26;
  const wires = circ.qubits.map((q, i) => `<text class="wname" x="${nameW - 6}" y="${y(i) + 4}" text-anchor="end">${esc(q)}</text>` +
    `<line class="wire" x1="${nameW}" x2="${x}" y1="${y(i)}" y2="${y(i)}"/>`).join('');
  return `<svg width="${x}" height="${height}" viewBox="0 0 ${x} ${height}" role="img" aria-label="Qiskit circuit ${esc(circ.name)}">${wires}${parts.join('')}</svg>`;
}

function renderHood() {
  if (!L) return;
  const groups = L.groups();
  if (hoodGroup >= groups.length) hoodGroup = 0;
  const group = groups[hoodGroup];
  const circ = buildCircuit(L, build, group);
  document.getElementById('hood-sub').textContent =
    `The Qiskit circuit for this build: one qubit per rail, one per station. Columns c1–c${L.columns} match the map.`;
  document.getElementById('hood-trains').innerHTML = groups.length > 1
    ? groups.map((g, i) => `<button class="chip" type="button" data-train="${i}" aria-pressed="${i === hoodGroup}">train ${esc(g[0].id)}</button>`).join('')
    : group.length > 1 ? `<span class="stats">${group.length} trains leave together: one circuit</span>` : '';
  document.getElementById('hood-circuit').innerHTML = circuitSVG(circ);

  // live check: simulate the circuit (statevector) and compare with the track physics the game animates;
  // next to it the ideal run (how many cars get each outcome) and, after a statistics run, the real shots
  const fromCircuit = circuitOutcomes(L, build, group), fromTrack = trackOutcomes(L, build, group);
  const ideal = idealRun(L, build), cars = {};
  for (const k of ideal.groups[hoodGroup].shots) cars[k] = (cars[k] ?? 0) + 1;
  const stats = shotStats.get(hoodGroup);
  const keys = [...new Set([...Object.keys(fromCircuit), ...Object.keys(fromTrack), ...Object.keys(stats?.counts ?? {})])]
    .sort((a, b) => (fromCircuit[b] ?? 0) - (fromCircuit[a] ?? 0) || (a < b ? -1 : 1));
  const agree = keys.every(k => Math.abs((fromCircuit[k] ?? 0) - (fromTrack[k] ?? 0)) < 1e-9);
  const nameOf = id => L.stations.find(s => s.id === id)?.name ?? id;
  const rows = keys.map(k => {
    const [stops, exit] = k.split('|');
    const n = stats?.counts[k] ?? 0;
    return `<tr><td>${stops ? stops.split(',').map(nameOf).map(esc).join(' → ') : '—'}</td><td>${exit === 'derail' ? 'derailed (noise)' : esc(exit)}</td>` +
      `<td class="num">${((fromCircuit[k] ?? 0) * 100).toFixed(1)}%</td><td class="num">${((fromTrack[k] ?? 0) * 100).toFixed(1)}%</td>` +
      `<td class="num">${cars[k] ?? 0}</td>` +
      `<td class="num">${stats ? `${n} <small>(${(100 * n / stats.shots).toFixed(1)}%)</small>` : '—'}</td></tr>`;
  }).join('');
  const k = ideal.cars;
  document.getElementById('hood-check').innerHTML =
    `<h3>Where the ${group.length > 1 ? 'trains end' : 'train ends'} up</h3><table><thead><tr><th>Stations that saw a train</th><th>Exit ${group.length > 1 ? 'rails' : 'rail'}</th>` +
    `<th>Circuit</th><th>Train physics</th><th>Ideal run<br>(${k} car${k === 1 ? '' : 's'})</th><th>Shots${stats ? `<br>(${stats.shots})` : ''}</th></tr></thead><tbody>${rows}</tbody></table>` +
    `<span class="verdict ${agree ? 'good' : 'bad'}">${agree ? '✓ Circuit and train physics agree' : '✗ Circuit and train physics disagree'}</span>` +
    `<div class="statrun"><button type="button" id="stat-run"${shotBusy || ionqJobUsed ? ' disabled' : ''}>${shotBusy ? 'Running…' : `Run ${STAT_SHOTS} shots`}</button>` +
    `<p>${shotError ? `<b class="bad">The job failed: ${esc(shotError)}</b> ` : ''}` +
    `${ionqJobUsed ? 'IonQ allows one job per Qollab run: press Run in Qollab again to send another. ' : ''}` +
    `${stats ? `${stats.shots} shots on ${esc(stats.source)}. ` : qollab ? 'The shots run as one job on the backend picked in Qollab\'s Select QPU dialog (on IonQ, for the train shown here). ' : ''}` +
    `The ideal run (what Run plays and scores) gives each outcome exactly its share of the cars. ` +
    `Real shots are random: they wander around the exact probabilities, by about ±${(100 / Math.sqrt(STAT_SHOTS)).toFixed(0)}% for ${STAT_SHOTS} shots.</p></div>`;
  document.getElementById('hood-code').textContent = toQiskitPython(L, circ);
}
// ── statistics run: real shots of the circuit, for comparison only (they don't change the score).
// On Qollab (tools/build_qollab.py) main.js imports the Python bridge quantrain.qollab, and the shots run as ONE
// job on the backend picked in Qollab's "Select QPU" dialog. Anywhere else they are drawn in the browser from
// the circuit's exact statevector probabilities.
const STAT_SHOTS = 1000;
let shotStats = new Map(), shotBusy = false, shotError = '', ionqJobUsed = false;   // hood group → { shots, counts, source }
// Qollab ends a run when main.js finishes, and IonQ refuses jobs after that, so on Qollab main.js waits
// (last line) until the first "Run 1000 shots" is done.
let releaseRun;
const firstShotsDone = new Promise(resolve => { releaseRun = resolve; });
const qollab = typeof quantrainBridge !== 'undefined' && typeof backend !== 'undefined' ? { bridge: quantrainBridge, backend } : null;   // eslint-disable-line no-undef
if (qollab) console.log('Quantrain is running. Play in the page above; "Under the hood" → "Run 1000 shots" sends one job to the backend you picked.');
const shotRunner = {
  async runAll(shots) {                            // → { source, groups: [counts by outcome, one per circuit] }
    if (qollab) {
      // on IonQ the bridge sends only the circuit of the train shown (hoodGroup); locally, every train in one job
      const raw = await qollab.bridge.run_shots.callPromising(qollab.backend, JSON.stringify(L.source), JSON.stringify(placements), shots, hoodGroup);
      const out = JSON.parse(String(raw));
      if (/ionq/i.test(out.backend)) ionqJobUsed = true;   // IonQ backends take one job per Qollab run
      return { source: out.backend, groups: out.groups, first: out.first ?? 0 };
    }
    const groups = L.groups().map(group => {
      const probs = Object.entries(circuitOutcomes(L, build, group));
      const counts = {};
      for (let i = 0; i < shots; i++) {
        let r = Math.random(), k = probs[probs.length - 1][0];
        for (const [key, p] of probs) { if ((r -= p) <= 0) { k = key; break; } }
        counts[k] = (counts[k] ?? 0) + 1;
      }
      return counts;
    });
    return { source: 'local simulator (in your browser)', groups, first: 0 };
  },
};
document.getElementById('hood-check').addEventListener('click', async e => {
  if (!e.target.closest('#stat-run') || shotBusy || ionqJobUsed) return;
  shotBusy = true;
  shotError = '';
  renderHood();
  const stamp = build;
  try {
    const res = await shotRunner.runAll(STAT_SHOTS);
    if (stamp === build) res.groups.forEach((counts, i) => shotStats.set(res.first + i, { shots: STAT_SHOTS, counts, source: res.source }));
  } catch (err) {
    shotError = String(err?.message ?? err).split('\n').filter(Boolean).slice(-1)[0] ?? 'unknown error';
  } finally { shotBusy = false; renderHood(); releaseRun(); }
});
document.getElementById('hood-trains').addEventListener('click', e => {
  const b = e.target.closest('[data-train]');
  if (b) { hoodGroup = +b.dataset.train; renderHood(); }
});
function setHood(open) {
  if (open && makerOpen()) setMaker(false);
  hood.hidden = !open;
  document.body.classList.toggle('hood-open', open);
  document.querySelector('.bar').hidden = open;
  // with the circuit open, the palette moves into its header (compact), so the map keeps its space
  const palette = document.getElementById('palette');
  palette.classList.toggle('compact', open);
  if (open) document.querySelector('#hood .hood-head').insertBefore(palette, document.getElementById('hood-close'));
  else dock.insertBefore(palette, dock.firstChild);
  for (const l of rulerLabels) l.el.hidden = !open;
  if (open) renderHood();
  fit();
}
document.getElementById('hood-close').addEventListener('click', () => setHood(false));
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !hood.hidden) setHood(false); });
document.getElementById('hood-copy').addEventListener('click', async e => {
  const text = document.getElementById('hood-code').textContent;
  try { await navigator.clipboard.writeText(text); e.target.textContent = 'Copied'; }
  catch { const r = document.createRange(); r.selectNodeContents(document.getElementById('hood-code')); getSelection().removeAllRanges(); getSelection().addRange(r); e.target.textContent = 'Selected, press Ctrl/⌘+C'; }
  window.setTimeout(() => { e.target.textContent = 'Copy code'; }, 1800);
});

// ───────────────────────── playground ─────────────────────────
// Everything is buildable and unlimited, including stations and trains; + buttons add columns and tracks.
// Limits keep every circuit small enough to check exactly in the browser and to run on IonQ in one job.
const PG = LIMITS;                                 // engine: 8 tracks, 10 columns, 20 qubits, 4 trains
const PG_KEY = 'quantrain:playground';
const railName = k => String.fromCharCode(65 + k);
const PG_START = () => ({ rails: 3, columns: 5, together: false, trains: [{ slot: 0, rail: 'A' }],
  stations: [{ col: 5, rail: 'A' }, { col: 5, rail: 'B' }, { col: 5, rail: 'C' }], placements: [] });
const clonePg = g => JSON.parse(JSON.stringify(g));
let pg = null;

function makePgLevel(g) {
  const rails = Array.from({ length: g.rails }, (_, k) => railName(k));
  const ri = r => rails.indexOf(r);
  if (g.rails < 1 || g.rails > PG.maxRails || g.columns < 1 || g.columns > PG.maxColumns) throw new LevelError('playground size');
  if (g.rails + g.stations.length > PG.maxQubits || !g.trains.length || g.trains.length > PG.maxTrains) throw new LevelError('playground limits');
  if (g.stations.some(st => ri(st.rail) < 0 || st.col < 1 || st.col > g.columns)) throw new LevelError('station off the grid');
  const trains = [...g.trains].sort((a, b) => ri(a.rail) - ri(b.rail));
  const data = {
    format: FORMAT, id: 'playground', name: 'Playground', rails, columns: g.columns,
    blurb: 'Build anything: every block, station and train is free. The + buttons add columns and tracks.',
    dispatch: g.together ? 'together' : 'sequential',
    trains: trains.map((t, k) => {
      const d = { id: TRAIN_KINDS[t.slot][0], colour: TRAIN_KINDS[t.slot][1], depot: t.rail };
      if (g.together) {                            // each train owns the tracks from its depot down to the next train's
        const from = k === 0 ? 0 : ri(t.rail), to = k + 1 < trains.length ? ri(trains[k + 1].rail) : rails.length;
        d.rails = rails.slice(from, to);
      }
      return d;
    }),
    slots: [], stations: [], supply: { twist: null, points: null, cross: null }, solutions: {},
  };
  if (g.together && trains.length > 1) data.supply.interlock = null;
  const taken = new Set(g.stations.map(st => cellKey(st.col, st.rail)));
  for (let c = 1; c <= g.columns; c++) {
    const free = rails.filter(r => !taken.has(cellKey(c, r)));
    if (free.length) data.slots.push({ col: c, rails: free });
  }
  const keyOf = st => cellKey(st.col, st.rail);
  data.stations = [...g.stations].sort((a, b) => a.col - b.col || ri(a.rail) - ri(b.rail)).map((st, i) => {
    const n = Math.max(0, Math.min(LIMITS.maxPassengers, st.n ?? 2));
    const d = { id: `s${st.col}${st.rail}`, name: `Stop ${st.rail}${st.col}`, rail: st.rail, col: st.col,
      passengers: Array.from({ length: n }, (_, k) => SHAPE_NAMES[(i + k) % 3]) };
    const partner = st.partner && g.stations.find(o => keyOf(o) === st.partner);
    if (partner && partner.partner === keyOf(st)) d.partner = `s${partner.col}${partner.rail}`;
    return d;
  });
  if (g.cars) data.cars = g.cars;
  return parseLevel(data);
}
// Apply a new playground state: rebuild the level, keep the blocks that are still legal, save.
function tidyPg(g) {                              // couples must name each other; marks only on real cells
  const keys = new Set(g.stations.map(st => cellKey(st.col, st.rail)));
  for (const st of g.stations) {
    const other = st.partner && g.stations.find(o => cellKey(o.col, o.rail) === st.partner);
    if (st.partner && (!other || other.partner !== cellKey(st.col, st.rail))) delete st.partner;
  }
  g.blocked = (g.blocked ?? []).filter(k => { const [c, r] = k.split('/'); return +c >= 1 && +c <= g.columns && r.charCodeAt(0) - 65 < g.rails && !keys.has(k); });
}
function renameRails(g, f) {                      // after a track is added / removed at the top: every letter moves
  const re = k => { const [c, r] = k.split('/'); return `${c}/${f(r)}`; };
  g.trains.forEach(t => { t.rail = f(t.rail); });
  g.stations.forEach(st => { st.rail = f(st.rail); if (st.partner) st.partner = re(st.partner); });
  g.placements.forEach(p => { p.rails = p.rails.map(f); });
  g.blocked = (g.blocked ?? []).map(re);
}
function pgCommit(next, { save = true, refit = false } = {}) {
  tidyPg(next);
  let Lnext;
  try { Lnext = makePgLevel(next); } catch (err) { console.warn('playground:', err.message); return false; }
  const kept = [];
  for (const p of next.placements) { try { layout(Lnext, [...kept, p]); kept.push(p); } catch { /* no longer fits */ } }
  next.placements = kept;
  pg = next; L = Lnext; placements = kept;
  if (save) store.set(PG_KEY, pg);
  setupPalette();
  rebuild();
  if (refit) fit();
  return true;
}
function enterPlayground(initial = null) {
  mode = 'playground';
  puzzleCtx = null;
  document.body.classList.remove('puzzle', 'puzzle-test');
  document.body.classList.add('playground');
  levelIndex = -1;
  const saved = initial ?? store.get(PG_KEY);
  let ok = false;
  if (saved) { try { makePgLevel(saved); ok = true; } catch { /* broken save: start fresh */ } }
  document.getElementById('title').textContent = 'Playground';
  document.getElementById('back').textContent = '‹ Menu';
  pgCommit(ok ? saved : PG_START(), { save: !!initial });
  document.getElementById('blurb').textContent = L.blurb;
  applyTheme();
  fit();
}
function pgAdd(where) {
  if (busy()) return;
  const g = clonePg(pg);
  if (where === 'column') g.columns += 1;
  else {
    g.rails += 1;
    if (where === 'top') renameRails(g, r => railName(r.charCodeAt(0) - 64));   // a track above: every rail moves down one letter
  }
  pgCommit(g, { refit: true });
}
document.getElementById('pg-dispatch').addEventListener('click', e => {
  const b = e.target.closest('[data-dispatch]');
  if (!b || busy() || mode !== 'playground') return;
  const g = clonePg(pg);
  g.together = b.dataset.dispatch === 'together';
  if (g.together !== pg.together) pgCommit(g);
});
const plusEl = document.getElementById('plus');
plusEl.addEventListener('click', e => {
  const b = e.target.closest('button');
  if (!b || b.disabled) return;
  if (b.dataset.add) pgAdd(b.dataset.add); else pgRemove(b.dataset.remove);
});
// − removes the last column, or the top / bottom track, with whatever stood there (blocks, stations, a train)
function removable(where) {
  if (where === 'column') return pg.columns > 1;
  const rail = where === 'top' ? 'A' : railName(pg.rails - 1);
  return pg.rails > 1 && pg.trains.some(t => t.rail !== rail);
}
function pgRemove(where) {
  if (busy() || !removable(where)) return;
  const g = clonePg(pg);
  if (where === 'column') {
    g.blocked = (g.blocked ?? []).filter(k => +k.split('/')[0] !== g.columns);
    g.stations = g.stations.filter(st => st.col !== g.columns);
    g.placements = g.placements.filter(p => p.col !== g.columns);
    g.columns -= 1;
  } else {
    const gone = where === 'top' ? 'A' : railName(g.rails - 1);
    g.trains = g.trains.filter(t => t.rail !== gone);
    g.stations = g.stations.filter(st => st.rail !== gone);
    g.placements = g.placements.filter(p => !p.rails.includes(gone));
    g.rails -= 1;
    g.blocked = (g.blocked ?? []).filter(k => k.split('/')[1] !== gone);
    if (where === 'top') renameRails(g, r => railName(r.charCodeAt(0) - 66));   // every rail moves up one letter
  }
  pgCommit(g, { refit: true });
}
function updatePlus() {
  plusEl.hidden = mode !== 'playground' || screen !== 'game' || busy() || makerOpen();
  if (plusEl.hidden || !L) return;
  const qubitsFull = L.rails.length + L.stations.length >= PG.maxQubits;
  for (const b of plusEl.querySelectorAll('[data-add]')) {
    const full = b.dataset.add === 'column' ? L.columns >= PG.maxColumns : L.rails.length >= PG.maxRails || qubitsFull;
    b.disabled = full;
    b.title = full ? (b.dataset.add === 'column' ? `at most ${PG.maxColumns} columns` : `at most ${PG.maxRails} tracks and ${PG.maxQubits} qubits (tracks + stations)`) : '';
  }
  for (const b of plusEl.querySelectorAll('[data-remove]')) {
    b.disabled = !removable(b.dataset.remove);
    b.title = b.disabled ? 'the line keeps at least one column, one track and one train' : '';
  }
}
const plusWorld = new THREE.Vector3();
function placePlus() {
  if (plusEl.hidden || !L) return;
  const r = renderer.domElement.getBoundingClientRect();
  const zTop = railZ(0) - RAIL_GAP * 0.62, zBottom = railZ(L.rails.length - 1) + RAIL_GAP * 0.62;
  const at = { column: [exitX() + 2.4, (zTop + zBottom) / 2], top: [depotX() - 1.6, zTop], bottom: [depotX() - 1.6, zBottom] };   // depot end: platforms never stand there
  for (const pill of plusEl.querySelectorAll('.pill')) {
    const [x, z] = at[pill.dataset.at];
    plusWorld.set(x, H, z).project(camera);
    pill.style.transform = `translate(${r.left + (plusWorld.x + 1) / 2 * r.width}px, ${r.top + (1 - plusWorld.y) / 2 * r.height}px) translate(-50%, -50%)`;
  }
}

// ───────────────────────── community puzzles: make, test, share, open, remix ─────────────────────────
// A puzzle is a playground design packed into a short code (engine: encodePuzzle). The code travels in a link after
// '#p=' (the part of a URL that never reaches a server), in a QR code, or as plain text. Nothing is uploaded anywhere.
// Everything already on the map is fixed for the player; they build only on the cells the maker left open.
//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//  http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

var qrcode = function() {

  //---------------------------------------------------------------------
  // qrcode
  //---------------------------------------------------------------------

  /**
   * qrcode
   * @param typeNumber 1 to 40
   * @param errorCorrectionLevel 'L','M','Q','H'
   */
  var qrcode = function(typeNumber, errorCorrectionLevel) {

    var PAD0 = 0xEC;
    var PAD1 = 0x11;

    var _typeNumber = typeNumber;
    var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
    var _modules = null;
    var _moduleCount = 0;
    var _dataCache = null;
    var _dataList = [];

    var _this = {};

    var makeImpl = function(test, maskPattern) {

      _moduleCount = _typeNumber * 4 + 17;
      _modules = function(moduleCount) {
        var modules = new Array(moduleCount);
        for (var row = 0; row < moduleCount; row += 1) {
          modules[row] = new Array(moduleCount);
          for (var col = 0; col < moduleCount; col += 1) {
            modules[row][col] = null;
          }
        }
        return modules;
      }(_moduleCount);

      setupPositionProbePattern(0, 0);
      setupPositionProbePattern(_moduleCount - 7, 0);
      setupPositionProbePattern(0, _moduleCount - 7);
      setupPositionAdjustPattern();
      setupTimingPattern();
      setupTypeInfo(test, maskPattern);

      if (_typeNumber >= 7) {
        setupTypeNumber(test);
      }

      if (_dataCache == null) {
        _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
      }

      mapData(_dataCache, maskPattern);
    };

    var setupPositionProbePattern = function(row, col) {

      for (var r = -1; r <= 7; r += 1) {

        if (row + r <= -1 || _moduleCount <= row + r) continue;

        for (var c = -1; c <= 7; c += 1) {

          if (col + c <= -1 || _moduleCount <= col + c) continue;

          if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
              || (0 <= c && c <= 6 && (r == 0 || r == 6) )
              || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
            _modules[row + r][col + c] = true;
          } else {
            _modules[row + r][col + c] = false;
          }
        }
      }
    };

    var getBestMaskPattern = function() {

      var minLostPoint = 0;
      var pattern = 0;

      for (var i = 0; i < 8; i += 1) {

        makeImpl(true, i);

        var lostPoint = QRUtil.getLostPoint(_this);

        if (i == 0 || minLostPoint > lostPoint) {
          minLostPoint = lostPoint;
          pattern = i;
        }
      }

      return pattern;
    };

    var setupTimingPattern = function() {

      for (var r = 8; r < _moduleCount - 8; r += 1) {
        if (_modules[r][6] != null) {
          continue;
        }
        _modules[r][6] = (r % 2 == 0);
      }

      for (var c = 8; c < _moduleCount - 8; c += 1) {
        if (_modules[6][c] != null) {
          continue;
        }
        _modules[6][c] = (c % 2 == 0);
      }
    };

    var setupPositionAdjustPattern = function() {

      var pos = QRUtil.getPatternPosition(_typeNumber);

      for (var i = 0; i < pos.length; i += 1) {

        for (var j = 0; j < pos.length; j += 1) {

          var row = pos[i];
          var col = pos[j];

          if (_modules[row][col] != null) {
            continue;
          }

          for (var r = -2; r <= 2; r += 1) {

            for (var c = -2; c <= 2; c += 1) {

              if (r == -2 || r == 2 || c == -2 || c == 2
                  || (r == 0 && c == 0) ) {
                _modules[row + r][col + c] = true;
              } else {
                _modules[row + r][col + c] = false;
              }
            }
          }
        }
      }
    };

    var setupTypeNumber = function(test) {

      var bits = QRUtil.getBCHTypeNumber(_typeNumber);

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
      }

      for (var i = 0; i < 18; i += 1) {
        var mod = (!test && ( (bits >> i) & 1) == 1);
        _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
      }
    };

    var setupTypeInfo = function(test, maskPattern) {

      var data = (_errorCorrectionLevel << 3) | maskPattern;
      var bits = QRUtil.getBCHTypeInfo(data);

      // vertical
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 6) {
          _modules[i][8] = mod;
        } else if (i < 8) {
          _modules[i + 1][8] = mod;
        } else {
          _modules[_moduleCount - 15 + i][8] = mod;
        }
      }

      // horizontal
      for (var i = 0; i < 15; i += 1) {

        var mod = (!test && ( (bits >> i) & 1) == 1);

        if (i < 8) {
          _modules[8][_moduleCount - i - 1] = mod;
        } else if (i < 9) {
          _modules[8][15 - i - 1 + 1] = mod;
        } else {
          _modules[8][15 - i - 1] = mod;
        }
      }

      // fixed module
      _modules[_moduleCount - 8][8] = (!test);
    };

    var mapData = function(data, maskPattern) {

      var inc = -1;
      var row = _moduleCount - 1;
      var bitIndex = 7;
      var byteIndex = 0;
      var maskFunc = QRUtil.getMaskFunction(maskPattern);

      for (var col = _moduleCount - 1; col > 0; col -= 2) {

        if (col == 6) col -= 1;

        while (true) {

          for (var c = 0; c < 2; c += 1) {

            if (_modules[row][col - c] == null) {

              var dark = false;

              if (byteIndex < data.length) {
                dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
              }

              var mask = maskFunc(row, col - c);

              if (mask) {
                dark = !dark;
              }

              _modules[row][col - c] = dark;
              bitIndex -= 1;

              if (bitIndex == -1) {
                byteIndex += 1;
                bitIndex = 7;
              }
            }
          }

          row += inc;

          if (row < 0 || _moduleCount <= row) {
            row -= inc;
            inc = -inc;
            break;
          }
        }
      }
    };

    var createBytes = function(buffer, rsBlocks) {

      var offset = 0;

      var maxDcCount = 0;
      var maxEcCount = 0;

      var dcdata = new Array(rsBlocks.length);
      var ecdata = new Array(rsBlocks.length);

      for (var r = 0; r < rsBlocks.length; r += 1) {

        var dcCount = rsBlocks[r].dataCount;
        var ecCount = rsBlocks[r].totalCount - dcCount;

        maxDcCount = Math.max(maxDcCount, dcCount);
        maxEcCount = Math.max(maxEcCount, ecCount);

        dcdata[r] = new Array(dcCount);

        for (var i = 0; i < dcdata[r].length; i += 1) {
          dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
        }
        offset += dcCount;

        var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
        var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

        var modPoly = rawPoly.mod(rsPoly);
        ecdata[r] = new Array(rsPoly.getLength() - 1);
        for (var i = 0; i < ecdata[r].length; i += 1) {
          var modIndex = i + modPoly.getLength() - ecdata[r].length;
          ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
        }
      }

      var totalCodeCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalCodeCount += rsBlocks[i].totalCount;
      }

      var data = new Array(totalCodeCount);
      var index = 0;

      for (var i = 0; i < maxDcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < dcdata[r].length) {
            data[index] = dcdata[r][i];
            index += 1;
          }
        }
      }

      for (var i = 0; i < maxEcCount; i += 1) {
        for (var r = 0; r < rsBlocks.length; r += 1) {
          if (i < ecdata[r].length) {
            data[index] = ecdata[r][i];
            index += 1;
          }
        }
      }

      return data;
    };

    var createData = function(typeNumber, errorCorrectionLevel, dataList) {

      var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);

      var buffer = qrBitBuffer();

      for (var i = 0; i < dataList.length; i += 1) {
        var data = dataList[i];
        buffer.put(data.getMode(), 4);
        buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
        data.write(buffer);
      }

      // calc num max data.
      var totalDataCount = 0;
      for (var i = 0; i < rsBlocks.length; i += 1) {
        totalDataCount += rsBlocks[i].dataCount;
      }

      if (buffer.getLengthInBits() > totalDataCount * 8) {
        throw 'code length overflow. ('
          + buffer.getLengthInBits()
          + '>'
          + totalDataCount * 8
          + ')';
      }

      // end code
      if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
        buffer.put(0, 4);
      }

      // padding
      while (buffer.getLengthInBits() % 8 != 0) {
        buffer.putBit(false);
      }

      // padding
      while (true) {

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD0, 8);

        if (buffer.getLengthInBits() >= totalDataCount * 8) {
          break;
        }
        buffer.put(PAD1, 8);
      }

      return createBytes(buffer, rsBlocks);
    };

    _this.addData = function(data, mode) {

      mode = mode || 'Byte';

      var newData = null;

      switch(mode) {
      case 'Numeric' :
        newData = qrNumber(data);
        break;
      case 'Alphanumeric' :
        newData = qrAlphaNum(data);
        break;
      case 'Byte' :
        newData = qr8BitByte(data);
        break;
      case 'Kanji' :
        newData = qrKanji(data);
        break;
      default :
        throw 'mode:' + mode;
      }

      _dataList.push(newData);
      _dataCache = null;
    };

    _this.isDark = function(row, col) {
      if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
        throw row + ',' + col;
      }
      return _modules[row][col];
    };

    _this.getModuleCount = function() {
      return _moduleCount;
    };

    _this.make = function() {
      if (_typeNumber < 1) {
        var typeNumber = 1;

        for (; typeNumber < 40; typeNumber++) {
          var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
          var buffer = qrBitBuffer();

          for (var i = 0; i < _dataList.length; i++) {
            var data = _dataList[i];
            buffer.put(data.getMode(), 4);
            buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
            data.write(buffer);
          }

          var totalDataCount = 0;
          for (var i = 0; i < rsBlocks.length; i++) {
            totalDataCount += rsBlocks[i].dataCount;
          }

          if (buffer.getLengthInBits() <= totalDataCount * 8) {
            break;
          }
        }

        _typeNumber = typeNumber;
      }

      makeImpl(false, getBestMaskPattern() );
    };

    _this.createTableTag = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var qrHtml = '';

      qrHtml += '<table style="';
      qrHtml += ' border-width: 0px; border-style: none;';
      qrHtml += ' border-collapse: collapse;';
      qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
      qrHtml += '">';
      qrHtml += '<tbody>';

      for (var r = 0; r < _this.getModuleCount(); r += 1) {

        qrHtml += '<tr>';

        for (var c = 0; c < _this.getModuleCount(); c += 1) {
          qrHtml += '<td style="';
          qrHtml += ' border-width: 0px; border-style: none;';
          qrHtml += ' border-collapse: collapse;';
          qrHtml += ' padding: 0px; margin: 0px;';
          qrHtml += ' width: ' + cellSize + 'px;';
          qrHtml += ' height: ' + cellSize + 'px;';
          qrHtml += ' background-color: ';
          qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
          qrHtml += ';';
          qrHtml += '"/>';
        }

        qrHtml += '</tr>';
      }

      qrHtml += '</tbody>';
      qrHtml += '</table>';

      return qrHtml;
    };

    _this.createSvgTag = function(cellSize, margin, alt, title) {

      var opts = {};
      if (typeof arguments[0] == 'object') {
        // Called by options.
        opts = arguments[0];
        // overwrite cellSize and margin.
        cellSize = opts.cellSize;
        margin = opts.margin;
        alt = opts.alt;
        title = opts.title;
      }

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      // Compose alt property surrogate
      alt = (typeof alt === 'string') ? {text: alt} : alt || {};
      alt.text = alt.text || null;
      alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;

      // Compose title property surrogate
      title = (typeof title === 'string') ? {text: title} : title || {};
      title.text = title.text || null;
      title.id = (title.text) ? title.id || 'qrcode-title' : null;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var c, mc, r, mr, qrSvg='', rect;

      rect = 'l' + cellSize + ',0 0,' + cellSize +
        ' -' + cellSize + ',0 0,-' + cellSize + 'z ';

      qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
      qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
      qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
      qrSvg += ' preserveAspectRatio="xMinYMin meet"';
      qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
          escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
      qrSvg += '>';
      qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
          escapeXml(title.text) + '</title>' : '';
      qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
          escapeXml(alt.text) + '</description>' : '';
      qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
      qrSvg += '<path d="';

      for (r = 0; r < _this.getModuleCount(); r += 1) {
        mr = r * cellSize + margin;
        for (c = 0; c < _this.getModuleCount(); c += 1) {
          if (_this.isDark(r, c) ) {
            mc = c*cellSize+margin;
            qrSvg += 'M' + mc + ',' + mr + rect;
          }
        }
      }

      qrSvg += '" stroke="transparent" fill="black"/>';
      qrSvg += '</svg>';

      return qrSvg;
    };

    _this.createDataURL = function(cellSize, margin) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      return createDataURL(size, size, function(x, y) {
        if (min <= x && x < max && min <= y && y < max) {
          var c = Math.floor( (x - min) / cellSize);
          var r = Math.floor( (y - min) / cellSize);
          return _this.isDark(r, c)? 0 : 1;
        } else {
          return 1;
        }
      } );
    };

    _this.createImgTag = function(cellSize, margin, alt) {

      cellSize = cellSize || 2;
      margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;

      var img = '';
      img += '<img';
      img += '\u0020src="';
      img += _this.createDataURL(cellSize, margin);
      img += '"';
      img += '\u0020width="';
      img += size;
      img += '"';
      img += '\u0020height="';
      img += size;
      img += '"';
      if (alt) {
        img += '\u0020alt="';
        img += escapeXml(alt);
        img += '"';
      }
      img += '/>';

      return img;
    };

    var escapeXml = function(s) {
      var escaped = '';
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charAt(i);
        switch(c) {
        case '<': escaped += '&lt;'; break;
        case '>': escaped += '&gt;'; break;
        case '&': escaped += '&amp;'; break;
        case '"': escaped += '&quot;'; break;
        default : escaped += c; break;
        }
      }
      return escaped;
    };

    var _createHalfASCII = function(margin) {
      var cellSize = 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r1, r2, p;

      var blocks = {
        '██': '█',
        '█ ': '▀',
        ' █': '▄',
        '  ': ' '
      };

      var blocksLastLineNoMargin = {
        '██': '▀',
        '█ ': '▀',
        ' █': ' ',
        '  ': ' '
      };

      var ascii = '';
      for (y = 0; y < size; y += 2) {
        r1 = Math.floor((y - min) / cellSize);
        r2 = Math.floor((y + 1 - min) / cellSize);
        for (x = 0; x < size; x += 1) {
          p = '█';

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
            p = ' ';
          }

          if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
            p += ' ';
          }
          else {
            p += '█';
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
        }

        ascii += '\n';
      }

      if (size % 2 && margin > 0) {
        return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.createASCII = function(cellSize, margin) {
      cellSize = cellSize || 1;

      if (cellSize < 2) {
        return _createHalfASCII(margin);
      }

      cellSize -= 1;
      margin = (typeof margin == 'undefined')? cellSize * 2 : margin;

      var size = _this.getModuleCount() * cellSize + margin * 2;
      var min = margin;
      var max = size - margin;

      var y, x, r, p;

      var white = Array(cellSize+1).join('██');
      var black = Array(cellSize+1).join('  ');

      var ascii = '';
      var line = '';
      for (y = 0; y < size; y += 1) {
        r = Math.floor( (y - min) / cellSize);
        line = '';
        for (x = 0; x < size; x += 1) {
          p = 1;

          if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
            p = 0;
          }

          // Output 2 characters per pixel, to create full square. 1 character per pixels gives only half width of square.
          line += p ? white : black;
        }

        for (r = 0; r < cellSize; r += 1) {
          ascii += line + '\n';
        }
      }

      return ascii.substring(0, ascii.length-1);
    };

    _this.renderTo2dContext = function(context, cellSize) {
      cellSize = cellSize || 2;
      var length = _this.getModuleCount();
      for (var row = 0; row < length; row++) {
        for (var col = 0; col < length; col++) {
          context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
          context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
        }
      }
    }

    return _this;
  };

  //---------------------------------------------------------------------
  // qrcode.stringToBytes
  //---------------------------------------------------------------------

  qrcode.stringToBytesFuncs = {
    'default' : function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        bytes.push(c & 0xff);
      }
      return bytes;
    }
  };

  qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];

  //---------------------------------------------------------------------
  // qrcode.createStringToBytes
  //---------------------------------------------------------------------

  /**
   * @param unicodeData base64 string of byte array.
   * [16bit Unicode],[16bit Bytes], ...
   * @param numChars
   */
  qrcode.createStringToBytes = function(unicodeData, numChars) {

    // create conversion map.

    var unicodeMap = function() {

      var bin = base64DecodeInputStream(unicodeData);
      var read = function() {
        var b = bin.read();
        if (b == -1) throw 'eof';
        return b;
      };

      var count = 0;
      var unicodeMap = {};
      while (true) {
        var b0 = bin.read();
        if (b0 == -1) break;
        var b1 = read();
        var b2 = read();
        var b3 = read();
        var k = String.fromCharCode( (b0 << 8) | b1);
        var v = (b2 << 8) | b3;
        unicodeMap[k] = v;
        count += 1;
      }
      if (count != numChars) {
        throw count + ' != ' + numChars;
      }

      return unicodeMap;
    }();

    var unknownChar = '?'.charCodeAt(0);

    return function(s) {
      var bytes = [];
      for (var i = 0; i < s.length; i += 1) {
        var c = s.charCodeAt(i);
        if (c < 128) {
          bytes.push(c);
        } else {
          var b = unicodeMap[s.charAt(i)];
          if (typeof b == 'number') {
            if ( (b & 0xff) == b) {
              // 1byte
              bytes.push(b);
            } else {
              // 2bytes
              bytes.push(b >>> 8);
              bytes.push(b & 0xff);
            }
          } else {
            bytes.push(unknownChar);
          }
        }
      }
      return bytes;
    };
  };

  //---------------------------------------------------------------------
  // QRMode
  //---------------------------------------------------------------------

  var QRMode = {
    MODE_NUMBER :    1 << 0,
    MODE_ALPHA_NUM : 1 << 1,
    MODE_8BIT_BYTE : 1 << 2,
    MODE_KANJI :     1 << 3
  };

  //---------------------------------------------------------------------
  // QRErrorCorrectionLevel
  //---------------------------------------------------------------------

  var QRErrorCorrectionLevel = {
    L : 1,
    M : 0,
    Q : 3,
    H : 2
  };

  //---------------------------------------------------------------------
  // QRMaskPattern
  //---------------------------------------------------------------------

  var QRMaskPattern = {
    PATTERN000 : 0,
    PATTERN001 : 1,
    PATTERN010 : 2,
    PATTERN011 : 3,
    PATTERN100 : 4,
    PATTERN101 : 5,
    PATTERN110 : 6,
    PATTERN111 : 7
  };

  //---------------------------------------------------------------------
  // QRUtil
  //---------------------------------------------------------------------

  var QRUtil = function() {

    var PATTERN_POSITION_TABLE = [
      [],
      [6, 18],
      [6, 22],
      [6, 26],
      [6, 30],
      [6, 34],
      [6, 22, 38],
      [6, 24, 42],
      [6, 26, 46],
      [6, 28, 50],
      [6, 30, 54],
      [6, 32, 58],
      [6, 34, 62],
      [6, 26, 46, 66],
      [6, 26, 48, 70],
      [6, 26, 50, 74],
      [6, 30, 54, 78],
      [6, 30, 56, 82],
      [6, 30, 58, 86],
      [6, 34, 62, 90],
      [6, 28, 50, 72, 94],
      [6, 26, 50, 74, 98],
      [6, 30, 54, 78, 102],
      [6, 28, 54, 80, 106],
      [6, 32, 58, 84, 110],
      [6, 30, 58, 86, 114],
      [6, 34, 62, 90, 118],
      [6, 26, 50, 74, 98, 122],
      [6, 30, 54, 78, 102, 126],
      [6, 26, 52, 78, 104, 130],
      [6, 30, 56, 82, 108, 134],
      [6, 34, 60, 86, 112, 138],
      [6, 30, 58, 86, 114, 142],
      [6, 34, 62, 90, 118, 146],
      [6, 30, 54, 78, 102, 126, 150],
      [6, 24, 50, 76, 102, 128, 154],
      [6, 28, 54, 80, 106, 132, 158],
      [6, 32, 58, 84, 110, 136, 162],
      [6, 26, 54, 82, 110, 138, 166],
      [6, 30, 58, 86, 114, 142, 170]
    ];
    var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
    var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
    var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

    var _this = {};

    var getBCHDigit = function(data) {
      var digit = 0;
      while (data != 0) {
        digit += 1;
        data >>>= 1;
      }
      return digit;
    };

    _this.getBCHTypeInfo = function(data) {
      var d = data << 10;
      while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
        d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
      }
      return ( (data << 10) | d) ^ G15_MASK;
    };

    _this.getBCHTypeNumber = function(data) {
      var d = data << 12;
      while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
        d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
      }
      return (data << 12) | d;
    };

    _this.getPatternPosition = function(typeNumber) {
      return PATTERN_POSITION_TABLE[typeNumber - 1];
    };

    _this.getMaskFunction = function(maskPattern) {

      switch (maskPattern) {

      case QRMaskPattern.PATTERN000 :
        return function(i, j) { return (i + j) % 2 == 0; };
      case QRMaskPattern.PATTERN001 :
        return function(i, j) { return i % 2 == 0; };
      case QRMaskPattern.PATTERN010 :
        return function(i, j) { return j % 3 == 0; };
      case QRMaskPattern.PATTERN011 :
        return function(i, j) { return (i + j) % 3 == 0; };
      case QRMaskPattern.PATTERN100 :
        return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
      case QRMaskPattern.PATTERN101 :
        return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
      case QRMaskPattern.PATTERN110 :
        return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
      case QRMaskPattern.PATTERN111 :
        return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

      default :
        throw 'bad maskPattern:' + maskPattern;
      }
    };

    _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
      var a = qrPolynomial([1], 0);
      for (var i = 0; i < errorCorrectLength; i += 1) {
        a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
      }
      return a;
    };

    _this.getLengthInBits = function(mode, type) {

      if (1 <= type && type < 10) {

        // 1 - 9

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 10;
        case QRMode.MODE_ALPHA_NUM : return 9;
        case QRMode.MODE_8BIT_BYTE : return 8;
        case QRMode.MODE_KANJI     : return 8;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 27) {

        // 10 - 26

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 12;
        case QRMode.MODE_ALPHA_NUM : return 11;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 10;
        default :
          throw 'mode:' + mode;
        }

      } else if (type < 41) {

        // 27 - 40

        switch(mode) {
        case QRMode.MODE_NUMBER    : return 14;
        case QRMode.MODE_ALPHA_NUM : return 13;
        case QRMode.MODE_8BIT_BYTE : return 16;
        case QRMode.MODE_KANJI     : return 12;
        default :
          throw 'mode:' + mode;
        }

      } else {
        throw 'type:' + type;
      }
    };

    _this.getLostPoint = function(qrcode) {

      var moduleCount = qrcode.getModuleCount();

      var lostPoint = 0;

      // LEVEL1

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount; col += 1) {

          var sameCount = 0;
          var dark = qrcode.isDark(row, col);

          for (var r = -1; r <= 1; r += 1) {

            if (row + r < 0 || moduleCount <= row + r) {
              continue;
            }

            for (var c = -1; c <= 1; c += 1) {

              if (col + c < 0 || moduleCount <= col + c) {
                continue;
              }

              if (r == 0 && c == 0) {
                continue;
              }

              if (dark == qrcode.isDark(row + r, col + c) ) {
                sameCount += 1;
              }
            }
          }

          if (sameCount > 5) {
            lostPoint += (3 + sameCount - 5);
          }
        }
      };

      // LEVEL2

      for (var row = 0; row < moduleCount - 1; row += 1) {
        for (var col = 0; col < moduleCount - 1; col += 1) {
          var count = 0;
          if (qrcode.isDark(row, col) ) count += 1;
          if (qrcode.isDark(row + 1, col) ) count += 1;
          if (qrcode.isDark(row, col + 1) ) count += 1;
          if (qrcode.isDark(row + 1, col + 1) ) count += 1;
          if (count == 0 || count == 4) {
            lostPoint += 3;
          }
        }
      }

      // LEVEL3

      for (var row = 0; row < moduleCount; row += 1) {
        for (var col = 0; col < moduleCount - 6; col += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row, col + 1)
              &&  qrcode.isDark(row, col + 2)
              &&  qrcode.isDark(row, col + 3)
              &&  qrcode.isDark(row, col + 4)
              && !qrcode.isDark(row, col + 5)
              &&  qrcode.isDark(row, col + 6) ) {
            lostPoint += 40;
          }
        }
      }

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount - 6; row += 1) {
          if (qrcode.isDark(row, col)
              && !qrcode.isDark(row + 1, col)
              &&  qrcode.isDark(row + 2, col)
              &&  qrcode.isDark(row + 3, col)
              &&  qrcode.isDark(row + 4, col)
              && !qrcode.isDark(row + 5, col)
              &&  qrcode.isDark(row + 6, col) ) {
            lostPoint += 40;
          }
        }
      }

      // LEVEL4

      var darkCount = 0;

      for (var col = 0; col < moduleCount; col += 1) {
        for (var row = 0; row < moduleCount; row += 1) {
          if (qrcode.isDark(row, col) ) {
            darkCount += 1;
          }
        }
      }

      var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
      lostPoint += ratio * 10;

      return lostPoint;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // QRMath
  //---------------------------------------------------------------------

  var QRMath = function() {

    var EXP_TABLE = new Array(256);
    var LOG_TABLE = new Array(256);

    // initialize tables
    for (var i = 0; i < 8; i += 1) {
      EXP_TABLE[i] = 1 << i;
    }
    for (var i = 8; i < 256; i += 1) {
      EXP_TABLE[i] = EXP_TABLE[i - 4]
        ^ EXP_TABLE[i - 5]
        ^ EXP_TABLE[i - 6]
        ^ EXP_TABLE[i - 8];
    }
    for (var i = 0; i < 255; i += 1) {
      LOG_TABLE[EXP_TABLE[i] ] = i;
    }

    var _this = {};

    _this.glog = function(n) {

      if (n < 1) {
        throw 'glog(' + n + ')';
      }

      return LOG_TABLE[n];
    };

    _this.gexp = function(n) {

      while (n < 0) {
        n += 255;
      }

      while (n >= 256) {
        n -= 255;
      }

      return EXP_TABLE[n];
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrPolynomial
  //---------------------------------------------------------------------

  function qrPolynomial(num, shift) {

    if (typeof num.length == 'undefined') {
      throw num.length + '/' + shift;
    }

    var _num = function() {
      var offset = 0;
      while (offset < num.length && num[offset] == 0) {
        offset += 1;
      }
      var _num = new Array(num.length - offset + shift);
      for (var i = 0; i < num.length - offset; i += 1) {
        _num[i] = num[i + offset];
      }
      return _num;
    }();

    var _this = {};

    _this.getAt = function(index) {
      return _num[index];
    };

    _this.getLength = function() {
      return _num.length;
    };

    _this.multiply = function(e) {

      var num = new Array(_this.getLength() + e.getLength() - 1);

      for (var i = 0; i < _this.getLength(); i += 1) {
        for (var j = 0; j < e.getLength(); j += 1) {
          num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
        }
      }

      return qrPolynomial(num, 0);
    };

    _this.mod = function(e) {

      if (_this.getLength() - e.getLength() < 0) {
        return _this;
      }

      var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );

      var num = new Array(_this.getLength() );
      for (var i = 0; i < _this.getLength(); i += 1) {
        num[i] = _this.getAt(i);
      }

      for (var i = 0; i < e.getLength(); i += 1) {
        num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
      }

      // recursive call
      return qrPolynomial(num, 0).mod(e);
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // QRRSBlock
  //---------------------------------------------------------------------

  var QRRSBlock = function() {

    var RS_BLOCK_TABLE = [

      // L
      // M
      // Q
      // H

      // 1
      [1, 26, 19],
      [1, 26, 16],
      [1, 26, 13],
      [1, 26, 9],

      // 2
      [1, 44, 34],
      [1, 44, 28],
      [1, 44, 22],
      [1, 44, 16],

      // 3
      [1, 70, 55],
      [1, 70, 44],
      [2, 35, 17],
      [2, 35, 13],

      // 4
      [1, 100, 80],
      [2, 50, 32],
      [2, 50, 24],
      [4, 25, 9],

      // 5
      [1, 134, 108],
      [2, 67, 43],
      [2, 33, 15, 2, 34, 16],
      [2, 33, 11, 2, 34, 12],

      // 6
      [2, 86, 68],
      [4, 43, 27],
      [4, 43, 19],
      [4, 43, 15],

      // 7
      [2, 98, 78],
      [4, 49, 31],
      [2, 32, 14, 4, 33, 15],
      [4, 39, 13, 1, 40, 14],

      // 8
      [2, 121, 97],
      [2, 60, 38, 2, 61, 39],
      [4, 40, 18, 2, 41, 19],
      [4, 40, 14, 2, 41, 15],

      // 9
      [2, 146, 116],
      [3, 58, 36, 2, 59, 37],
      [4, 36, 16, 4, 37, 17],
      [4, 36, 12, 4, 37, 13],

      // 10
      [2, 86, 68, 2, 87, 69],
      [4, 69, 43, 1, 70, 44],
      [6, 43, 19, 2, 44, 20],
      [6, 43, 15, 2, 44, 16],

      // 11
      [4, 101, 81],
      [1, 80, 50, 4, 81, 51],
      [4, 50, 22, 4, 51, 23],
      [3, 36, 12, 8, 37, 13],

      // 12
      [2, 116, 92, 2, 117, 93],
      [6, 58, 36, 2, 59, 37],
      [4, 46, 20, 6, 47, 21],
      [7, 42, 14, 4, 43, 15],

      // 13
      [4, 133, 107],
      [8, 59, 37, 1, 60, 38],
      [8, 44, 20, 4, 45, 21],
      [12, 33, 11, 4, 34, 12],

      // 14
      [3, 145, 115, 1, 146, 116],
      [4, 64, 40, 5, 65, 41],
      [11, 36, 16, 5, 37, 17],
      [11, 36, 12, 5, 37, 13],

      // 15
      [5, 109, 87, 1, 110, 88],
      [5, 65, 41, 5, 66, 42],
      [5, 54, 24, 7, 55, 25],
      [11, 36, 12, 7, 37, 13],

      // 16
      [5, 122, 98, 1, 123, 99],
      [7, 73, 45, 3, 74, 46],
      [15, 43, 19, 2, 44, 20],
      [3, 45, 15, 13, 46, 16],

      // 17
      [1, 135, 107, 5, 136, 108],
      [10, 74, 46, 1, 75, 47],
      [1, 50, 22, 15, 51, 23],
      [2, 42, 14, 17, 43, 15],

      // 18
      [5, 150, 120, 1, 151, 121],
      [9, 69, 43, 4, 70, 44],
      [17, 50, 22, 1, 51, 23],
      [2, 42, 14, 19, 43, 15],

      // 19
      [3, 141, 113, 4, 142, 114],
      [3, 70, 44, 11, 71, 45],
      [17, 47, 21, 4, 48, 22],
      [9, 39, 13, 16, 40, 14],

      // 20
      [3, 135, 107, 5, 136, 108],
      [3, 67, 41, 13, 68, 42],
      [15, 54, 24, 5, 55, 25],
      [15, 43, 15, 10, 44, 16],

      // 21
      [4, 144, 116, 4, 145, 117],
      [17, 68, 42],
      [17, 50, 22, 6, 51, 23],
      [19, 46, 16, 6, 47, 17],

      // 22
      [2, 139, 111, 7, 140, 112],
      [17, 74, 46],
      [7, 54, 24, 16, 55, 25],
      [34, 37, 13],

      // 23
      [4, 151, 121, 5, 152, 122],
      [4, 75, 47, 14, 76, 48],
      [11, 54, 24, 14, 55, 25],
      [16, 45, 15, 14, 46, 16],

      // 24
      [6, 147, 117, 4, 148, 118],
      [6, 73, 45, 14, 74, 46],
      [11, 54, 24, 16, 55, 25],
      [30, 46, 16, 2, 47, 17],

      // 25
      [8, 132, 106, 4, 133, 107],
      [8, 75, 47, 13, 76, 48],
      [7, 54, 24, 22, 55, 25],
      [22, 45, 15, 13, 46, 16],

      // 26
      [10, 142, 114, 2, 143, 115],
      [19, 74, 46, 4, 75, 47],
      [28, 50, 22, 6, 51, 23],
      [33, 46, 16, 4, 47, 17],

      // 27
      [8, 152, 122, 4, 153, 123],
      [22, 73, 45, 3, 74, 46],
      [8, 53, 23, 26, 54, 24],
      [12, 45, 15, 28, 46, 16],

      // 28
      [3, 147, 117, 10, 148, 118],
      [3, 73, 45, 23, 74, 46],
      [4, 54, 24, 31, 55, 25],
      [11, 45, 15, 31, 46, 16],

      // 29
      [7, 146, 116, 7, 147, 117],
      [21, 73, 45, 7, 74, 46],
      [1, 53, 23, 37, 54, 24],
      [19, 45, 15, 26, 46, 16],

      // 30
      [5, 145, 115, 10, 146, 116],
      [19, 75, 47, 10, 76, 48],
      [15, 54, 24, 25, 55, 25],
      [23, 45, 15, 25, 46, 16],

      // 31
      [13, 145, 115, 3, 146, 116],
      [2, 74, 46, 29, 75, 47],
      [42, 54, 24, 1, 55, 25],
      [23, 45, 15, 28, 46, 16],

      // 32
      [17, 145, 115],
      [10, 74, 46, 23, 75, 47],
      [10, 54, 24, 35, 55, 25],
      [19, 45, 15, 35, 46, 16],

      // 33
      [17, 145, 115, 1, 146, 116],
      [14, 74, 46, 21, 75, 47],
      [29, 54, 24, 19, 55, 25],
      [11, 45, 15, 46, 46, 16],

      // 34
      [13, 145, 115, 6, 146, 116],
      [14, 74, 46, 23, 75, 47],
      [44, 54, 24, 7, 55, 25],
      [59, 46, 16, 1, 47, 17],

      // 35
      [12, 151, 121, 7, 152, 122],
      [12, 75, 47, 26, 76, 48],
      [39, 54, 24, 14, 55, 25],
      [22, 45, 15, 41, 46, 16],

      // 36
      [6, 151, 121, 14, 152, 122],
      [6, 75, 47, 34, 76, 48],
      [46, 54, 24, 10, 55, 25],
      [2, 45, 15, 64, 46, 16],

      // 37
      [17, 152, 122, 4, 153, 123],
      [29, 74, 46, 14, 75, 47],
      [49, 54, 24, 10, 55, 25],
      [24, 45, 15, 46, 46, 16],

      // 38
      [4, 152, 122, 18, 153, 123],
      [13, 74, 46, 32, 75, 47],
      [48, 54, 24, 14, 55, 25],
      [42, 45, 15, 32, 46, 16],

      // 39
      [20, 147, 117, 4, 148, 118],
      [40, 75, 47, 7, 76, 48],
      [43, 54, 24, 22, 55, 25],
      [10, 45, 15, 67, 46, 16],

      // 40
      [19, 148, 118, 6, 149, 119],
      [18, 75, 47, 31, 76, 48],
      [34, 54, 24, 34, 55, 25],
      [20, 45, 15, 61, 46, 16]
    ];

    var qrRSBlock = function(totalCount, dataCount) {
      var _this = {};
      _this.totalCount = totalCount;
      _this.dataCount = dataCount;
      return _this;
    };

    var _this = {};

    var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {

      switch(errorCorrectionLevel) {
      case QRErrorCorrectionLevel.L :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
      case QRErrorCorrectionLevel.M :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
      case QRErrorCorrectionLevel.Q :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
      case QRErrorCorrectionLevel.H :
        return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
      default :
        return undefined;
      }
    };

    _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {

      var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);

      if (typeof rsBlock == 'undefined') {
        throw 'bad rs block @ typeNumber:' + typeNumber +
            '/errorCorrectionLevel:' + errorCorrectionLevel;
      }

      var length = rsBlock.length / 3;

      var list = [];

      for (var i = 0; i < length; i += 1) {

        var count = rsBlock[i * 3 + 0];
        var totalCount = rsBlock[i * 3 + 1];
        var dataCount = rsBlock[i * 3 + 2];

        for (var j = 0; j < count; j += 1) {
          list.push(qrRSBlock(totalCount, dataCount) );
        }
      }

      return list;
    };

    return _this;
  }();

  //---------------------------------------------------------------------
  // qrBitBuffer
  //---------------------------------------------------------------------

  var qrBitBuffer = function() {

    var _buffer = [];
    var _length = 0;

    var _this = {};

    _this.getBuffer = function() {
      return _buffer;
    };

    _this.getAt = function(index) {
      var bufIndex = Math.floor(index / 8);
      return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
    };

    _this.put = function(num, length) {
      for (var i = 0; i < length; i += 1) {
        _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
      }
    };

    _this.getLengthInBits = function() {
      return _length;
    };

    _this.putBit = function(bit) {

      var bufIndex = Math.floor(_length / 8);
      if (_buffer.length <= bufIndex) {
        _buffer.push(0);
      }

      if (bit) {
        _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
      }

      _length += 1;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrNumber
  //---------------------------------------------------------------------

  var qrNumber = function(data) {

    var _mode = QRMode.MODE_NUMBER;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var data = _data;

      var i = 0;

      while (i + 2 < data.length) {
        buffer.put(strToNum(data.substring(i, i + 3) ), 10);
        i += 3;
      }

      if (i < data.length) {
        if (data.length - i == 1) {
          buffer.put(strToNum(data.substring(i, i + 1) ), 4);
        } else if (data.length - i == 2) {
          buffer.put(strToNum(data.substring(i, i + 2) ), 7);
        }
      }
    };

    var strToNum = function(s) {
      var num = 0;
      for (var i = 0; i < s.length; i += 1) {
        num = num * 10 + chatToNum(s.charAt(i) );
      }
      return num;
    };

    var chatToNum = function(c) {
      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      }
      throw 'illegal char :' + c;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrAlphaNum
  //---------------------------------------------------------------------

  var qrAlphaNum = function(data) {

    var _mode = QRMode.MODE_ALPHA_NUM;
    var _data = data;

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _data.length;
    };

    _this.write = function(buffer) {

      var s = _data;

      var i = 0;

      while (i + 1 < s.length) {
        buffer.put(
          getCode(s.charAt(i) ) * 45 +
          getCode(s.charAt(i + 1) ), 11);
        i += 2;
      }

      if (i < s.length) {
        buffer.put(getCode(s.charAt(i) ), 6);
      }
    };

    var getCode = function(c) {

      if ('0' <= c && c <= '9') {
        return c.charCodeAt(0) - '0'.charCodeAt(0);
      } else if ('A' <= c && c <= 'Z') {
        return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
      } else {
        switch (c) {
        case ' ' : return 36;
        case '$' : return 37;
        case '%' : return 38;
        case '*' : return 39;
        case '+' : return 40;
        case '-' : return 41;
        case '.' : return 42;
        case '/' : return 43;
        case ':' : return 44;
        default :
          throw 'illegal char :' + c;
        }
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qr8BitByte
  //---------------------------------------------------------------------

  var qr8BitByte = function(data) {

    var _mode = QRMode.MODE_8BIT_BYTE;
    var _data = data;
    var _bytes = qrcode.stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return _bytes.length;
    };

    _this.write = function(buffer) {
      for (var i = 0; i < _bytes.length; i += 1) {
        buffer.put(_bytes[i], 8);
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // qrKanji
  //---------------------------------------------------------------------

  var qrKanji = function(data) {

    var _mode = QRMode.MODE_KANJI;
    var _data = data;

    var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
    if (!stringToBytes) {
      throw 'sjis not supported.';
    }
    !function(c, code) {
      // self test for sjis support.
      var test = stringToBytes(c);
      if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
        throw 'sjis not supported.';
      }
    }('\u53cb', 0x9746);

    var _bytes = stringToBytes(data);

    var _this = {};

    _this.getMode = function() {
      return _mode;
    };

    _this.getLength = function(buffer) {
      return ~~(_bytes.length / 2);
    };

    _this.write = function(buffer) {

      var data = _bytes;

      var i = 0;

      while (i + 1 < data.length) {

        var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);

        if (0x8140 <= c && c <= 0x9FFC) {
          c -= 0x8140;
        } else if (0xE040 <= c && c <= 0xEBBF) {
          c -= 0xC140;
        } else {
          throw 'illegal char at ' + (i + 1) + '/' + c;
        }

        c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);

        buffer.put(c, 13);

        i += 2;
      }

      if (i < data.length) {
        throw 'illegal char at ' + (i + 1);
      }
    };

    return _this;
  };

  //=====================================================================
  // GIF Support etc.
  //

  //---------------------------------------------------------------------
  // byteArrayOutputStream
  //---------------------------------------------------------------------

  var byteArrayOutputStream = function() {

    var _bytes = [];

    var _this = {};

    _this.writeByte = function(b) {
      _bytes.push(b & 0xff);
    };

    _this.writeShort = function(i) {
      _this.writeByte(i);
      _this.writeByte(i >>> 8);
    };

    _this.writeBytes = function(b, off, len) {
      off = off || 0;
      len = len || b.length;
      for (var i = 0; i < len; i += 1) {
        _this.writeByte(b[i + off]);
      }
    };

    _this.writeString = function(s) {
      for (var i = 0; i < s.length; i += 1) {
        _this.writeByte(s.charCodeAt(i) );
      }
    };

    _this.toByteArray = function() {
      return _bytes;
    };

    _this.toString = function() {
      var s = '';
      s += '[';
      for (var i = 0; i < _bytes.length; i += 1) {
        if (i > 0) {
          s += ',';
        }
        s += _bytes[i];
      }
      s += ']';
      return s;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64EncodeOutputStream
  //---------------------------------------------------------------------

  var base64EncodeOutputStream = function() {

    var _buffer = 0;
    var _buflen = 0;
    var _length = 0;
    var _base64 = '';

    var _this = {};

    var writeEncoded = function(b) {
      _base64 += String.fromCharCode(encode(b & 0x3f) );
    };

    var encode = function(n) {
      if (n < 0) {
        // error.
      } else if (n < 26) {
        return 0x41 + n;
      } else if (n < 52) {
        return 0x61 + (n - 26);
      } else if (n < 62) {
        return 0x30 + (n - 52);
      } else if (n == 62) {
        return 0x2b;
      } else if (n == 63) {
        return 0x2f;
      }
      throw 'n:' + n;
    };

    _this.writeByte = function(n) {

      _buffer = (_buffer << 8) | (n & 0xff);
      _buflen += 8;
      _length += 1;

      while (_buflen >= 6) {
        writeEncoded(_buffer >>> (_buflen - 6) );
        _buflen -= 6;
      }
    };

    _this.flush = function() {

      if (_buflen > 0) {
        writeEncoded(_buffer << (6 - _buflen) );
        _buffer = 0;
        _buflen = 0;
      }

      if (_length % 3 != 0) {
        // padding
        var padlen = 3 - _length % 3;
        for (var i = 0; i < padlen; i += 1) {
          _base64 += '=';
        }
      }
    };

    _this.toString = function() {
      return _base64;
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // base64DecodeInputStream
  //---------------------------------------------------------------------

  var base64DecodeInputStream = function(str) {

    var _str = str;
    var _pos = 0;
    var _buffer = 0;
    var _buflen = 0;

    var _this = {};

    _this.read = function() {

      while (_buflen < 8) {

        if (_pos >= _str.length) {
          if (_buflen == 0) {
            return -1;
          }
          throw 'unexpected end of file./' + _buflen;
        }

        var c = _str.charAt(_pos);
        _pos += 1;

        if (c == '=') {
          _buflen = 0;
          return -1;
        } else if (c.match(/^\s$/) ) {
          // ignore if whitespace.
          continue;
        }

        _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
        _buflen += 6;
      }

      var n = (_buffer >>> (_buflen - 8) ) & 0xff;
      _buflen -= 8;
      return n;
    };

    var decode = function(c) {
      if (0x41 <= c && c <= 0x5a) {
        return c - 0x41;
      } else if (0x61 <= c && c <= 0x7a) {
        return c - 0x61 + 26;
      } else if (0x30 <= c && c <= 0x39) {
        return c - 0x30 + 52;
      } else if (c == 0x2b) {
        return 62;
      } else if (c == 0x2f) {
        return 63;
      } else {
        throw 'c:' + c;
      }
    };

    return _this;
  };

  //---------------------------------------------------------------------
  // gifImage (B/W)
  //---------------------------------------------------------------------

  var gifImage = function(width, height) {

    var _width = width;
    var _height = height;
    var _data = new Array(width * height);

    var _this = {};

    _this.setPixel = function(x, y, pixel) {
      _data[y * _width + x] = pixel;
    };

    _this.write = function(out) {

      //---------------------------------
      // GIF Signature

      out.writeString('GIF87a');

      //---------------------------------
      // Screen Descriptor

      out.writeShort(_width);
      out.writeShort(_height);

      out.writeByte(0x80); // 2bit
      out.writeByte(0);
      out.writeByte(0);

      //---------------------------------
      // Global Color Map

      // black
      out.writeByte(0x00);
      out.writeByte(0x00);
      out.writeByte(0x00);

      // white
      out.writeByte(0xff);
      out.writeByte(0xff);
      out.writeByte(0xff);

      //---------------------------------
      // Image Descriptor

      out.writeString(',');
      out.writeShort(0);
      out.writeShort(0);
      out.writeShort(_width);
      out.writeShort(_height);
      out.writeByte(0);

      //---------------------------------
      // Local Color Map

      //---------------------------------
      // Raster Data

      var lzwMinCodeSize = 2;
      var raster = getLZWRaster(lzwMinCodeSize);

      out.writeByte(lzwMinCodeSize);

      var offset = 0;

      while (raster.length - offset > 255) {
        out.writeByte(255);
        out.writeBytes(raster, offset, 255);
        offset += 255;
      }

      out.writeByte(raster.length - offset);
      out.writeBytes(raster, offset, raster.length - offset);
      out.writeByte(0x00);

      //---------------------------------
      // GIF Terminator
      out.writeString(';');
    };

    var bitOutputStream = function(out) {

      var _out = out;
      var _bitLength = 0;
      var _bitBuffer = 0;

      var _this = {};

      _this.write = function(data, length) {

        if ( (data >>> length) != 0) {
          throw 'length over';
        }

        while (_bitLength + length >= 8) {
          _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
          length -= (8 - _bitLength);
          data >>>= (8 - _bitLength);
          _bitBuffer = 0;
          _bitLength = 0;
        }

        _bitBuffer = (data << _bitLength) | _bitBuffer;
        _bitLength = _bitLength + length;
      };

      _this.flush = function() {
        if (_bitLength > 0) {
          _out.writeByte(_bitBuffer);
        }
      };

      return _this;
    };

    var getLZWRaster = function(lzwMinCodeSize) {

      var clearCode = 1 << lzwMinCodeSize;
      var endCode = (1 << lzwMinCodeSize) + 1;
      var bitLength = lzwMinCodeSize + 1;

      // Setup LZWTable
      var table = lzwTable();

      for (var i = 0; i < clearCode; i += 1) {
        table.add(String.fromCharCode(i) );
      }
      table.add(String.fromCharCode(clearCode) );
      table.add(String.fromCharCode(endCode) );

      var byteOut = byteArrayOutputStream();
      var bitOut = bitOutputStream(byteOut);

      // clear code
      bitOut.write(clearCode, bitLength);

      var dataIndex = 0;

      var s = String.fromCharCode(_data[dataIndex]);
      dataIndex += 1;

      while (dataIndex < _data.length) {

        var c = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;

        if (table.contains(s + c) ) {

          s = s + c;

        } else {

          bitOut.write(table.indexOf(s), bitLength);

          if (table.size() < 0xfff) {

            if (table.size() == (1 << bitLength) ) {
              bitLength += 1;
            }

            table.add(s + c);
          }

          s = c;
        }
      }

      bitOut.write(table.indexOf(s), bitLength);

      // end code
      bitOut.write(endCode, bitLength);

      bitOut.flush();

      return byteOut.toByteArray();
    };

    var lzwTable = function() {

      var _map = {};
      var _size = 0;

      var _this = {};

      _this.add = function(key) {
        if (_this.contains(key) ) {
          throw 'dup key:' + key;
        }
        _map[key] = _size;
        _size += 1;
      };

      _this.size = function() {
        return _size;
      };

      _this.indexOf = function(key) {
        return _map[key];
      };

      _this.contains = function(key) {
        return typeof _map[key] != 'undefined';
      };

      return _this;
    };

    return _this;
  };

  var createDataURL = function(width, height, getPixel) {
    var gif = gifImage(width, height);
    for (var y = 0; y < height; y += 1) {
      for (var x = 0; x < width; x += 1) {
        gif.setPixel(x, y, getPixel(x, y) );
      }
    }

    var b = byteArrayOutputStream();
    gif.write(b);

    var base64 = base64EncodeOutputStream();
    var bytes = b.toByteArray();
    for (var i = 0; i < bytes.length; i += 1) {
      base64.writeByte(bytes[i]);
    }
    base64.flush();

    return 'data:image/gif;base64,' + base64;
  };

  //---------------------------------------------------------------------
  // returns qrcode function.

  return qrcode;
}();

// multibyte support
!function() {

  qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
    // http://stackoverflow.com/questions/18729405/how-to-convert-utf8-string-to-byte-array
    function toUTF8Array(str) {
      var utf8 = [];
      for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
          utf8.push(0xc0 | (charcode >> 6),
              0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
          utf8.push(0xe0 | (charcode >> 12),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
          i++;
          // UTF-16 encodes 0x10000-0x10FFFF by
          // subtracting 0x10000 and splitting the
          // 20 bits of 0x0-0xFFFFF into two halves
          charcode = 0x10000 + (((charcode & 0x3ff)<<10)
            | (str.charCodeAt(i) & 0x3ff));
          utf8.push(0xf0 | (charcode >>18),
              0x80 | ((charcode>>12) & 0x3f),
              0x80 | ((charcode>>6) & 0x3f),
              0x80 | (charcode & 0x3f));
        }
      }
      return utf8;
    }
    return toUTF8Array(s);
  };

}();
const PUBLIC_URL = "https://thohmass.github.io/Quantrain/prototype/";             // where the shared game lives (set by the build; links need it inside iframes)
let puzzleCtx = null;                              // { P, data, test, key } while a puzzle is open
const puzzleKey = P => JSON.stringify(P.slice(3)); // what the player meets: renaming does not need a new test
const DEFAULT_SUPPLY = [-1, -1, -1, -1];           // twist, points, cross, interlock: -1 = unlimited, 0 = none
const SUPPLY_STEPS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, -1];
const MAX_CARS = 16;
const hashText = s => { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 0x01000193); return (h >>> 0).toString(36); };
const puzzleStoreKey = () => `quantrain:puzzle:${puzzleCtx.test ? "test" : "play"}:${hashText(puzzleCtx.key)}`;   // your own test build stays out of the shared copy

/** The playground design → the puzzle array of the engine codec. */
function designToPuzzle(g) {
  const ri = r => r.charCodeAt(0) - 65;
  const sts = [...g.stations].sort((a, b) => a.col - b.col || ri(a.rail) - ri(b.rail));
  const index = new Map(sts.map((st, i) => [cellKey(st.col, st.rail), i]));
  const used = new Set([...sts.map(st => cellKey(st.col, st.rail)), ...g.placements.flatMap(p => p.rails.map(r => cellKey(p.col, r)))]);
  const blocked = new Set(g.blocked ?? []);
  const cells = Array.from({ length: g.columns }, (_, c) => {
    let mask = 0;
    for (let k = 0; k < g.rails; k++) { const key = cellKey(c + 1, railName(k)); if (!used.has(key) && !blocked.has(key)) mask |= 1 << k; }
    return mask;
  });
  const fixed = g.placements.map(p => {
    const top = Math.min(...p.rails.map(ri));
    const f = [TYPE_CODES.indexOf(p.type), p.col, top];
    if (p.type === 'twist') f.push(p.steps ?? 0);
    if (p.type === 'points') f.push(p.stay ?? 50);
    return f;
  });
  return [1, (g.name ?? '').trim().slice(0, LIMITS.name), (g.desc ?? '').trim().slice(0, LIMITS.description),
    g.rails, g.columns, g.together ? 1 : 0, g.trains.map(t => [t.slot, ri(t.rail)]),
    sts.map(st => [st.col, ri(st.rail), st.n ?? 2, st.partner && index.has(st.partner) ? index.get(st.partner) : -1]),
    fixed, cells, [...(g.supplyP ?? DEFAULT_SUPPLY)], g.cars ?? 0];
}
/** The puzzle array → a playground design (Remix): fixed parts become ordinary blocks, closed cells stay closed. */
function puzzleToDesign(P) {
  const [, name, desc, nR, nC, together, trains, stations, fixed, cells, supply, cars] = P;
  const key = st => cellKey(st[0], railName(st[1]));
  const g = {
    rails: nR, columns: nC, together: !!together, trains: trains.map(([slot, r]) => ({ slot, rail: railName(r) })),
    stations: stations.map(st => ({ col: st[0], rail: railName(st[1]), n: st[2], ...(st[3] >= 0 ? { partner: key(stations[st[3]]) } : {}) })),
    placements: fixed.map(([code, col, top, x]) => {
      const type = TYPE_CODES[code], p = { type, col, rails: Array.from({ length: SPAN[type] }, (_, k) => railName(top + k)) };
      if (type === 'twist') p.steps = x;
      if (type === 'points') p.stay = x;
      return p;
    }),
    blocked: [], supplyP: [...supply], name, desc, cars,
  };
  const used = new Set([...g.stations.map(st => cellKey(st.col, st.rail)), ...g.placements.flatMap(p => p.rails.map(r => cellKey(p.col, r)))]);
  for (let c = 1; c <= nC; c++) for (let k = 0; k < nR; k++) {
    const k2 = cellKey(c, railName(k));
    if (!used.has(k2) && !(cells[c - 1] & (1 << k))) g.blocked.push(k2);
  }
  return g;
}
/** Is the design a puzzle that can be tested? { P, data } or { problem }. */
function checkDesign(g) {
  const P = designToPuzzle(g);
  let data;
  try { data = puzzleToLevelData(P); } catch (err) { return { P, problem: err.message.replace(/^puzzle: /, '') }; }
  const Lp = parseLevel(data);
  const total = Lp.stations.reduce((n, s) => n + s.passengers.length, 0);
  if (!total) return { P, data, problem: 'Give at least one station a passenger.' };
  const open = P[9].reduce((n, m) => { for (; m; m &= m - 1) n++; return n; }, 0);
  const types = TYPE_CODES.filter(t => t in Lp.supply);
  let warning = '';
  if (!open) warning = 'The player has no pads to build on.';
  else if (!types.length) warning = 'The player gets no blocks: set at least one under "Blocks the player gets".';
  else if (idealRun(Lp, layout(Lp, [])).stars === 3) warning = 'Heads-up: it is already solved before the player places anything.';
  return { P, data, open, warning };
}

// ── open a puzzle (testing your own, or one someone shared)
function enterPuzzle(P, data, { test = false } = {}) {
  if (busy()) resetRun();
  setMaker(false);
  if (!hood.hidden) setHood(false);
  mode = 'puzzle';
  puzzleCtx = { P, data, test, key: puzzleKey(P) };
  document.body.classList.remove('playground');
  document.body.classList.add('puzzle');
  document.body.classList.toggle('puzzle-test', test);
  levelIndex = -1;
  L = parseLevel(data);
  const saved = store.get(puzzleStoreKey());
  placements = Array.isArray(saved) && legal(saved) ? saved : [];
  document.getElementById('title').innerHTML = `<span class="badge">${test ? 'testing' : 'community'}</span>${esc(L.name)}`;
  document.getElementById('blurb').textContent = L.blurb ||
    'A puzzle someone made in the Quantrain playground. Build on the empty pads and pick up every passenger in one run.';
  document.getElementById('back').textContent = test ? '‹ Editing' : '‹ Menu';
  setupPalette();
  rebuild();
  applyTheme();
  if (screen !== 'game') show('game'); else fit();
}
function leavePuzzleHash() {                       // the menu should not reopen the puzzle on reload
  try { if (/^#p=/.test(location.hash)) history.replaceState(null, '', location.pathname + location.search); } catch { /* sandboxed */ }
}
function remixPuzzle() {
  if (mode !== 'puzzle' || puzzleCtx.test) return;
  const before = store.get(PG_KEY);
  if (before) store.set(`${PG_KEY}:before-remix`, before);   // the previous playground is not lost for good
  const g = puzzleToDesign(puzzleCtx.P);
  leavePuzzleHash();
  enterPlayground(g);
  setMaker(true);
}
async function testDesign() {
  const c = checkDesign(pg);
  if (c.problem) { renderMaker(); return; }
  pg.name = c.P[1]; pg.desc = c.P[2];
  store.set(PG_KEY, pg);
  enterPuzzle(c.P, c.data, { test: true });
}

// ── the maker sheet: names, supply, passengers, couples, cars; tap pads on the map to open / close them
function setMaker(open) {
  if (open && (mode !== 'playground' || busy())) return;
  const was = makerOpen();
  if (open && !hood.hidden) setHood(false);
  maker.hidden = !open;
  document.body.classList.toggle('making', open);
  document.getElementById('make-puzzle').setAttribute('aria-expanded', String(open));
  if (open) renderMaker();
  if (was === open) return;
  if (cellObjs.length) showSlots();
  updatePlus();
  if (screen === 'game') fit();
}
const stepper = (attrs, value, label, dec, inc) =>
  `<span class="stepper" role="group" aria-label="${esc(label)}"><button type="button" ${attrs} data-d="-1" aria-label="fewer" ${dec ? '' : 'disabled'}>−</button>` +
  `<output>${value}</output><button type="button" ${attrs} data-d="1" aria-label="more" ${inc ? '' : 'disabled'}>+</button></span>`;
function renderMaker() {
  if (!pg) return;
  const sup = pg.supplyP ?? DEFAULT_SUPPLY;
  const interlockOk = pg.together && pg.trains.length > 1;
  document.getElementById('mk-supply').innerHTML = TYPE_CODES.map((t, i) => {
    if (t === 'interlock' && !interlockOk) return '';
    const at = SUPPLY_STEPS.indexOf(sup[i]);
    return `<div class="mk-row"><span class="k-${t}">${ICONS[t]}</span><span class="lbl-name">${NAMES[t]}</span>` +
      stepper(`data-sup="${i}"`, sup[i] < 0 ? '∞' : sup[i], `${NAMES[t]} for the player`, at > 0, at < SUPPLY_STEPS.length - 1) + '</div>';
  }).join('');
  const ri = r => r.charCodeAt(0) - 65;
  const sts = [...pg.stations].sort((a, b) => a.col - b.col || ri(a.rail) - ri(b.rail));
  document.getElementById('mk-stations').innerHTML = sts.length ? sts.map(st => {
    const k = cellKey(st.col, st.rail), n = st.n ?? 2, name = `Stop ${st.rail}${st.col}`;
    const options = ['<option value="">no couple</option>', ...sts.filter(o => o !== st).map(o => {
      const ok = cellKey(o.col, o.rail);
      return `<option value="${ok}" ${st.partner === ok ? 'selected' : ''}>♥ Stop ${o.rail}${o.col}</option>`;
    })].join('');
    return `<div class="mk-row"><span class="lbl-name">${name}</span>` +
      stepper(`data-pass="${k}"`, n, `passengers at ${name}`, n > 0, n < LIMITS.maxPassengers) +
      `<select data-couple="${k}" aria-label="couple of ${name}">${options}</select></div>`;
  }).join('') : '<p class="mk-empty">Drag stations from the dock onto the line first.</p>';
  const cars = pg.cars ?? 0, auto = carsFor(L);
  document.getElementById('mk-cars').innerHTML = `<div class="mk-row"><span class="lbl-name">${cars ? 'set by you' : `auto (${auto})`}</span>` +
    stepper('data-cars', cars || 'auto', 'cars per run', cars > 0, cars < MAX_CARS) + '</div>' +
    '<p class="mk-empty">Auto sends one car per passenger. Fewer cars make it harder.</p>';
  const name = document.getElementById('mk-name'), desc = document.getElementById('mk-desc');
  if (document.activeElement !== name) name.value = pg.name ?? '';
  if (document.activeElement !== desc) desc.value = pg.desc ?? '';
  const c = checkDesign(pg), verified = !c.problem && pg.verified === puzzleKey(c.P);
  document.getElementById('mk-test').disabled = !!c.problem;
  const share = document.getElementById('mk-share');
  share.disabled = !verified;
  share.title = verified ? '' : 'Clear your puzzle with ★★★ first';
  const status = document.getElementById('mk-status');
  status.classList.toggle('bad', !!c.problem);
  status.classList.toggle('good', verified);
  status.textContent = c.problem ? c.problem
    : (verified ? '✓ Cleared with ★★★: ready to share. ' : `Test it and clear it with ★★★ to unlock Share. `) +
      `${c.open} pad${c.open === 1 ? '' : 's'} open for the player.` + (c.warning ? ' ' + c.warning : '');
}
function changeDesign(f) {
  if (busy()) return;
  const g = clonePg(pg);
  f(g);
  pgCommit(g);
  renderMaker();
}
maker.addEventListener('click', e => {
  const b = e.target.closest('button[data-d]');
  if (!b || b.disabled) return;
  const d = +b.dataset.d;
  if (b.dataset.sup !== undefined) changeDesign(g => {
    const i = +b.dataset.sup, sup = g.supplyP = [...(g.supplyP ?? DEFAULT_SUPPLY)];
    sup[i] = SUPPLY_STEPS[Math.max(0, Math.min(SUPPLY_STEPS.length - 1, SUPPLY_STEPS.indexOf(sup[i]) + d))];
  });
  else if (b.dataset.pass !== undefined) changeDesign(g => {
    const st = g.stations.find(s => cellKey(s.col, s.rail) === b.dataset.pass);
    if (st) st.n = Math.max(0, Math.min(LIMITS.maxPassengers, (st.n ?? 2) + d));
  });
  else if (b.dataset.cars !== undefined) changeDesign(g => { g.cars = Math.max(0, Math.min(MAX_CARS, (g.cars ?? 0) + d)); });
});
maker.addEventListener('change', e => {
  const sel = e.target.closest('select[data-couple]');
  if (!sel) return;
  changeDesign(g => {
    const key = s => cellKey(s.col, s.rail);
    const me = g.stations.find(s => key(s) === sel.dataset.couple);
    const unlink = s => { const o = s?.partner && g.stations.find(x => key(x) === s.partner); if (o) delete o.partner; if (s) delete s.partner; };
    unlink(me);
    const other = sel.value && g.stations.find(s => key(s) === sel.value);
    if (me && other) { unlink(other); me.partner = key(other); other.partner = key(me); }
  });
});
for (const [id, field] of [['mk-name', 'name'], ['mk-desc', 'desc']]) {
  document.getElementById(id).addEventListener('input', e => { if (!pg) return; pg[field] = e.target.value; store.set(PG_KEY, pg); });
}
document.getElementById('maker-close').addEventListener('click', () => setMaker(false));
document.getElementById('make-puzzle').addEventListener('click', () => setMaker(!makerOpen()));
document.getElementById('mk-test').addEventListener('click', testDesign);
document.getElementById('mk-share').addEventListener('click', () => {
  const c = checkDesign(pg);
  if (!c.problem && pg.verified === puzzleKey(c.P)) sharePuzzle(c.P);
});
// a tap (not a drag) on a pad while the maker is open switches it between "the player builds here" and "closed"
const padTap = { id: null, x: 0, y: 0 };
function padAt(cx, cy) {
  const r = renderer.domElement.getBoundingClientRect();
  ndc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  levelGroup.updateMatrixWorld();
  const pads = cellObjs.filter(o => o.col > 0 && o.pad.visible);
  const hit = raycaster.intersectObjects(pads.map(o => o.fill), false)[0];
  return hit ? pads.find(o => o.fill === hit.object) : null;
}
renderer.domElement.addEventListener('pointerdown', e => {
  if (makerOpen() && e.isPrimary) Object.assign(padTap, { id: e.pointerId, x: e.clientX, y: e.clientY });
});
renderer.domElement.addEventListener('pointerup', e => {
  if (!makerOpen() || padTap.id !== e.pointerId) return;
  padTap.id = null;
  if (Math.hypot(e.clientX - padTap.x, e.clientY - padTap.y) > DRAG_START_PX) return;   // that was a pan
  const o = padAt(e.clientX, e.clientY);
  if (!o) return;
  changeDesign(g => {
    const set = new Set(g.blocked ?? []);
    if (set.has(o.key)) set.delete(o.key); else set.add(o.key);
    g.blocked = [...set];
  });
});

// ── share: link + QR + code
function shareBase() {
  try {
    if (window.top === window.self && /^https?:$/.test(location.protocol)) return location.origin + location.pathname;
  } catch { /* cross-origin parent: we are inside someone else's page */ }
  return PUBLIC_URL ? PUBLIC_URL.replace(/[#?].*$/, '') : '';
}
function qrSvg(text) {
  const q = qrcode(0, text.length > 600 ? 'L' : 'M');
  q.addData(text);
  q.make();
  const n = q.getModuleCount();
  let d = '';
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) d += `M${c} ${r}h1v1h-1z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-4 -4 ${n + 8} ${n + 8}" shape-rendering="crispEdges"><rect x="-4" y="-4" width="${n + 8}" height="${n + 8}" fill="#fff"/><path d="${d}" fill="#000"/></svg>`;
}
let modalReturn = null;
function openModal(el, focus) {
  modalReturn = document.activeElement;
  el.hidden = false;
  (focus ?? el.querySelector('[data-close]')).focus();
}
function closeModal(el) {
  if (el.hidden) return;
  el.hidden = true;
  if (modalReturn?.isConnected) modalReturn.focus();
}
const shareEl = document.getElementById('share'), openEl = document.getElementById('open');
async function sharePuzzle(P = puzzleCtx?.P) {
  if (!P) return;
  let code;
  try { code = await encodePuzzle(P); } catch (err) { console.warn('share:', err.message); return; }
  const base = shareBase(), link = base ? `${base}#p=${code}` : '';
  const name = P[1] || 'Untitled puzzle';
  document.getElementById('share-title').textContent = puzzleCtx?.test || mode === 'playground' ? 'Share your puzzle' : 'Share this puzzle';
  document.getElementById('share-sub').textContent = `“${name}” — anyone with the link or code gets the same map. ` +
    'The whole puzzle is inside the link itself: nothing is uploaded.';
  const qr = document.getElementById('share-qr');
  qr.hidden = !link;
  qr.innerHTML = link ? qrSvg(link) : '';
  const linkRow = document.getElementById('share-link').closest('.field');
  linkRow.hidden = !link;
  document.getElementById('share-link').value = link;
  document.getElementById('share-code').value = code;
  document.getElementById('share-note').textContent = link
    ? 'Scan the code with a phone camera, or send the link. In Qollab, use “Open a shared puzzle” and paste the code.'
    : 'This copy of the game has no public address, so there is no link here. Send the code: the player opens it with “Open a shared puzzle” in the menu.';
  const native = document.getElementById('share-native');
  native.hidden = !(link && navigator.share);
  native.onclick = () => navigator.share({ title: `Quantrain puzzle: ${name}`, text: P[2] || 'Can you clear my Quantrain puzzle?', url: link }).catch(() => {});
  openModal(shareEl);
}
for (const b of document.querySelectorAll('[data-copy]')) {
  b.addEventListener('click', async () => {
    const el = document.getElementById(b.dataset.copy), was = 'Copy';
    try { await navigator.clipboard.writeText(el.value); b.textContent = 'Copied ✓'; }
    catch { el.focus(); el.select(); b.textContent = 'Selected: ⌘/Ctrl+C'; }
    window.setTimeout(() => { b.textContent = was; }, 1800);
  });
}
for (const m of [shareEl, openEl]) {
  m.addEventListener('click', e => { if (e.target === m || e.target.closest('[data-close]')) closeModal(m); });
  m.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(m); });
}
document.getElementById('puzzle-share').addEventListener('click', () => sharePuzzle());
document.getElementById('puzzle-remix').addEventListener('click', remixPuzzle);

// ── open: a pasted link or code, or the '#p=' part of the address
const PUZZLE_ERRORS = {
  'this is not a puzzle code': 'That is not a puzzle link or code. It looks like q1.… (or a link with #p=q1.… in it).',
  'the code is damaged': 'The code is damaged: part of it is probably missing. Copy the whole link or code again.',
};
const puzzleError = err => err instanceof LevelError
  ? PUZZLE_ERRORS[err.message.replace(/^puzzle: /, '')] ?? `This puzzle does not load (${err.message.replace(/^puzzle: /, '')}). It may come from a newer version of Quantrain.`
  : 'This puzzle does not load in this browser.';
async function openPuzzleText(text) {
  const { puzzle, data } = await decodePuzzle(text);
  enterPuzzle(puzzle, data);
}
document.getElementById('go-open').addEventListener('click', () => {
  document.getElementById('open-error').textContent = '';
  openModal(openEl, document.getElementById('open-text'));
});
document.getElementById('open-go').addEventListener('click', async () => {
  const text = document.getElementById('open-text').value, errEl = document.getElementById('open-error');
  errEl.textContent = '';
  if (!text.trim()) { errEl.textContent = 'Paste a link or a code first.'; return; }
  try { await openPuzzleText(text); closeModal(openEl); }
  catch (err) { errEl.textContent = puzzleError(err); }
});
document.getElementById('open-text').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); document.getElementById('open-go').click(); }
});
async function openFromHash() {
  let hash = '';
  try { hash = location.hash; } catch { return false; }
  if (!/^#p=/.test(hash)) return false;
  try { await openPuzzleText(hash); return true; }
  catch (err) {
    document.getElementById('open-text').value = hash.slice(3);
    document.getElementById('open-error').textContent = puzzleError(err);
    openModal(openEl, document.getElementById('open-text'));
    return false;
  }
}
window.addEventListener('hashchange', () => { closeModal(openEl); closeModal(shareEl); openFromHash(); });

// ───────────────────────── screens: menu, level grid, game ─────────────────────────
let screen = 'menu';
const STAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8l2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2l-5.7 3.1 1.2-6.4-4.7-4.4 6.4-.8z" fill="currentColor" fill-opacity=".14" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>';
function renderLevelGrid() {
  document.getElementById('level-grid').innerHTML = LEVELS.map((lv, i) => {
    const stars = store.get(`quantrain:stars:${lv.id}`) ?? 0;          // best result of one run
    return `<button class="tile" type="button" data-level="${i}" aria-label="Level ${i + 1}: ${esc(lv.name)}, ${stars} of 3 stars">` +
      `<span class="num">${i + 1}</span><span class="name">${esc(lv.name)}</span>` +
      `<span class="stars">${[0, 1, 2].map(k => `<span class="${k < stars ? 'on' : ''}">${STAR}</span>`).join('')}</span>` +
      `<span class="done">${stars === 3 ? 'cleared' : ''}</span></button>`;
  }).join('');
}
function show(name) {
  screen = name;
  if (busy()) resetRun();
  if (name !== 'game' && !hood.hidden) setHood(false);
  document.getElementById('menu').hidden = name !== 'menu';
  document.getElementById('levels-screen').hidden = name !== 'levels';
  for (const el of [document.querySelector('header'), dock, document.getElementById('labels'), document.getElementById('fit'),
    document.getElementById('zoom-in'), document.getElementById('zoom-out')]) el.hidden = name !== 'game';
  hideResult();
  if (name !== 'game') { setMaker(false); if (mode === 'puzzle') leavePuzzleHash(); }
  if (name === 'levels') renderLevelGrid();
  updatePlus();
  if (name === 'game') fit();
}
document.getElementById('go-levels').addEventListener('click', () => show('levels'));
document.getElementById('go-playground').addEventListener('click', () => { enterPlayground(); show('game'); });
document.querySelector('[data-go="menu"]').addEventListener('click', () => show('menu'));
document.getElementById('level-grid').addEventListener('click', e => {
  const t = e.target.closest('[data-level]');
  if (t) { buildLevel(+t.dataset.level); show('game'); }
});
function goBack() {
  if (mode === 'puzzle' && puzzleCtx?.test) { if (busy()) resetRun(); enterPlayground(pg); setMaker(true); return; }
  show(mode === 'level' ? 'levels' : 'menu');
}
document.getElementById('back').addEventListener('click', goBack);
for (const [id, step] of [['prev-level', -1], ['next-level', 1]]) {
  document.getElementById(id).addEventListener('click', () => {
    const i = levelIndex + step;
    if (mode !== 'level' || i < 0 || i >= LEVELS.length) return;
    if (busy()) resetRun();
    buildLevel(i);
  });
}

// ───────────────────────── go ─────────────────────────
// ?level=N opens a level, ?playground opens the playground, otherwise the menu.
if (params.has('playground')) { enterPlayground(); show('game'); }
else if (params.has('level')) { buildLevel(Math.min(LEVELS.length, Math.max(1, parseInt(params.get('level'), 10) || 1)) - 1); show('game'); }
else { buildLevel(0); show('menu'); }
openFromHash();                                    // a shared link: …#p=q1.…
window.addEventListener('resize', fit);
renderer.setAnimationLoop(now => {
  if (screen !== 'game') return;                 // the map is covered: nothing to draw
  step(now);
  controls.update();
  renderer.render(scene, camera);
  placeLabels();
  placePlus();
});
if (qollab) await firstShotsDone;                 // keep the Qollab run live for the first shot job
